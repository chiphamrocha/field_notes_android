#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 prepare-assets.py
for file in app/src/main/assets/web/*.js; do node --check "$file"; done
for name in tablet photo-log release saved-drawings android recovery; do node "checks/$name.cjs"; done
if [[ "${FIELD_NOTES_BROWSER_TESTS:-0}" == 1 ]]; then node checks/browser-recovery.cjs; fi
