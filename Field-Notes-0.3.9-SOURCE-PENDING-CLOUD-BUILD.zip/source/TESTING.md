# Testing status

## Executed locally using pre-existing Codex runtimes
Five inherited Node regression suites passed after correcting stale test fixtures
for the already-released pointer-up gesture and per-location photo numbering.
Coverage: ink, eraser, undo/redo, draft persistence, saved-drawing isolation,
PPTX template generation, PDF exports with four rotations/crop/Unicode, and
Android bridge speech/export simulations. A new recovery suite passes multi-image
renumbering across pages and modal opening-gesture rejection.
These are automated checks, not Android hardware tests.

## Browser regression executed
The new full app scenario passed in pre-existing Microsoft Edge using an isolated
test profile and the bundled Playwright runtime. It exercised the Android HTML
entry, multi-image numbering, tag scale, delayed opening clicks, selected-field
dictation, crop/reset/cancel/arrows, visible editor actions at three screen sizes,
held marker drag, PDF/PPTX/ZIP output through the simulated native bridge and
persistent draft reload. Additional checks passed deletion/renumbering/Undo,
simulated pen Menu, two-page PDF navigation and rotation. No development software
was installed.

An upgrade-continuity check passed using the exact recovered 0.3.6 web assets
and an isolated test profile at the unchanged origin, then reloading the
candidate. Existing project/document/archive identity, caption/location/
disposition, photo identity/position and ink remained available. This is a
browser storage test, not a physical Android package upgrade test.

## Prepared, not yet executed
Cloud source compilation, official apksigner validation, zipalign check of a
new APK and cloud artifact download.
Cloud workflow uploads evidence but success must be checked before release.

## Not performed
Physical Samsung installation, actual camera/microphone/S Pen/IME interaction,
existing tablet-database migration acceptance, PowerPoint visual inspection,
physical printing at actual size and comparison with the user's own plan.

## Tablet acceptance after a verified signed build exists
1. Retain the current installation. Export a backup, notes and annotated PDF.
2. Install the signed candidate over the app, without uninstalling/clearing data.
3. Confirm existing saved drawings, photos, captions, dispositions and ink survive.
4. Open/cancel/save a marker where a dialog action overlaps it. Test finger and pen.
5. Alternate handwriting and dictation repeatedly in each text field.
6. Capture a camera photo, attach two images to one marker, reopen arrows/crop.
7. Navigate/rotate a multi-page plan; delete a photo entry and verify numbering.
8. Export annotated PDF and both editable reports; inspect all photos and text.
Stop on failure; preserve data and the working installation. Do not claim
physical verification based only on browser or bridge tests.
