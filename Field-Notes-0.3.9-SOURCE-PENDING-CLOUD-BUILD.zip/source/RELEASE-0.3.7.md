HISTORICAL REFERENCE ONLY. Prior release claims below are not current verification. Do not install failed 0.3.7/0.3.8 APKs.

# Field Notes v0.3.7 - Tablet field-test update

**Base:** installed/released v0.3.6, package `com.fieldnotes.preview`. Android versionCode **37**, versionName **0.3.7**. Same signing certificate as v0.3.6. Install over the existing app. **Do not uninstall or clear storage.**

## Implemented in this candidate
- Correct photo tag numbering by location, not number of attached images; multiple images retain the same tag. Reconcile skipped numbers in restored drawings.
- Press, hold, drag, and release to move existing note/photo markers with pen or finger; short tap still opens them.
- Draw Fine, Medium and Bold strokes in drawing coordinates, not screen-pixel widths, so zoom at creation does not change their saved relative thickness.
- Remove the redundant Screen text size selector; labels scale with the drawing and share the same nominal printed diameter. Set nominal diameter to 3/16 inch on the source sheet, pending visual comparison to the existing 111 keynote on the user's actual PDF.
- Match note/photo marker geometry in the annotated PDF and prevent multi-image markers showing a false ID range.
- Read-only Notes and Saved drawings dialogs close when the backdrop is tapped; editing dialogs retain their protection.
- Remove redundant Fit drawing to screen menu button; retain toolbar Fit.
- Remove persistent export-name field; use project number, project name and export type as editable Save dialog suggestions.
- Short-lived success messages instead of stale duplicate status messages.
- Rename Add/edit arrows to Edit, place it beside Remove, hide unhelpful `site-photo.jpg` display text; keep filenames inside backups.
- Photo editor now has Arrows and Crop, including Reset crop; preserve original photo data for subsequent reset.
- Add a separate photo log PDF export in addition to existing editable PowerPoint.
- Simplify pen-only helper text; add a pen-down fallback for hamburger-menu activation.
- Backup photo filenames include drawing page, tag and attachment index; preserve crop metadata and original photo files.

## Verification performed
- JavaScript syntax checks for modified files passed.
- Photo numbering regression: Photo 04 with two images remains 04; the next new location remains 10, not 11.
- Confirmed pen stroke creation no longer divides width by current screen zoom.
- APK ZIP integrity and alignment checks passed. `jarsigner -verify` passed. Matching SHA-256 signer certificate with v0.3.6 confirmed.
- AndroidManifest binary patched to versionCode 37 and versionName 0.3.7; package identity unchanged.

## Still requires physical tablet verification
- Samsung S Pen text-box focus lag and menu single-tap response; pen-down fallback is a mitigation, not a proven hardware fix.
- Exact visual match to the existing `111` keynote on the user's architectural PDF. The candidate uses a 3/16-inch nominal marker diameter, not a measured 111 symbol.
- Cropping, dragging, PDF and PowerPoint exports, Android Save dialog, camera and dictation on the actual tablet.
- Browser visual testing was blocked by the test environment; no claim of successful interactive/device QA.

**Do not uninstall v0.3.6 if installation fails.** Preserve data and report the Android error.
