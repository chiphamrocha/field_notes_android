HISTORICAL REFERENCE ONLY. Prior release claims below are not current verification. Do not install failed 0.3.7/0.3.8 APKs.

# Field Notes 0.3.3 test build

October 25, 2026. This build covers the 13 open items FN-005 through FN-017. Device acceptance remains separate from automated checks.

| Item | Included behavior | Verification / remaining limit |
| --- | --- | --- |
| FN-005 | Plan labels display at twice the earlier screen size. PDF label text is 13.5 pt, equal to 3/16 inch at Actual Size; circles expand to fit discipline IDs instead of shrinking their text. | Real PDF generated and rendered. Screen labels checked in the app. |
| FN-006 | Separate Rotate control turns the current PDF page 90 degrees clockwise and transforms its annotations with it. Rotation persists in saved drawings and vector PDF exports. | Four consecutive turns restore pin coordinates; actual two-page PDF export retains the page rotation. |
| FN-007 | Menu has its own S Pen activation handler, without the primary-pointer prerequisite, and suppresses duplicate compatibility clicks. | Simulated pen events pass. Samsung S Pen acceptance is pending. |
| FN-008 | Previous / page number / Next sit together at bottom center, alongside a distinct Rotate control. Navigation clears abandoned gestures first. | Actual page-button navigation on a two-page PDF passes, including with a stale gesture. |
| FN-009 | Select caption, location, disposition, or note text, then use the shared Record / Stop controls. The destination is named beside the controls. | Android and browser speech-provider simulations confirm that other fields remain untouched. Windows retains its local microphone engine with selected-field routing. |
| FN-010 | Photo arrow image fits within the editor; Undo arrow, Cancel and Apply arrows remain visible. | Tall-image editor checked at tablet portrait and short landscape sizes. Physical device check pending. |
| FN-011 | Android requests provider punctuation; on Stop, a conservative fallback capitalizes the first letter and adds a final period where appropriate. Original text can be restored for the selected field. | **Partial:** full contextual commas and sentence boundaries are not supplied by a separate language model. Provider support varies. Words and measurements are not rewritten by the fallback. |
| FN-012 | Android and browser dictation reconnect across service-imposed session ends and silent timeouts until Stop; captured text is retained. | Simulated repeated silence and browser restart pass. Permissions, provider failures and leaving the foreground can stop dictation explicitly. Windows retains its existing approximately three-minute recording limit. |
| FN-013 | Clear stale pointer, gesture, touch, navigation and pen-down state at editor/tool transitions and when leaving the app. | **Candidate fix:** state-reset checks pass, but the reported intermittent Samsung failure has not been reproduced or confirmed fixed on hardware. |
| FN-014 | Android speech requests architectural vocabulary hints including sill, jamb, mullion, CMU, soffit, flashing, RTU and HAZMAT. | **Provider-dependent:** hints may be ignored, particularly by older speech services. No replacement recognition engine or blanket seal-to-sill substitution. |
| FN-015 | Punch Walk Date and Project Number header cells share an identical left edge and width. | Actual exported PPTX XML confirms equal boundaries. PowerPoint/device visual acceptance remains pending. |
| FN-016 | Discipline choices and report headings use uppercase ARCHITECTURE, MECHANICAL, ELECTRICAL and FIRE PROTECTION. | App options and actual report content checked. |
| FN-017 | Open a saved note/photo pin and choose Delete entry. Deleting a photo removes its entry and pin, then renumbers remaining photos and labels continuously across the drawing set. Internal IDs and photo associations stay stable. Undo/Redo is available immediately after entry deletion. | 20-photo, two-page test deletes photo 3 and yields 1–19, preserving former photo 4's identity/caption as photo 3. Undo restores 20; Redo restores 19; save/reload preserves results. Text-note deletion is also checked. |

Already exported reports stay unchanged. New exports use the current numbering. Original source photos/PDFs on the device are kept. Text notes keep their existing numbers when deleted; the confirmed automatic-renumbering rule applies to photos.

## Install

- Android: install `Field-Notes-Android-0.3.3.apk` over the existing app. The package name and signing certificate match 0.3.2; version code increases from 32 to 33. Do not uninstall the existing app or clear its storage. Use Export backup package before updating important work.
- Windows: extract the complete `Field-Notes-Windows-0.3.3.zip`, then open `Field-Notes.exe`. The app data directory and database remain unchanged. The complete runtime and local speech model are included.
- iPhone/iPad: the ZIP contains a browser/PWA folder, not an iOS installer. Replace hosted files at the existing HTTPS URL to retain that browser's local data. This task does not publish or change hosting.
- Source: the source ZIP includes the Windows app code, Android project and original test signing key, PWA files, and QA scripts. Windows also contains an Android source ZIP under Developer.

## Validation

- Android compiled with platform 35 / Build Tools 35.0.0; APK signature verified. Certificate digest matches the prior APK exactly.
- Chromium checks passed separately against Android, Windows and PWA entry pages: setup, selected voice field, pen Menu, input reset, photo editor fit, deletion/renumbering, Undo/Redo, page navigation, four rotations, vector PDF, editable Punch Walk PPTX, and save/reload.
- Native Android speech and export bridges and browser speech were simulated. This is not a microphone or speech-accuracy test. The Windows executable was not run on Windows, and Safari was not run on an iPhone.
- Existing regression checks passed: drawing/coalesced samples, eraser rollback, draft persistence, Photo Log template output and continuation, archived drawings, PDF crop/rotation/Unicode, whole-drawing deletion isolation, Android binary export and failure cleanup. Three old QA harness assumptions were updated: missing base-fixture photo-ID helper, the requested ARCHITECTURE title, and the export-error rejection contract.
- Generated vector PDF was rendered and inspected. Punch Walk header coordinates and uppercase report text were checked in the generated PPTX XML; the changed PowerPoint was not rendered in PowerPoint/LibreOffice here.

## First tablet checks

1. Open an existing drawing. Check Menu with the S Pen, and previous/next PDF pages.
2. Open a note or photo label. Confirm Delete entry, renumbering, and immediate Undo.
3. Rotate a marked PDF page and export it; confirm the annotations follow the drawing.
4. In a photo form, select Location or Disposition, then Record. Pause, resume, and tap Stop. Check the target, punctuation, and technical words.
5. Switch between the photo form, handwriting and pan/zoom. Report whether the temporary drawing freeze returns.

Android speech option reference: https://developer.android.com/reference/android/speech/RecognizerIntent . Formatting and biasing support are optional and depend on the installed recognizer.
