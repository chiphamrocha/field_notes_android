from pathlib import Path
root=Path(__file__).parent/'app/src/main/assets/web'
assert (root/'index.html').exists() and (root/'fixes-037.js').exists()
assert 'Field Notes · 0.3.9' in (root/'index.html').read_text()
print('Field Notes 0.3.9 Android web assets are ready.')
