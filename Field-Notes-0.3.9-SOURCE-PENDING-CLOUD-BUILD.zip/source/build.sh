#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
sdk_path="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-}}"
: "${sdk_path:?Android SDK required on cloud runner}"
tools_path="$sdk_path/build-tools/35.0.0"
platform_path="$sdk_path/platforms/android-35/android.jar"
python3 prepare-assets.py
# Only generated files are removed. Existing APKs are never build inputs.
python3 - <<'PY'
from pathlib import Path
import shutil
for name in ['classes','dex','generated']:
 p=Path('build')/name
 if p.exists(): shutil.rmtree(p)
 p.mkdir(parents=True)
for name in ['resources.zip','resources.apk','classes.jar','unsigned.apk','aligned.apk','Field-Notes-Android-0.3.9.apk']:
 (Path('build')/name).unlink(missing_ok=True)
PY
"$tools_path/aapt2" compile --dir app/src/main/res -o build/resources.zip
"$tools_path/aapt2" link -o build/resources.apk --manifest app/src/main/AndroidManifest.xml -I "$platform_path" build/resources.zip -A app/src/main/assets --java build/generated
javac -encoding UTF-8 -source 8 -target 8 -classpath "$platform_path" -d build/classes app/src/main/java/com/fieldnotes/preview/*.java
python3 - <<'PY'
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
with ZipFile('build/classes.jar','w',ZIP_DEFLATED) as z:
 for p in sorted(Path('build/classes').rglob('*.class')): z.write(p,p.relative_to('build/classes'))
PY
"$tools_path/d8" --min-api 26 --lib "$platform_path" --output build/dex build/classes.jar
cp build/resources.apk build/unsigned.apk
python3 - <<'PY'
from zipfile import ZipFile, ZIP_DEFLATED
with ZipFile('build/unsigned.apk','a',ZIP_DEFLATED) as z:z.write('build/dex/classes.dex','classes.dex')
PY
"$tools_path/zipalign" -f -P 16 4 build/unsigned.apk build/aligned.apk
"$tools_path/zipalign" -c -P 16 4 build/aligned.apk
"$tools_path/aapt" dump badging build/aligned.apk > build/badging.txt
grep -q "package: name='com.fieldnotes.preview' versionCode='39' versionName='0.3.9'" build/badging.txt
if [[ -z "${FIELD_NOTES_KEYSTORE:-}" ]]; then
 echo 'Unsigned compilation complete. Matching key required before installation.'
 exit 0
fi
: "${FIELD_NOTES_STORE_PASSWORD:?Signing store password required}"
: "${FIELD_NOTES_KEY_PASSWORD:?Signing key password required}"
: "${FIELD_NOTES_KEY_ALIAS:?Signing alias required}"
"$tools_path/apksigner" sign --ks "$FIELD_NOTES_KEYSTORE" --ks-key-alias "$FIELD_NOTES_KEY_ALIAS" --ks-pass env:FIELD_NOTES_STORE_PASSWORD --key-pass env:FIELD_NOTES_KEY_PASSWORD --out build/Field-Notes-Android-0.3.9.apk build/aligned.apk
"$tools_path/apksigner" verify --verbose --print-certs build/Field-Notes-Android-0.3.9.apk > build/signature-verification.txt
grep -qi 'Signer #1 certificate SHA-256 digest: 28bfff0b3d3d38064caaa1ba679ebb2718cfcd3ed45a3daf9160b74efd46961c' build/signature-verification.txt
"$tools_path/zipalign" -c -P 16 4 build/Field-Notes-Android-0.3.9.apk
sha256sum build/Field-Notes-Android-0.3.9.apk > build/SHA256SUMS.txt
