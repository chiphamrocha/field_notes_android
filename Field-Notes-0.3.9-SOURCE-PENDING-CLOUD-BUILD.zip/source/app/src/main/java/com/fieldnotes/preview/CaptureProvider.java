package com.fieldnotes.preview;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import java.io.File;
import java.io.FileNotFoundException;

public final class CaptureProvider extends ContentProvider {
  public boolean onCreate(){ return true; }
  private File file(Uri uri) throws FileNotFoundException {
    if(!"com.fieldnotes.preview.capture".equals(uri.getAuthority()) || !uri.getPath().matches("/capture/[a-f0-9-]+\\.jpg")) throw new FileNotFoundException("Invalid capture");
    File f=new File(new File(getContext().getCacheDir(),"capture"),uri.getLastPathSegment());
    if(!f.exists())throw new FileNotFoundException("Capture expired");
    return f;
  }
  public String getType(Uri uri){return "image/jpeg";}
  public ParcelFileDescriptor openFile(Uri uri,String mode) throws FileNotFoundException {return ParcelFileDescriptor.open(file(uri),ParcelFileDescriptor.parseMode(mode));}
  public Cursor query(Uri uri,String[] projection,String selection,String[] args,String sort){
    try{File f=file(uri);String[] cols=projection==null?new String[]{OpenableColumns.DISPLAY_NAME,OpenableColumns.SIZE}:projection;MatrixCursor c=new MatrixCursor(cols);Object[] values=new Object[cols.length];for(int i=0;i<cols.length;i++)values[i]=OpenableColumns.DISPLAY_NAME.equals(cols[i])?"Site-photo.jpg":OpenableColumns.SIZE.equals(cols[i])?f.length():null;c.addRow(values);return c;}catch(Exception e){return null;}
  }
  public Uri insert(Uri u,ContentValues v){throw new UnsupportedOperationException();}
  public int delete(Uri u,String s,String[] a){throw new UnsupportedOperationException();}
  public int update(Uri u,ContentValues v,String s,String[] a){throw new UnsupportedOperationException();}
}
