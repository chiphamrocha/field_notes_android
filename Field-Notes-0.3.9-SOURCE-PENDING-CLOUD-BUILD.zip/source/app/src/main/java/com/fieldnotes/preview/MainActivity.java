package com.fieldnotes.preview;

import android.Manifest;
import android.app.*;
import android.content.*;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.*;
import android.provider.MediaStore;
import android.speech.*;
import android.util.Base64;
import android.webkit.*;
import android.widget.Toast;
import org.json.JSONObject;
import java.io.*;
import java.util.*;
import java.util.concurrent.Executors;

public final class MainActivity extends Activity {
  private static final String HOST="appassets.androidplatform.net", HOME="https://"+HOST+"/assets/web/index.html";
  private static final int PICK=10, EXPORT=11, MIC=12;
  private WebView web;
  private ValueCallback<Uri[]> chooser;
  private Uri captureUri;
  private SpeechRecognizer recognizer;
  private String voiceId, voiceLanguage;
  private final Handler timer=new Handler(Looper.getMainLooper());
  private final Bridge bridge=new Bridge();
  private boolean destroyed;
  private final java.util.concurrent.ExecutorService filesWorker=Executors.newSingleThreadExecutor();
  private static boolean local(Uri uri){return uri!=null&&"https".equals(uri.getScheme())&&HOST.equals(uri.getHost())&&uri.getPort()==-1&&uri.getPath()!=null&&uri.getPath().startsWith("/assets/web/");}
  private boolean trusted(){return web!=null&&local(Uri.parse(web.getUrl()==null?"":web.getUrl()));}
  private void js(String script){if(!destroyed)runOnUiThread(()->{if(!destroyed&&trusted())web.evaluateJavascript(script,null);});}
  private void status(String text){js("window.fieldNotesAndroidExportStatus&&window.fieldNotesAndroidExportStatus("+JSONObject.quote(text)+")");}
  private void toast(String text){runOnUiThread(()->Toast.makeText(this,text,Toast.LENGTH_LONG).show());}

  @Override public void onCreate(Bundle state){
    super.onCreate(state);
    // Avoid a blank page on the Android 8 factory WebView. Chrome 109+ is available for this OS.
    String agent=WebSettings.getDefaultUserAgent(this);java.util.regex.Matcher version=java.util.regex.Pattern.compile("Chrome/(\\d+)").matcher(agent);
    if(!version.find()||Integer.parseInt(version.group(1))<109){
      new AlertDialog.Builder(this).setTitle("Update Android System WebView").setMessage("Field Notes needs a newer drawing engine. In Google Play, update Android System WebView and Google Chrome, then reopen Field Notes. Android 8 is supported with WebView 109 or newer.").setPositiveButton("Open Google Play",(d,w)->{try{startActivity(new Intent(Intent.ACTION_VIEW,Uri.parse("market://details?id=com.google.android.webview")));}catch(Exception e){toast("Open Google Play and search for Android System WebView.");}finish();}).setNegativeButton("Close",(d,w)->finish()).setCancelable(false).show();return;
    }
    cleanCache();
    web=new WebView(this);setContentView(web);
    WebSettings settings=web.getSettings();settings.setJavaScriptEnabled(true);settings.setDomStorageEnabled(true);settings.setDatabaseEnabled(true);settings.setAllowFileAccess(false);settings.setAllowContentAccess(true);settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);settings.setSupportZoom(false);settings.setBuiltInZoomControls(false);settings.setDisplayZoomControls(false);settings.setTextZoom(100);settings.setMediaPlaybackRequiresUserGesture(true);
    web.setOverScrollMode(WebView.OVER_SCROLL_NEVER);
    web.addJavascriptInterface(bridge,"FieldNotesNative");
    web.setWebViewClient(new WebViewClient(){
      @Override public boolean shouldOverrideUrlLoading(WebView view,WebResourceRequest request){return !local(request.getUrl())||!HOME.equals(request.getUrl().toString());}
      @Override public boolean shouldOverrideUrlLoading(WebView view,String url){return !HOME.equals(url);}
      @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest request){return asset(request.getUrl());}
      @Override public void onReceivedError(WebView v,WebResourceRequest req,WebResourceError error){if(req.isForMainFrame())toast("The drawing workspace could not start. Close and reopen Field Notes.");}
      @Override public boolean onRenderProcessGone(WebView v,RenderProcessGoneDetail detail){web=null;v.destroy();new AlertDialog.Builder(MainActivity.this).setTitle("Drawing workspace stopped").setMessage("The phone ran out of drawing resources. Reopen Field Notes to restore the last saved draft. Large PDFs may need fewer pages.").setPositiveButton("Close",(d,w)->finish()).setCancelable(false).show();return true;}
    });
    web.setWebChromeClient(new WebChromeClient(){
      @Override public boolean onShowFileChooser(WebView view,ValueCallback<Uri[]> callback,FileChooserParams params){
        if(!trusted()){callback.onReceiveValue(null);return true;}
        if(chooser!=null)chooser.onReceiveValue(null);chooser=callback;captureUri=null;
        if(params.isCaptureEnabled()){openCamera();return true;}
        Intent pick=new Intent(Intent.ACTION_OPEN_DOCUMENT);pick.addCategory(Intent.CATEGORY_OPENABLE);
        ArrayList<String> types=new ArrayList<>();for(String type:params.getAcceptTypes())if(type!=null&&type.contains("/"))types.add(type);
        pick.setType(types.size()==1?types.get(0):"*/*");if(types.size()>1)pick.putExtra(Intent.EXTRA_MIME_TYPES,types.toArray(new String[0]));pick.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,params.getMode()==FileChooserParams.MODE_OPEN_MULTIPLE);
        try{startActivityForResult(pick,PICK);}catch(Exception error){finishChooser(null);toast("No file picker was found on this phone.");}return true;
      }
      @Override public void onPermissionRequest(PermissionRequest request){request.deny();} // Camera uses its own Android app; voice uses SpeechRecognizer.
      @Override public boolean onJsAlert(WebView v,String url,String message,JsResult result){new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("OK",(d,w)->result.confirm()).setOnCancelListener(d->result.cancel()).show();return true;}
      @Override public boolean onJsConfirm(WebView v,String url,String message,JsResult result){new AlertDialog.Builder(MainActivity.this).setMessage(message).setPositiveButton("Continue",(d,w)->result.confirm()).setNegativeButton("Cancel",(d,w)->result.cancel()).setOnCancelListener(d->result.cancel()).show();return true;}
    });
    web.loadUrl(HOME);
  }
  private WebResourceResponse asset(Uri uri){
    if(!local(uri))return response(403,"Blocked",new byte[0],"text/plain");
    String path=uri.getPath().substring("/assets/".length());
    if(path.contains("..")||path.contains("\\")||path.indexOf('\0')>=0)return response(403,"Blocked",new byte[0],"text/plain");
    try{
      InputStream input=getAssets().open(path);String mime;
      if(path.endsWith(".mjs")||path.endsWith(".js"))mime="application/javascript";else if(path.endsWith(".html"))mime="text/html";else if(path.endsWith(".css"))mime="text/css";else if(path.endsWith(".pdf"))mime="application/pdf";else if(path.endsWith(".ttf"))mime="font/ttf";else{mime=MimeTypeMap.getSingleton().getMimeTypeFromExtension(MimeTypeMap.getFileExtensionFromUrl(path));if(mime==null)mime="application/octet-stream";}
      Map<String,String> headers=new HashMap<>();headers.put("Content-Security-Policy","default-src 'self' data: blob:; script-src 'self'; worker-src 'self' blob:; style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; connect-src 'self'; media-src 'self' data: blob:; frame-src 'none'; object-src 'none'; base-uri 'self'; form-action 'self'");headers.put("X-Content-Type-Options","nosniff");
      return new WebResourceResponse(mime,"UTF-8",200,"OK",headers,input);
    }catch(IOException e){return response(404,"Not Found",new byte[0],"text/plain");}
  }
  private WebResourceResponse response(int code,String reason,byte[] bytes,String mime){return new WebResourceResponse(mime,"UTF-8",code,reason,Collections.emptyMap(),new ByteArrayInputStream(bytes));}
  private void cleanCache(){for(String name:new String[]{"capture","exports"}){File dir=new File(getCacheDir(),name);dir.mkdirs();File[] files=dir.listFiles();if(files!=null)for(File file:files)if(System.currentTimeMillis()-file.lastModified()>86400000L)file.delete();}}
  private void finishChooser(Uri[] uris){if(chooser!=null){ValueCallback<Uri[]> next=chooser;chooser=null;next.onReceiveValue(uris);}}
  private void openCamera(){
    try{File dir=new File(getCacheDir(),"capture");dir.mkdirs();File f=new File(dir,UUID.randomUUID()+".jpg");f.createNewFile();captureUri=Uri.parse("content://com.fieldnotes.preview.capture/capture/"+f.getName());
      Intent camera=new Intent(MediaStore.ACTION_IMAGE_CAPTURE);camera.putExtra(MediaStore.EXTRA_OUTPUT,captureUri);camera.setClipData(ClipData.newRawUri("Site photo",captureUri));camera.addFlags(Intent.FLAG_GRANT_WRITE_URI_PERMISSION|Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivityForResult(camera,PICK);
    }catch(Exception e){finishChooser(null);toast("Camera unavailable. Use Attach photos to select an existing picture.");}
  }
  @Override protected void onActivityResult(int request,int result,Intent data){
    super.onActivityResult(request,result,data);
    if(request==PICK){
      Uri[] uris=null;
      if(result==RESULT_OK){if(captureUri!=null)uris=new Uri[]{captureUri};else if(data!=null&&data.getClipData()!=null){ClipData clip=data.getClipData();ArrayList<Uri> list=new ArrayList<>();for(int i=0;i<Math.min(50,clip.getItemCount());i++)if("content".equals(clip.getItemAt(i).getUri().getScheme()))list.add(clip.getItemAt(i).getUri());uris=list.toArray(new Uri[0]);}else if(data!=null&&data.getData()!=null&&"content".equals(data.getData().getScheme()))uris=new Uri[]{data.getData()};}
      captureUri=null;finishChooser(uris);
    }else if(request==EXPORT){
      File file;String name;synchronized(bridge){file=bridge.exportFile;name=bridge.exportName;bridge.exportFile=null;bridge.exportName=null;bridge.exportId=null;bridge.awaitingSave=false;}
      if(file==null)return;
      if(result!=RESULT_OK||data==null||data.getData()==null){file.delete();status("Export cancelled. Your drawing is still saved in Field Notes.");return;}
      final Uri destination=data.getData();final String filename=name;
      filesWorker.execute(()->{try(InputStream in=new FileInputStream(file);OutputStream out=getContentResolver().openOutputStream(destination,"w")){if(out==null)throw new IOException();byte[] buf=new byte[65536];int n;while((n=in.read(buf))!=-1)out.write(buf,0,n);out.flush();status("Saved "+filename);toast("Saved "+filename);}catch(Exception e){status("Export could not be saved. Check storage space and retry.");toast("Export could not be saved.");}finally{file.delete();}});
    }
  }

  private void voiceEvent(String id,String phase,String text){js("window.fieldNotesAndroidSpeech&&window.fieldNotesAndroidSpeech("+JSONObject.quote(id)+","+JSONObject.quote(phase)+","+JSONObject.quote(text==null?"":text)+")");}
  private void cancelVoice(String id){if(voiceId==null||id!=null&&!voiceId.equals(id))return;String previous=voiceId;voiceId=null;timer.removeCallbacksAndMessages(null);if(recognizer!=null){recognizer.cancel();recognizer.destroy();recognizer=null;}voiceEvent(previous,"cancelled","");}
  private void startVoice(String id,String language){
    cancelVoice(null);voiceId=id;voiceLanguage="vi-VN".equals(language)?"vi-VN":"en-US";
    if(!SpeechRecognizer.isRecognitionAvailable(this)){voiceEvent(id,"error","No speech service is installed. Install or enable Google's Speech Recognition service, or type this note.");voiceId=null;return;}
    if(!getPreferences(0).getBoolean("speechConsent",false)){
      new AlertDialog.Builder(this).setTitle("Use phone speech recognition?").setMessage("Field Notes saves the transcript, not the recording. Your phone's speech provider may process audio online under its own privacy settings. Offline recognition is requested, but the provider decides whether it is available. No paid AI API is used by Field Notes.").setPositiveButton("Continue",(d,w)->{if(!id.equals(voiceId))return;getPreferences(0).edit().putBoolean("speechConsent",true).apply();checkMicrophone(id);}).setNegativeButton("Cancel",(d,w)->cancelVoice(id)).setOnCancelListener(d->cancelVoice(id)).show();
    }else checkMicrophone(id);
  }
  private void checkMicrophone(String id){if(!id.equals(voiceId))return;if(checkSelfPermission(Manifest.permission.RECORD_AUDIO)!=PackageManager.PERMISSION_GRANTED)requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO},MIC);else listen(id);}
  @Override public void onRequestPermissionsResult(int request,String[] permissions,int[] granted){super.onRequestPermissionsResult(request,permissions,granted);if(request==MIC&&voiceId!=null){if(granted.length>0&&granted[0]==PackageManager.PERMISSION_GRANTED)listen(voiceId);else{voiceEvent(voiceId,"error","Microphone access was denied. Enable it in Android Settings > Apps > Field Notes Test > Permissions, or type your note.");voiceId=null;}}}
  private void listen(String id){
    if(!id.equals(voiceId))return;
    try{
      if(recognizer!=null){recognizer.destroy();recognizer=null;}
      recognizer=SpeechRecognizer.createSpeechRecognizer(this);
      recognizer.setRecognitionListener(new RecognitionListener(){
        private boolean active(){return id.equals(voiceId);}
        public void onReadyForSpeech(Bundle params){if(active())voiceEvent(id,"ready","");}
        public void onBeginningOfSpeech(){}
        public void onRmsChanged(float rms){if(active())voiceEvent(id,"level",String.valueOf(Math.max(0,Math.min(1,(rms+2)/12))));}
        public void onBufferReceived(byte[] buffer){}
        public void onEndOfSpeech(){if(active()){voiceEvent(id,"processing","");deadline(id);}}
        public void onError(int error){if(!active())return;String message;
          switch(error){case SpeechRecognizer.ERROR_NO_MATCH:case SpeechRecognizer.ERROR_SPEECH_TIMEOUT:message="No speech was recognized. Tap Start voice and try a short sentence.";break;case SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS:message="The speech service needs microphone permission.";break;case SpeechRecognizer.ERROR_NETWORK:case SpeechRecognizer.ERROR_NETWORK_TIMEOUT:message="The phone's speech service needs a connection or an offline language pack.";break;case SpeechRecognizer.ERROR_RECOGNIZER_BUSY:message="The speech service is busy. Wait a moment and retry.";break;default:message="Phone speech service error "+error+". Retry, or type this note.";}
          voiceEvent(id,"error",message);cancelVoice(id);
        }
        public void onResults(Bundle results){if(!active())return;ArrayList<String> values=results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);voiceEvent(id,"final",values==null||values.isEmpty()?"":values.get(0));cancelVoice(id);}
        public void onPartialResults(Bundle partial){if(!active())return;ArrayList<String> values=partial.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);if(values!=null&&!values.isEmpty())voiceEvent(id,"partial",values.get(0));}
        public void onEvent(int type,Bundle params){}
      });
      Intent request=new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);request.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);request.putExtra(RecognizerIntent.EXTRA_LANGUAGE,voiceLanguage);request.putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true);request.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1);request.putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true);request.putExtra("android.speech.extra.ENABLE_FORMATTING","quality");request.putExtra("android.speech.extra.HIDE_PARTIAL_TRAILING_PUNCTUATION",true);request.putStringArrayListExtra("android.speech.extra.BIASING_STRINGS",new ArrayList<>(Arrays.asList("sill","jamb","mullion","CMU","soffit","parapet","flashing","spalling","efflorescence","RTU","HAZMAT","sealant","arch window","fire stopping","curtain wall")));recognizer.startListening(request);
      timer.postDelayed(()->{if(id.equals(voiceId)&&recognizer!=null){recognizer.stopListening();voiceEvent(id,"processing","");deadline(id);}},55000);
    }catch(Exception e){voiceEvent(id,"error","The phone speech service could not start. Check that it is enabled in Android settings.");cancelVoice(id);}
  }
  private void deadline(String id){timer.removeCallbacksAndMessages(null);timer.postDelayed(()->{if(id.equals(voiceId)){voiceEvent(id,"error","The speech service did not return a final transcript. Retry a shorter sentence.");cancelVoice(id);}},20000);}

  public final class Bridge {
    @JavascriptInterface public void closeReady(){runOnUiThread(()->{if(trusted())finish();});}
    private String exportId,exportName,exportMime;private File exportFile;private OutputStream output;private long expected,written;private boolean awaitingSave;
    @JavascriptInterface public void startSpeech(String id,String language){if(id!=null&&id.matches("voice-[0-9-]{1,55}"))runOnUiThread(()->{if(trusted())startVoice(id,language);});}
    @JavascriptInterface public void stopSpeech(String id){runOnUiThread(()->{if(trusted()&&id!=null&&id.equals(voiceId)&&recognizer!=null){voiceEvent(id,"processing","");recognizer.stopListening();deadline(id);}});}
    @JavascriptInterface public void cancelSpeech(String id){runOnUiThread(()->cancelVoice(id));}
    @JavascriptInterface public synchronized boolean beginExport(String id,String name,String mime,long size){
      if(exportId!=null||id==null||!id.matches("export-[0-9-]{1,55}")||size<1||size>134217728L||name==null||name.length()>160||name.matches(".*[\\\\/:*?\"<>|\\p{Cntrl}].*")||!name.matches(".*\\.(pdf|pptx|zip|html)"))return false;
      String valid=name.endsWith(".pdf")?"application/pdf":name.endsWith(".pptx")?"application/vnd.openxmlformats-officedocument.presentationml.presentation":name.endsWith(".zip")?"application/zip":"text/html";
      try{File dir=new File(getCacheDir(),"exports");dir.mkdirs();exportFile=File.createTempFile("export-",".tmp",dir);output=new FileOutputStream(exportFile);exportId=id;exportName=name;exportMime=valid;expected=size;written=0;return true;}catch(IOException error){abortExport(id);return false;}
    }
    @JavascriptInterface public synchronized boolean appendExport(String id,String chunk){if(!Objects.equals(id,exportId)||output==null||chunk==null||chunk.length()>350000)return false;try{byte[] bytes=Base64.decode(chunk,Base64.DEFAULT);if(written+bytes.length>expected)throw new IOException();output.write(bytes);written+=bytes.length;return true;}catch(Exception e){abortExport(id);return false;}}
    @JavascriptInterface public synchronized boolean finishExport(String id){if(!Objects.equals(id,exportId)||output==null||written!=expected)return false;try{output.close();output=null;awaitingSave=true;runOnUiThread(()->{if(!trusted()){abortExport(id);return;}Intent create=new Intent(Intent.ACTION_CREATE_DOCUMENT);create.addCategory(Intent.CATEGORY_OPENABLE);create.setType(exportMime);create.putExtra(Intent.EXTRA_TITLE,exportName);try{startActivityForResult(create,EXPORT);}catch(Exception e){abortExport(id);status("No Save file picker was found on this phone.");}});return true;}catch(IOException e){abortExport(id);return false;}}
    @JavascriptInterface public synchronized void abortExport(String id){if(!Objects.equals(id,exportId)&&exportId!=null)return;try{if(output!=null)output.close();}catch(IOException ignored){}output=null;if(exportFile!=null)exportFile.delete();exportFile=null;exportId=null;awaitingSave=false;}
  }
  @Override public void onBackPressed(){if(web==null){finish();return;}web.evaluateJavascript("window.fieldNotesAndroidBack?window.fieldNotesAndroidBack():false",value->{if(!"true".equals(value))new AlertDialog.Builder(this).setMessage("Close Field Notes? Saved drawings stay on this phone.").setPositiveButton("Close",(d,w)->{web.evaluateJavascript("Promise.resolve().then(()=>tabletPersist()).then(()=>FieldNotesNative.closeReady()).catch(()=>window.fieldNotesAndroidExportStatus('Could not save the drawing. Keep the app open and export a backup.'))",null);}).setNegativeButton("Stay",null).show();});}
  @Override protected void onPause(){if(web!=null&&trusted())web.evaluateJavascript("if(typeof tabletPersist==='function')tabletPersist()",null);super.onPause();}
  @Override protected void onStop(){cancelVoice(null);super.onStop();}
  @Override protected void onDestroy(){destroyed=true;cancelVoice(null);finishChooser(null);if(!isChangingConfigurations())bridge.abortExport(bridge.exportId);filesWorker.shutdown();if(web!=null){web.removeJavascriptInterface("FieldNotesNative");web.destroy();web=null;}super.onDestroy();}
}
