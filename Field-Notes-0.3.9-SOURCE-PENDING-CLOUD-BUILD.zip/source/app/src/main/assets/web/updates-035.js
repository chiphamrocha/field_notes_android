'use strict';
// Clear stale pointer state at form boundaries without blurring or blocking handwriting.
for(const event of ['focusin','focusout','pointerup','pointercancel'])$('entry').addEventListener(event,e=>{
 if(e.type==='pointerup'||e.type==='pointercancel'){window.tabletPenDown=false;return;}
 if(typeof fnResetInput==='function')fnResetInput();
});
// A new pen pointerdown proves the previous pen contact has ended.
document.addEventListener('pointerdown',e=>{if(e.pointerType==='pen'&&!e.buttons){window.tabletPenDown=false;}},true);
// Separate, locally generated PDF report. Each attachment retains its location tag ID.
const reportPdfButton=document.createElement('button');reportPdfButton.id='exportPhotoLogPdf';reportPdfButton.textContent='Export report (.pdf)';$('exportPhotoLog').after(reportPdfButton);
async function fieldNotesBuildReportPdf(items,metadata){
 const doc=await PDFLib.PDFDocument.create();doc.registerFontkit(fontkit);
 const response=await fetch('vendor/fonts/DejaVuSans.ttf');if(!response.ok)throw Error('The report font is unavailable.');
 const font=await doc.embedFont(new Uint8Array(await response.arrayBuffer()),{subset:true}),size=10,margin=36,width=540;
 for(let index=0;index<items.length;index++){
  const item=items[index],id=fieldNotesPhotoId(item.number,metadata),imageIndex=items.filter((x,i)=>i<=index&&x.sourcePage===item.sourcePage&&x.number===item.number).length;
  const photoBytes=new Uint8Array(await (await fetch(item.photo.dataUrl)).arrayBuffer());let image;
  if(item.photo.dataUrl.startsWith('data:image/png'))image=await doc.embedPng(photoBytes);
  else if(item.photo.dataUrl.startsWith('data:image/jpeg'))image=await doc.embedJpg(photoBytes);
  else {const bitmap=await createImageBitmap(new Blob([photoBytes],{type:item.photo.type})),canvas=document.createElement('canvas');canvas.width=bitmap.width;canvas.height=bitmap.height;canvas.getContext('2d').drawImage(bitmap,0,0);bitmap.close();image=await doc.embedPng(new Uint8Array(await(await fetch(canvas.toDataURL('image/png'))).arrayBuffer()));}
  let page,y;
  const start=(continued=false)=>{page=doc.addPage([612,792]);y=756;page.drawText((metadata.visitType==='punch'?'Punch Walk':'Photo Log')+(continued?' (continued)':''),{x:margin,y,font,size:16});y-=24;page.drawText('Photo '+id+' · image '+imageIndex+' · drawing page '+item.sourcePage,{x:margin,y,font,size});y-=20;};
  start();
  const scale=Math.min(width/image.width,340/image.height);page.drawImage(image,{x:margin+(width-image.width*scale)/2,y:y-image.height*scale,width:image.width*scale,height:image.height*scale});y-=image.height*scale+20;
  const text=[['Project',[metadata.projectNumber,metadata.projectName,metadata.site].filter(Boolean).join(' · ')],['Date',metadata.date],['Location',item.location],['Caption',item.description],['Disposition',item.disposition]];
  for(const [label,value]of text){if(!value)continue;for(const line of fieldNotesPdf.wrap(label+': '+value,font,size,width)){if(y<margin+size)start(true);page.drawText(line,{x:margin,y,font,size});y-=15;}y-=6;}
 }
 return doc.save();
}
reportPdfButton.onclick=async()=>{
 const status=$('photoLogStatus');if(pending||tablet.active||tablet.restoring||loadingPage){status.textContent='Finish the current action before exporting.';return;}
 reportPdfButton.disabled=true;status.textContent='Preparing PDF report…';
 try{const items=tabletPhotoLogItems();if(!items.length)throw Error('Add a photo before exporting.');const bytes=await fieldNotesBuildReportPdf(items,photoLogMetadata);const saved=await downloadBlob(new Blob([bytes],{type:'application/pdf'}),fieldNotesExportName(photoLogMetadata.visitType==='punch'?'Punch List':'Photo Log','pdf'));status.textContent=saved?'PDF report prepared. Complete the device Save dialog to keep it.':'Export cancelled.';}catch(error){status.textContent='Export failed: '+error.message;}finally{reportPdfButton.disabled=false;}
};
