 'use strict';
/* Field Notes 0.3.4. Fixed geometry and fixed lettering for all numbered pins.
   Do not use content-dependent scaling; the longest supported ID is A999. */
(()=>{
 const originalMark=markSvg;
 markSvg=function(mark,style,printing=false){
  if(!['note','voice'].includes(mark?.kind))return originalMark(mark,style,printing);
  const s=style||screenStyle(),r=s.pinRadius*1.35,x=mark.x,y=mark.y-s.pinRadius*2;
  const photo=tabletNoteType(mark)==='photo',color=photo?'#c45b36':'#285f70';
  const text=photo?fieldNotesPhotoId(mark.number):String(mark.number);
  // Preserve the existing photo-circle diameter. The note hexagon matches its height.
  // Fixed glyph size sized for four characters, identical for A1, A02, A100 and A999.
  const font=Math.min(s.numberSize, r*0.55);
  const shape=photo?`<circle cx="${x}" cy="${y}" r="${r}" fill="${color}"/>`:
   `<polygon points="${Array.from({length:6},(_,i)=>{const a=Math.PI/2+i*Math.PI/3;return `${x+r*Math.cos(a)},${y+r*Math.sin(a)}`;}).join(' ')}" fill="${color}"/>`;
  return `<g><path d="M ${x} ${mark.y} L ${x} ${y}" stroke="${color}" stroke-width="${s.strokeWidth||2}"/>${shape}<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="central" font-family="Arial, sans-serif" font-weight="500" font-size="${font}" fill="white">${escapeText(text)}</text></g>`;
 };
 // Preserve raw transcription internally but remove confusing restoration control.
 const restore=$('restoreDictation');if(restore){restore.hidden=true;restore.setAttribute('aria-hidden','true');
 new MutationObserver(()=>{if(!restore.hidden)restore.hidden=true;}).observe(restore,{attributes:true,attributeFilter:['hidden']});}
 // Clear abandoned pen/gesture state after a dictation session ends.
 // This is a candidate mitigation; Samsung hardware verification is still required.
 const status=$('voiceStatus');if(status){new MutationObserver(()=>{
   if(window.fnSpeechBusy===false&&typeof fnResetInput==='function')fnResetInput();
 }).observe(status,{childList:true,characterData:true,subtree:true});}
})();
