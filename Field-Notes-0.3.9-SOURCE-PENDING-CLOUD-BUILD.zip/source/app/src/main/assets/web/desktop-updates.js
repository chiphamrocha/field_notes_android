'use strict';
// One-step vector PDF. PDF.js supplies the exact crop/rotation transform used on screen.
$('exportVectorPdf').onclick=async()=>{
  const status=$('vectorPdfStatus'),button=$('exportVectorPdf');
  if(pending||gesture||action||tablet.active||tablet.restoring||loadingPage){status.textContent='Finish or cancel the current action before exporting.';return;}
  button.disabled=true;status.textContent='Preparing vector PDF…';
  try{
    savePage();tabletAssignPhotoNumbers();
    const records=pages.map(page=>({...page,marks:page.marks.map(mark=>({...mark}))}));
    let sourceKind='sample',sourceBytes,imageBytes,imageType;
    if(sourceFile&&(/\.pdf$/i.test(sourceFile.name)||sourceFile.type==='application/pdf')){
      sourceKind='pdf';sourceBytes=new Uint8Array(await sourceFile.arrayBuffer());
      if(!pdfDoc)throw Error('The original PDF is not ready. Reopen the saved drawing and retry.');
      for(let i=0;i<records.length;i++){const page=await pdfDoc.getPage(i+1),view=page.getViewport({scale:1,rotation:(page.rotate+(records[i].rotation||0))%360});records[i].viewport={width:view.width,height:view.height,transform:[...view.transform]};}
    }else if(sourceFile){
      sourceKind='image';imageType=sourceFile.type;
      if(['image/jpeg','image/png'].includes(imageType))imageBytes=new Uint8Array(await sourceFile.arrayBuffer());
      else{imageType='image/jpeg';imageBytes=new Uint8Array(await (await fetch(pages[0].background)).arrayBuffer());}
    }
    const fontResponse=await fetch('vendor/fonts/DejaVuSans.ttf');if(!fontResponse.ok)throw Error('The PDF text font could not be loaded.');
    const bytes=await window.fieldNotesPdf.build({sourceKind,sourceBytes,imageBytes,imageType,pages:records,metadata:{...photoLogMetadata},fontBytes:new Uint8Array(await fontResponse.arrayBuffer()),fontkit:window.fontkit});
    const saved=await downloadBlob(new Blob([bytes],{type:'application/pdf'}),fieldNotesExportName('Field Notes Annotated','pdf'));
    status.textContent=saved?'Vector PDF prepared. Complete the device Save dialog.':'Export cancelled. Your drawing is still saved.';
  }catch(error){status.textContent='PDF export failed: '+error.message;}
  finally{button.disabled=false;}
};

// Photo captions may be blank; the photo itself may not.
function tabletPhotoRequired(){
  if(pending&&tabletNoteType(pending)==='photo'&&!pending.photos?.length){$('notePhotoStatus').textContent='Attach or take at least one photo before saving this photo pin.';return true;}
  return false;
}
$('saveEntry').addEventListener('click',event=>{if(tabletPhotoRequired())event.preventDefault();});

// Keep previous drawings in the existing device database; opening another file cannot replace the only copy.
function tabletArchivedRecord(){savePage();return {version:1,projectDetailsSeen,documentId:tabletDocumentId,numberingScheme:'global-v1',reportMetadata:{...photoLogMetadata},file:sourceFile,fileName:sourceFile?.name,pages,pageIndex,settings:{width:tablet.width,color:tablet.color,smooth:tablet.smooth,penOnly:tablet.penOnly},updated:Date.now()};}
function tabletReadStored(key){return tabletDatabase().then(db=>new Promise((resolve,reject)=>{const request=db.transaction('drafts').objectStore('drafts').get(key);request.onsuccess=()=>resolve(request.result);request.onerror=()=>reject(request.error);}));}
async function tabletArchiveCurrent(){
  clearTimeout(saveTimer);const deadline=Date.now()+8000;while(saveBusy){if(Date.now()>deadline)throw Error('The current drawing is still saving. Wait, then retry.');await new Promise(resolve=>setTimeout(resolve,30));}
  const record=tabletArchivedRecord(),db=await tabletDatabase();
  await new Promise((resolve,reject)=>{const tx=db.transaction('drafts','readwrite'),store=tx.objectStore('drafts');store.put(record,'drawing:'+record.documentId);store.put({id:record.documentId,name:record.fileName||'Sample plan',updated:record.updated,pageCount:record.pages.length,project:record.reportMetadata.projectNumber||record.reportMetadata.site||''},'index:'+record.documentId);tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);});
}
const desktopLoadFile=loadFile;
loadFile=async function(file){
  if(loadingPage||pending||tablet.restoring)return;
  tabletCancelInk();
  try{await tabletArchiveCurrent();}catch(error){$('fileStatus').textContent='Could not save the current drawing. Opening another file was stopped: '+error.message;return;}
  const result=await desktopLoadFile(file);
  if(result){tabletDocumentId=tabletNewDocumentId();await tabletPersist();}
  return result;
};
async function tabletSavedIndexes(){const db=await tabletDatabase();return new Promise((resolve,reject)=>{const values=[],request=db.transaction('drafts').objectStore('drafts').openCursor();request.onsuccess=()=>{const cursor=request.result;if(!cursor){resolve(values);return;}if(String(cursor.key).startsWith('index:'))values.push(cursor.value);cursor.continue();};request.onerror=()=>reject(request.error);});}
async function tabletOpenSavedDrawing(id){
  if(id===tabletDocumentId){$('savedDrawingsSheet').close();return;}
  const status=$('savedDrawingsStatus');
  try{
    await tabletArchiveCurrent();
    const record=await tabletReadStored('drawing:'+id);if(!record?.pages?.length)throw Error('This saved drawing could not be found.');
    loadingPage=true;status.textContent='Opening saved drawing…';let nextPdf=null;
    const nextFile=record.file&&record.fileName&&!record.file.name?new File([record.file],record.fileName,{type:record.file.type}):record.file;
    if(nextFile&&(/\.pdf$/i.test(nextFile.name)||nextFile.type==='application/pdf')){const lib=await pdfLibrary();nextPdf=await lib.getDocument({data:new Uint8Array(await nextFile.arrayBuffer()),cMapUrl:new URL('./vendor/cmaps/',location.href).href,cMapPacked:true,standardFontDataUrl:new URL('./vendor/standard_fonts/',location.href).href}).promise;}
    const previousPdf=pdfDoc;sourceFile=nextFile;pdfDoc=nextPdf;pages=record.pages;pageIndex=clamp(record.pageIndex||0,0,pages.length-1);tabletDocumentId=record.documentId||id;
    Object.assign(photoLogMetadata,{discipline:'architectural',client:'',site:'',projectNumber:'',date:'',projectName:'',phase:'',visitType:'site'},record.reportMetadata||{});projectDetailsSeen=record.projectDetailsSeen===true;
    Object.assign(lab,{marks:pages[pageIndex].marks,view:{...pages[pageIndex].view},cursor:{...pages[pageIndex].cursor},background:pages[pageIndex].background});Object.assign(tablet,record.settings||{});
    $('inkWidth').value=String(tablet.width);$('inkColor').value=tablet.color;$('inkSmooth').value=String(tablet.smooth);$('penOnly').checked=tablet.penOnly;tablet.revision++;pageUi();tabletRender();await tabletPersist();
    if(previousPdf)previousPdf.destroy().catch(()=>{});
    $('savedDrawingsSheet').close();$('fileStatus').textContent='Saved drawing reopened.';
  }catch(error){status.textContent='Could not open drawing: '+error.message;}
  finally{loadingPage=false;}
}
async function tabletRefreshSavedDrawings(){
  const items=(await tabletSavedIndexes()).sort((a,b)=>b.updated-a.updated);
  $('savedDrawingsList').innerHTML=items.map(item=>'<article class="savedDrawingRow"><div class="savedDrawingActions"><button type="button" data-saved-drawing="'+escapeText(item.id)+'">'+escapeText(item.name)+(item.id===tabletDocumentId?' · Current':'')+'</button><button type="button" class="deleteDrawing" data-delete-drawing="'+escapeText(item.id)+'" aria-label="Delete '+escapeText(item.name)+'">Delete</button></div><p>'+escapeText(item.project)+' · '+item.pageCount+' page(s) · '+escapeText(new Date(item.updated).toLocaleString())+'</p></article>').join('');
}
async function tabletDeleteSavedDrawing(id){
  if(loadingPage||pending||tablet.active)return;
  const status=$('savedDrawingsStatus'),record=await tabletReadStored('drawing:'+id);
  if(!record){status.textContent='This saved drawing no longer exists.';await tabletRefreshSavedDrawings();return;}
  if(!confirm('Delete "'+(record.fileName||'Sample plan')+'" and its notes, photos and sketches from Field Notes? This cannot be undone. The original PDF/photo and exported files will not be deleted.'))return;
  clearTimeout(saveTimer);const deadline=Date.now()+8000;while(saveBusy){if(Date.now()>deadline)throw Error('The drawing is still saving. Wait and retry.');await new Promise(resolve=>setTimeout(resolve,30));}
  saveQueued=false;const isCurrent=id===tabletDocumentId,db=await tabletDatabase();
  await new Promise((resolve,reject)=>{const tx=db.transaction('drafts','readwrite'),store=tx.objectStore('drafts');store.delete('drawing:'+id);store.delete('index:'+id);if(isCurrent)store.delete('current');tx.oncomplete=resolve;tx.onerror=()=>reject(tx.error);tx.onabort=()=>reject(tx.error);});
  if(isCurrent){
    if(pdfDoc)pdfDoc.destroy().catch(()=>{});pdfDoc=null;sourceFile=null;pages=[emptyPage()];pageIndex=0;tabletDocumentId=tabletNewDocumentId();
    Object.assign(lab,{marks:pages[0].marks,view:{...pages[0].view},cursor:{...pages[0].cursor},background:null});Object.assign(photoLogMetadata,{discipline:'architectural',client:'',site:'',projectNumber:'',date:'',projectName:'',phase:'',visitType:'site'});tablet.revision++;tablet.mode='pan';pageUi();tabletRender();await tabletPersist();
  }
  await tabletRefreshSavedDrawings();status.textContent='Drawing deleted from Field Notes. Original files and exports were kept.';
}
$('savedDrawings').onclick=async()=>{
  if(pending||tablet.active||loadingPage)return;tabletCancelInk();$('phoneMenu').close();$('savedDrawingsSheet').showModal();const status=$('savedDrawingsStatus');status.textContent='Saving current drawing…';
  try{await tabletArchiveCurrent();await tabletRefreshSavedDrawings();status.textContent='Saved on this PC in the app database. Use Delete here to remove a drawing; export important work for a separate backup.';}catch(error){status.textContent='Could not list saved drawings: '+error.message;}
};
$('exportNotesMenu').onclick=()=>{$('exportNotes').onclick();};
$('closeSavedDrawings').onclick=()=>$('savedDrawingsSheet').close();
$('savedDrawingsList').addEventListener('click',event=>{
  const remove=event.target.closest('[data-delete-drawing]');
  if(remove){tabletDeleteSavedDrawing(remove.dataset.deleteDrawing).catch(error=>{$('savedDrawingsStatus').textContent='Could not delete drawing: '+error.message;});return;}
  const button=event.target.closest('[data-saved-drawing]');if(button)tabletOpenSavedDrawing(button.dataset.savedDrawing);
});
