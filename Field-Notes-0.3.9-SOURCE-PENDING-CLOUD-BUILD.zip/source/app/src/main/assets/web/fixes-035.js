 'use strict';
/* v0.3.5: pins use stable plan-space dimensions, never inverse-zoom sizing. */
(()=>{
 const pin=markSvg;
 const FONT=8.5, CIRCLE=16, HEX=17.5;
 markSvg=function(mark,style,printing=false){
   if(!['note','voice'].includes(mark?.kind))return pin(mark,style,printing);
   const photo=tabletNoteType(mark)==='photo',r=photo?CIRCLE:HEX;
   const x=mark.x,y=mark.y-r*1.8;
   const color=photo?'#c45b36':'#285f70';
   const value=photo?fieldNotesPhotoId(mark.number):String(mark.number);
   const shape=photo?`<circle cx="${x}" cy="${y}" r="${r}" fill="${color}"/>`:
     `<polygon points="${Array.from({length:6},(_,i)=>{const a=Math.PI/6+i*Math.PI/3;return `${x+r*Math.cos(a)},${y+r*Math.sin(a)}`}).join(' ')}" fill="${color}"/>`;
   return `<g><path d="M ${x} ${mark.y} L ${x} ${y}" stroke="${color}" stroke-width="1.6"/>${shape}<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="central" font-family="Arial,sans-serif" font-weight="500" font-size="${FONT}" fill="white">${escapeText(value)}</text></g>`;
 };
 const previous=showEntry;
 showEntry=function(...args){
   previous(...args);
   const photo=tabletNoteType(pending)==='photo';
   $('entryLabel').textContent=photo?'Photo caption: Type, write, or dictate.':'Note text: Type, write, or dictate.';
   $('voice').textContent='Record';$('stopVoice').textContent='Stop';
   $('voiceStatus').textContent='Tap Record, speak, then tap Stop. Review the text before saving.';
 };
 // Restore accurate wording after asynchronous speech status changes is handled by speech UI.
})();
