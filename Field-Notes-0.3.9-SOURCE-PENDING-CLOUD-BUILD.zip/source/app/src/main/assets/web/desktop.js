'use strict';
// The tested drawing/report engine is shared with the tablet; this file adds desktop input only.
const desktopShowEntry = showEntry;
showEntry = function(...args) {
  desktopShowEntry(...args);
  $('voiceStatus').textContent = 'Tap Dictate to open Windows voice typing. You can also click the text box and press Windows+H. Review the text before saving.';
};
let desktopSpace = false, desktopPan = null;
function desktopEditing() { return ['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName) || document.activeElement?.isContentEditable; }
document.addEventListener('keydown', event => {
  if (event.key === ' ' && !desktopEditing() && !dialogsOpen()) { desktopSpace = true; event.preventDefault(); }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'o' && !pending) { event.preventDefault(); $('photo').click(); }
  if ((event.ctrlKey || event.metaKey) && event.key.toLowerCase() === 'z' && !desktopEditing() && !dialogsOpen()) {
    event.preventDefault(); (event.shiftKey ? $('tabletRedo') : $('undo')).click();
  }
});
document.addEventListener('keyup', event => { if (event.key === ' ') desktopSpace = false; });
window.addEventListener('blur', () => { desktopSpace = false; desktopPan = null; });
$('viewport').addEventListener('wheel', event => {
  if (dialogsOpen() || loadingPage || pending || tablet.active) return;
  event.preventDefault();
  const frame = inputFrame(), anchor = point(event), before = {...lab.view};
  const delta = event.deltaY * (event.deltaMode === 1 ? 16 : event.deltaMode === 2 ? frame.height : 1);
  const w = clamp(before.w * Math.exp(clamp(delta,-500,500)*0.0015),80,Math.min(1000,700/(before.h/before.w)));
  const h = w * before.h/before.w;
  lab.view = paddedView(anchor.x - (event.clientX-frame.left)/frame.width*w,anchor.y-(event.clientY-frame.top)/frame.height*h,w,h);
  update(); tabletSaveSoon();
}, {passive:false});
document.addEventListener('pointerdown', event => {
  if (!$('viewport').contains(event.target)) return;
  if (dialogsOpen() || loadingPage || pending || !(event.button === 1 || (desktopSpace && event.button === 0))) return;
  event.preventDefault(); event.stopImmediatePropagation(); tabletCancelInk();
  desktopPan = {id:event.pointerId,x:event.clientX,y:event.clientY}; $('viewport').setPointerCapture(event.pointerId);
}, {capture:true});
document.addEventListener('pointermove', event => {
  if (!desktopPan || desktopPan.id !== event.pointerId) return;
  event.preventDefault(); event.stopImmediatePropagation();
  const frame = inputFrame(), v = lab.view;
  lab.view = paddedView(v.x-(event.clientX-desktopPan.x)*v.w/frame.width,v.y-(event.clientY-desktopPan.y)*v.h/frame.height,v.w,v.h);
  desktopPan.x=event.clientX; desktopPan.y=event.clientY; update();
}, {capture:true});
for (const type of ['pointerup','pointercancel','lostpointercapture']) document.addEventListener(type, event => {
  if (!desktopPan || desktopPan.id !== event.pointerId) return;
  event.preventDefault(); event.stopImmediatePropagation(); desktopPan = null; tabletSaveSoon();
}, {capture:true});
$('viewport').addEventListener('auxclick', event => { if (event.button === 1) event.preventDefault(); });

// Webcam capture stays separate from text-note entry and never records audio.
$('takePhoto').onclick = async () => {
  const target = pending;
  if (!target) return;
  const camera = document.createElement('dialog'); camera.className = 'noteSheet';
  camera.innerHTML = '<h2>Take a photo</h2><video autoplay playsinline muted style="width:100%;max-height:55vh;background:#222"></video><p role="status">Opening camera…</p><div class="row"><button type="button" data-close>Cancel</button><button type="button" data-capture disabled>Use photo</button></div>';
  document.body.appendChild(camera);
  const video = camera.querySelector('video'), status = camera.querySelector('p'), capture = camera.querySelector('[data-capture]');
  let stream;
  camera.querySelector('[data-close]').onclick = () => camera.close();
  camera.addEventListener('close', () => { stream?.getTracks().forEach(track => track.stop()); camera.remove(); });
  camera.showModal();
  try {
    stream = await navigator.mediaDevices.getUserMedia({video:true,audio:false});
    if (!camera.open) { stream.getTracks().forEach(track => track.stop()); return; }
    video.srcObject = stream; await video.play(); status.textContent = 'Position the camera, then choose Use photo.'; capture.disabled = false;
    capture.onclick = () => {
      if (pending !== target || !video.videoWidth) { status.textContent = 'Camera is not ready. Retry or cancel.'; return; }
      const canvas = document.createElement('canvas'); canvas.width=video.videoWidth; canvas.height=video.videoHeight;
      canvas.getContext('2d').drawImage(video,0,0);
      target.photos.push({name:'Site-photo-'+Date.now()+'.jpg',type:'image/jpeg',dataUrl:canvas.toDataURL('image/jpeg',0.92)});
      renderNotePhotos(); $('notePhotoStatus').textContent=target.photos.length+' photo(s) attached'; camera.close();
    };
  } catch (error) { status.textContent='Camera unavailable: '+error.message+'. You can attach an existing photo instead.'; }
};
