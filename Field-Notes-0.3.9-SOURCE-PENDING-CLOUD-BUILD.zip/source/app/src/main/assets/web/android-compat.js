'use strict';
// Android 8 can use a current WebView, but some supported versions lack these newer Promise helpers.
if (!Promise.withResolvers) Promise.withResolvers = function () { let resolve, reject; const promise = new this((a,b) => { resolve=a; reject=b; }); return {promise,resolve,reject}; };
if (!Promise.try) Promise.try = function (fn,...args) { return new this(resolve=>resolve(fn(...args))); };
