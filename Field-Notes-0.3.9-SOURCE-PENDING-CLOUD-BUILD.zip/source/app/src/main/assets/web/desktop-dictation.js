'use strict';
// Capture actual microphone samples, flush on Stop, then transcribe locally.
(() => {
  let session=null,sequence=0;
  const level=document.createElement('meter');level.id='voiceInputLevel';level.min=0;level.max=1;level.value=0;level.setAttribute('aria-label','Microphone input level');level.hidden=true;$('voiceStatus').insertAdjacentElement('afterend',level);
  function controls(busy){$('voice').disabled=busy;$('stopVoice').disabled=!busy;for(const id of ['text','photoLocation','disposition'])$(id).readOnly=busy;window.fnSpeechBusy=busy;$('saveEntry').disabled=busy;}
  async function release(current){clearTimeout(current.limit);current.stream?.getTracks().forEach(track=>track.stop());try{current.source?.disconnect();current.node?.disconnect();if(current.context?.state!=='closed')await current.context?.close();}catch{}if(!session||session===current){level.hidden=true;level.value=0;}}
  async function cancel(){const current=session;if(!current)return;session=null;current.cancelled=true;window.fieldNotesDesktop.cancelTranscription(current.id);await release(current);if(!session)controls(false);}
  const previousShowEntry=showEntry;
  showEntry=function(...args){previousShowEntry(...args);$('stopVoice').hidden=false;$('dictationLanguage').parentElement.hidden=false;$('voiceStatus').textContent='Type or speak your note. Start voice records; Stop voice transcribes on this PC. Only the text is kept with the note.';};
  $('voice').onclick=async()=>{
    if(session||!pending)return;
    const current={id:'voice-'+Date.now()+'-'+(++sequence),target:pending,field:window.fnVoiceField(),initial:window.fnVoiceField().value.trim(),chunks:[],samples:0,cancelled:false,stopping:false,limit:null};session=current;controls(true);$('voiceStatus').textContent='Requesting microphone access…';
    try{
      current.stream=await navigator.mediaDevices.getUserMedia({audio:{channelCount:1,echoCancellation:true,noiseSuppression:true,autoGainControl:true},video:false});
      if(session!==current){await release(current);return;}
      current.context=new AudioContext({sampleRate:16000});
      await current.context.audioWorklet.addModule('voice-capture-worklet.js');await current.context.resume();
      if(session!==current){await release(current);return;}
      current.node=new AudioWorkletNode(current.context,'field-notes-capture');current.source=current.context.createMediaStreamSource(current.stream);
      current.node.port.onmessage=event=>{
        if(event.data.samples&&!current.cancelled){const samples=new Float32Array(event.data.samples);current.chunks.push(samples);current.samples+=samples.length;let sum=0;for(const x of samples)sum+=x*x;level.value=Math.min(1,Math.sqrt(sum/samples.length)*4);if(current.samples>=16000*179&&!current.stopping)$('stopVoice').onclick();}
        if(event.data.done)current.flushed?.();
      };
      current.source.connect(current.node);current.node.connect(current.context.destination);level.hidden=false;$('voiceStatus').textContent='Recording… speak, then tap Stop voice to transcribe. The bar shows microphone sound.';
      current.limit=setTimeout(()=>$('stopVoice').onclick(),179000);
    }catch(error){if(session===current){session=null;await release(current);controls(false);$('voiceStatus').textContent='Microphone could not start: '+error.message+'. Check Windows microphone privacy settings.';}}
  };
  $('stopVoice').onclick=async()=>{
    const current=session;if(!current||current.stopping)return;
    if(!current.node){await cancel();$('voiceStatus').textContent='Recording cancelled.';return;}
    current.stopping=true;$('stopVoice').disabled=true;$('voiceStatus').textContent='Finishing recording…';
    try{
      await new Promise((resolve,reject)=>{const timer=setTimeout(()=>reject(Error('The microphone did not finish. Please retry.')),4000);current.flushed=()=>{clearTimeout(timer);resolve();};current.node.port.postMessage('stop');});
      await release(current);if(session!==current)return;
      const audio=window.fieldNotesAudio.encodeWav(current.chunks,current.context.sampleRate);current.chunks=[];
      $('voiceStatus').textContent='Transcribing on this PC… longer notes may take a little time.';
      const result=await window.fieldNotesDesktop.transcribe(current.id,audio,$('dictationLanguage').value==='vi-VN'?'vi':'en');
      if(session!==current||pending!==current.target)return;
      if(result.ok){window.fnSaveDictation(current.field,[current.initial,result.text.trim()].filter(Boolean).join(' '));$('voiceStatus').textContent='Review the text, then Save. Start voice adds another recording.';}
      else $('voiceStatus').textContent=result.error||'No speech was recognized. Try a shorter sentence.';
    }catch(error){if(session===current)$('voiceStatus').textContent=error.message;}
    finally{await release(current);if(session===current){session=null;controls(false);}}
  };
  $('entry').addEventListener('close',()=>cancel());
  window.addEventListener('beforeunload',()=>{if(session)window.fieldNotesDesktop.cancelTranscription(session.id);});
})();
