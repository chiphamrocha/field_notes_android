 'use strict';
/* Field Notes 0.3.6: consistent tag sizes, reliable modal opening, compact editor. */
(()=>{
 // Show the true number-only tag without redundant Note/Photo prefixes.
 // Pin dimensions are in drawing coordinates, not screen pixels.
 // Diameter follows print geometry; no fixed-pixel marker overlays.
 const fn036OriginalMark=markSvg;
 markSvg=function(mark,style,printing=false){
   if(!['note','voice'].includes(mark?.kind))return fn036OriginalMark(mark,style,printing);
   const R=Math.max(1,Number(style?.pinRadius)||5), photo=tabletNoteType(mark)==='photo', x=mark.x,y=mark.y-R*1.8;
   const color=photo?'#c45b36':'#285f70';
   const value=photo?fieldNotesPhotoId(mark.number):String(mark.number);
   const FONT=Math.min(R*.95,R*1.8/(Math.max(1,String(value).length)*.62));
   const shape=photo?`<circle cx="${x}" cy="${y}" r="${R}" fill="${color}"/>`:
     `<polygon points="${Array.from({length:6},(_,i)=>{const a=Math.PI/6+i*Math.PI/3;return `${x+R*Math.cos(a)},${y+R*Math.sin(a)}`}).join(' ')}" fill="${color}"/>`;
   return `<g><path d="M ${x} ${mark.y} L ${x} ${y}" stroke="${color}" stroke-width="1.6"/>${shape}<text x="${x}" y="${y}" text-anchor="middle" dominant-baseline="central" font-family="Arial,sans-serif" font-weight="500" font-size="${FONT}" fill="white">${escapeText(value)}</text></g>`;
 };
 // Retain original implementation for other geometry.
 const priorShow=showEntry;
 showEntry=function(...args){
   priorShow(...args);
   const mark=pending;
   if(!mark)return;
   const type=tabletNoteType(mark);
   $('entryLabel').textContent=mark.kind==='dim'?'Measured value, including units':mark.kind==='text'?'Text shown on the plan':type==='photo'?'Photo caption: Type, write, or dictate.':'Note: Type, write, or dictate.';
   $('voiceStatus').textContent='Tap Record, speak, then Stop. Review before saving.';
   $('voice').textContent='Record';$('stopVoice').textContent='Stop';
   const target=$('entry');target.scrollTop=0;
 };
 // A dialog opened by pointer release must not receive that gesture's click,
 // even when Android delays the compatibility click. A new down inside the
 // editor authorizes a distinct gesture; keyboard activation remains available.
 let editorPointerReady=false;
 const originalShow=showEntry;
 showEntry=function(...args){editorPointerReady=false;originalShow(...args);};
 $('entry').addEventListener('pointerdown',()=>{editorPointerReady=true;},true);
 $('entry').addEventListener('click',e=>{
   if(!editorPointerReady && e.detail!==0 && e.target.closest('button')){
     e.preventDefault();e.stopImmediatePropagation();
   }
 },true);
 // Re-enable the pen immediately after microphone completion, without resetting
 // an actively drawn stroke or changing the user's selected tool.
 const status=$('voiceStatus');
 if(status)new MutationObserver(()=>{
   if(window.fnSpeechBusy===false && !tablet.active && pending?.kind!=='dim'){
     window.tabletPenDown=false;
   }
 }).observe(status,{childList:true,subtree:true});
 // The hidden legacy language and restore controls are deliberately inaccessible.
 $('dictationLanguage').hidden=true;
 $('restoreDictation').hidden=true;
})();
