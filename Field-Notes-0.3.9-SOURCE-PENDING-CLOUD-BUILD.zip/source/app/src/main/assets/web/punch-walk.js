/* Editable OOXML report using the existing firm package/logo and the supplied punch-list layout. */
(function(root){
'use strict';
const E=v=>String(v??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&apos;'}[c]));
const emu=n=>Math.round(n*914400);
const disciplines={architectural:'Architecture',mechanical:'Mechanical',electrical:'Electrical',fireProtection:'Fire Protection'};
const prefixes={architectural:'A',mechanical:'M',electrical:'E',fireProtection:'F'};
function identifier(n,meta){return (prefixes[meta.discipline]||'A')+String(n).padStart(2,'0');}
function heading(meta){return 'PUNCH LIST: '+[meta.phase?.trim(),(disciplines[meta.discipline]||'Architecture').toUpperCase()].filter(Boolean).join(' - ');}
function text(id,name,value,x,y,w,h,size=9,bold=false){const count=String(value).split('\n').length;size=Math.min(size,h*72/(count*1.15));return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="${E(name)}"/><p:cNvSpPr txBox="1"/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${emu(x)}" y="${emu(y)}"/><a:ext cx="${emu(w)}" cy="${emu(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln><a:noFill/></a:ln></p:spPr><p:txBody><a:bodyPr wrap="square" lIns="0" rIns="0" tIns="0" bIns="0"><a:noAutofit/></a:bodyPr><a:lstStyle/>${String(value).split('\n').map(line=>`<a:p><a:pPr><a:lnSpc><a:spcPts val="${Math.round(size*110)}"/></a:lnSpc><a:spcBef><a:spcPts val="0"/></a:spcBef><a:spcAft><a:spcPts val="0"/></a:spcAft></a:pPr><a:r><a:rPr lang="en-US" sz="${Math.round(size*100)}" b="${bold?1:0}"><a:solidFill><a:srgbClr val="000000"/></a:solidFill><a:latin typeface="Arial"/></a:rPr><a:t xml:space="preserve">${E(line)}</a:t></a:r><a:endParaRPr sz="${Math.round(size*100)}"/></a:p>`).join('')}</p:txBody></p:sp>`;}
function box(id,x,y,w,h){return `<p:sp><p:nvSpPr><p:cNvPr id="${id}" name="Report cell ${id}"/><p:cNvSpPr/><p:nvPr/></p:nvSpPr><p:spPr><a:xfrm><a:off x="${emu(x)}" y="${emu(y)}"/><a:ext cx="${emu(w)}" cy="${emu(h)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom><a:noFill/><a:ln w="12700"><a:solidFill><a:srgbClr val="000000"/></a:solidFill></a:ln></p:spPr></p:sp>`;}
function pic(id,rid,x,y,w,h,image){const fit=Math.min(w/image.width,h/image.height),pw=image.width*fit,ph=image.height*fit;return `<p:pic><p:nvPicPr><p:cNvPr id="${id}" name="Report photo ${id}"/><p:cNvPicPr><a:picLocks noChangeAspect="1"/></p:cNvPicPr><p:nvPr/></p:nvPicPr><p:blipFill><a:blip r:embed="${rid}"/><a:stretch><a:fillRect/></a:stretch></p:blipFill><p:spPr><a:xfrm><a:off x="${emu(x+(w-pw)/2)}" y="${emu(y+(h-ph)/2)}"/><a:ext cx="${emu(pw)}" cy="${emu(ph)}"/></a:xfrm><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></p:spPr></p:pic>`;}
function lines(value,width=27){const out=[],limit=width*6;let measure=s=>Array.from(s).reduce((n,c)=>n+(/[MW@#%]/.test(c)?11:/[il.,' ]/.test(c)?3.5:6.7),0);if(typeof document!=='undefined'){const ctx=document.createElement('canvas').getContext('2d');ctx.font='12px Arial';measure=s=>ctx.measureText(s).width;}for(const paragraph of String(value||'').split(/\r?\n/)){let line='';for(const word of paragraph.split(/\s+/).filter(Boolean)){if(line&&measure(line+' '+word)>limit){out.push(line);line='';}for(const c of word){if(line&&measure(line+c)>limit){out.push(line);line='';}line+=c;}line+=' ';}out.push(line.trim());}return out;}
function pieces(value,width,max){const a=lines(value,width),out=[];for(let i=0;i<a.length;i+=max)out.push(a.slice(i,i+max).join('\n'));return out;}
function date(value){const m=/^(\d{4})-(\d{2})-(\d{2})$/.exec(value||'');return m?`${Number(m[2])}/${Number(m[3])}/${m[1]}`:value||'';}
async function build({template,items,metadata={},Zip=root.JSZip,prepare=root.photoLogExporter.preparePhoto}){
 if(!items.length)throw Error('Add a photo before exporting a Punch Walk.');
 const zip=await Zip.loadAsync(template),slots=[];
 for(const item of items){const image=await prepare(item.photo),description=pieces(item.description,27,8),disposition=pieces(item.disposition,27,8),location=pieces(item.location,27,3);for(let i=0;i<Math.max(description.length,disposition.length,location.length);i++)slots.push({...item,image,description:description[i]||'',disposition:disposition[i]||'',location:location[i]||'',continued:i>0});}
 let presentation=await zip.file('ppt/presentation.xml').async('string'),rels=await zip.file('ppt/_rels/presentation.xml.rels').async('string'),types=await zip.file('[Content_Types].xml').async('string');
 // Drop example slides, notes, comments, and unused images, retaining only the firm's logo.
 for(const name of Object.keys(zip.files))if(/^ppt\/(slides\/|notesSlides\/|comments\/)/.test(name)||(/^ppt\/media\//.test(name)&&name!=='ppt/media/image1.jpeg'))zip.remove(name);
 rels=rels.replace(/<Relationship\b[^>]*Type="[^"]*\/slide"[^>]*\/>/g,'');types=types.replace(/<Override\b[^>]*PartName="\/ppt\/(?:slides|notesSlides|comments)\/[^\"]*"[^>]*\/>/g,'');
 const count=Math.ceil(slots.length/2);let ids='';
 for(let p=0;p<count;p++){
  const n=p+1,rid='rIdPunch'+n;ids+=`<p:sldId id="${1024+p}" r:id="${rid}"/>`;rels=rels.replace('</Relationships>',`<Relationship Id="${rid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slide" Target="slides/slide${n}.xml"/></Relationships>`);types=types.replace('</Types>',`<Override PartName="/ppt/slides/slide${n}.xml" ContentType="application/vnd.openxmlformats-officedocument.presentationml.slide+xml"/></Types>`);
  let id=2,body='',sr=`<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/slideLayout" Target="../slideLayouts/slideLayout1.xml"/><Relationship Id="rIdLogo" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/image1.jpeg"/>`;
  const t=(name,v,x,y,w,h,size=9,b=false)=>body+=text(id++,name,v,x,y,w,h,size,b);
  body+=box(id++,.25,.25,7,.65)+box(id++,5.3,.25,1.95,.65);body+=pic(id++,'rIdLogo',.35,.32,.85,.22,{width:174,height:62});
  t('Project name',lines(metadata.projectName,43).join('\n'),1.35,.29,3.92,.30,9,true);t('Punch heading',lines(heading(metadata),52).join('\n'),1.35,.61,3.92,.25,8,true);t('Report date','Date: '+date(metadata.date),5.4,.34,1.75,.23,9);
  for(const [x,w,name,v]of [[.25,2.5,'Client Name',metadata.client],[2.75,2.55,'Location',metadata.site],[5.3,1.95,'AECOM Project Number',metadata.projectNumber]]){body+=box(id++,x,.90,w,.60);t(name,name+':\n'+lines(v,Math.floor(w*13)).join('\n'),x+.1,.96,w-.18,.48,8);}
  for(let j=0;j<2;j++){const item=slots[p*2+j],y=j?5.75:1.5;if(!item)continue;
   body+=box(id++,.25,y,7,4.1);body+=box(id++,.25,y,1.92,.5)+box(id++,.25,y+.5,1.92,.62)+box(id++,.25,y+1.12,1.92,1.47)+box(id++,.25,y+2.59,1.92,1.51);
   t('Photo number '+j,'Photo No.\n'+identifier(item.rawNumber??item.number,metadata)+(item.continued?' (cont.)':''),.35,y+.08,1.7,.4,10,true);
   t('Photo location '+j,'Photo Location (Room or Area):\n'+item.location,.35,y+.57,1.72,.51,8);
   t('Description '+j,'Description:\n'+item.description,.35,y+1.2,1.72,1.32,9);
   t('Disposition '+j,'Disposition:\n'+item.disposition,.35,y+2.67,1.72,1.36,9);
   const imageRid='rIdPhoto'+j,media=`punch-${n}-${j}.${item.image.ext}`;zip.file('ppt/media/'+media,item.image.base64,{base64:true});sr+=`<Relationship Id="${imageRid}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/image" Target="../media/${media}"/>`;if(!types.includes(`Extension="${item.image.ext}"`))types=types.replace('</Types>',`<Default Extension="${item.image.ext}" ContentType="${item.image.type}"/></Types>`);body+=pic(id++,imageRid,2.32,y+.15,4.78,3.8,item.image);
  }
  t('Page number',`${n} / ${count}`,.25,9.9,7,.15,8);
  zip.file(`ppt/slides/slide${n}.xml`,`<?xml version="1.0" encoding="UTF-8" standalone="yes"?><p:sld xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships" xmlns:p="http://schemas.openxmlformats.org/presentationml/2006/main" showMasterSp="0"><p:cSld><p:bg><p:bgPr><a:solidFill><a:srgbClr val="FFFFFF"/></a:solidFill><a:effectLst/></p:bgPr></p:bg><p:spTree><p:nvGrpSpPr><p:cNvPr id="1" name=""/><p:cNvGrpSpPr/><p:nvPr/></p:nvGrpSpPr><p:grpSpPr><a:xfrm><a:off x="0" y="0"/><a:ext cx="0" cy="0"/><a:chOff x="0" y="0"/><a:chExt cx="0" cy="0"/></a:xfrm></p:grpSpPr>${body}</p:spTree></p:cSld><p:clrMapOvr><a:masterClrMapping/></p:clrMapOvr></p:sld>`);zip.file(`ppt/slides/_rels/slide${n}.xml.rels`,sr+'</Relationships>');
 }
 presentation=presentation.replace(/<p:sldIdLst>[\s\S]*?<\/p:sldIdLst>/,`<p:sldIdLst>${ids}</p:sldIdLst>`).replace(/<p:sldSz\b[^>]*\/>/,`<p:sldSz cx="${emu(7.5)}" cy="${emu(10.15)}" type="custom"/>`);
 zip.file('ppt/presentation.xml',presentation);zip.file('ppt/_rels/presentation.xml.rels',rels);zip.file('[Content_Types].xml',types);
 zip.file('docProps/core.xml','<?xml version="1.0" encoding="UTF-8"?><cp:coreProperties xmlns:cp="http://schemas.openxmlformats.org/package/2006/metadata/core-properties" xmlns:dc="http://purl.org/dc/elements/1.1/"><dc:title>'+E(metadata.projectName)+' Punch List</dc:title><dc:creator>Field Notes</dc:creator></cp:coreProperties>');
 const app=zip.file('docProps/app.xml');if(app)zip.file('docProps/app.xml',(await app.async('string')).replace(/<Slides>\d+<\/Slides>/,`<Slides>${count}</Slides>`));return zip.generateAsync({type:'uint8array'});
}
const api={build,identifier,heading,disciplines,prefixes,lines};if(typeof module==='object'&&module.exports)module.exports=api;else root.punchWalkExporter=api;
})(typeof window!=='undefined'?window:globalThis);
