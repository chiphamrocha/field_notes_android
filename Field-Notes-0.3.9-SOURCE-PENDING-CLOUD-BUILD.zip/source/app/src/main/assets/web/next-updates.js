'use strict';
/* 0.3.3: device fixes, reversible deletion and synchronized numbering. */
function fnResetInput(){
 if(fn034PinTap){clearTimeout(fn034PinTap.timer);if(fn034PinTap.moving){Object.assign(fn034PinTap.hit,fn034PinTap.original);tablet.revision++;}fn034PinTap=null;}
 const id=tablet.active?.id;tabletCancelInk();
 try{if(id!==undefined&&$('viewport').hasPointerCapture(id))$('viewport').releasePointerCapture(id);}catch{}
 gesture=null;action=null;touchPoints.clear();pinch=null;navigationOnly=false;nativeTouchNavigation=false;window.tabletPenDown=false;
}
const fnSetMode=tabletSetMode;tabletSetMode=function(mode){fnResetInput();fnSetMode(mode);};
const fnEntry=showEntry;showEntry=function(...args){fnResetInput();fnEntry(...args);$('deleteEntry').hidden=!editingNote;fnVoiceTarget='text';fnShowVoiceTarget();$('voice').textContent='Record';$('stopVoice').textContent='Stop';$('restoreDictation').hidden=!pending?.dictationOriginals;};
$('entry').addEventListener('close',()=>{fnResetInput();fnVoiceTarget='text';});
window.addEventListener('blur',()=>{if(!pending)fnResetInput();});
document.addEventListener('visibilitychange',()=>{if(document.hidden)fnResetInput();});
// Larger labels on the interactive plan. Vector exports use 13.5pt (3/16 inch).
const fnScreenStyle=screenStyle;screenStyle=function(){const s=fnScreenStyle();return {...s,pinRadius:s.pinRadius*2,numberSize:s.numberSize*2};};
function fnUid(){return globalThis.crypto?.randomUUID?.()||'entry-'+Date.now()+'-'+Math.random().toString(36).slice(2);}
function fnEnsureIds(){for(const mark of tabletAllMarks()){if(!mark.id)mark.id=fnUid();for(const photo of mark.photos||[])if(!photo.id)photo.id=fnUid();}}
const fnAssign=tabletAssignPhotoNumbers;tabletAssignPhotoNumbers=function(){fnAssign();fnEnsureIds();};
function fnRenumberPhotos(){
 savePage();let number=1;
 const marks=tabletAllMarks().filter(m=>['note','voice'].includes(m.kind)&&tabletNoteType(m)==='photo').sort((a,b)=>(a.number||0)-(b.number||0));
 for(const mark of marks){mark.number=number++;for(const photo of mark.photos||[])photo.number=mark.number;}
 fieldNotesLabels();
}
function fnRenumberNotes(){
 savePage();let number=1;
 const notes=tabletAllMarks().filter(m=>['note','voice'].includes(m.kind)&&tabletNoteType(m)!=='photo').sort((a,b)=>(a.number||0)-(b.number||0));
 for(const mark of notes)mark.number=number++;
 fieldNotesLabels();
}
// Deletion snapshots span the drawing set because renumbering can affect other pages.
const fnUndo=[],fnRedo=[];
function fnAllSnapshot(){savePage();return structuredClone(pages.map(p=>p.marks));}
function fnRestoreAll(snapshot){for(let i=0;i<pages.length;i++){const list=pages[i].marks;list.splice(0,list.length,...structuredClone(snapshot[i]));histories.delete(list);}lab.marks=pages[pageIndex].marks;tablet.revision++;tabletRender();tabletSaveSoon();}
function fnClearDeleteHistory(){fnUndo.length=0;fnRedo.length=0;}
function fnDeleteMark(mark){
 const type=tabletNoteType(mark)==='photo'?'photo':'note';
 if(!confirm(type==='photo'?'Delete this photo entry and its plan label? Remaining photos will be renumbered. Original photos on your device are kept.':'Delete this note and its plan label?'))return false;
 const before=fnAllSnapshot(),list=pages[pageIndex].marks,index=list.indexOf(mark);if(index<0)return false;
 list.splice(index,1);if(type==='photo')fnRenumberPhotos();else fnRenumberNotes();
 for(const page of pages)histories.delete(page.marks);
 fnRedo.length=0;fnUndo.push({before,after:fnAllSnapshot()});
 tablet.revision++;tabletRender();tabletSaveSoon();return true;
}
$('deleteEntry').onclick=()=>{if(!editingNote)return;const mark=editingNote;if(!fnDeleteMark(mark))return;$('entry').returnValue='delete';$('entry').close();};
const fnCommit=tabletCommit;tabletCommit=function(before){fnClearDeleteHistory();fnCommit(before);};
const fnUndoClick=$('undo').onclick,fnRedoClick=$('tabletRedo').onclick;
$('undo').onclick=()=>{if(fnUndo.length&&!tablet.active){const entry=fnUndo.pop();fnRedo.push(entry);fnRestoreAll(entry.before);}else fnUndoClick();};
$('tabletRedo').onclick=()=>{if(fnRedo.length&&!tablet.active){const entry=fnRedo.pop();fnUndo.push(entry);fnRestoreAll(entry.after);}else fnRedoClick();};
const fnRender=tabletRender;tabletRender=function(){fnRender();if(fnUndo.length)$('undo').disabled=false;if(fnRedo.length)$('tabletRedo').disabled=false;};render=tabletRender;
// The photo attachment Remove action also closes numbering gaps after Save.
let fnRemovedAttachment=false;
$('notePhotoList').addEventListener('click',e=>{if(e.target.closest('[data-remove-photo]'))fnRemovedAttachment=true;},true);
$('entry').addEventListener('close',()=>{if(fnRemovedAttachment&&$('entry').returnValue==='save'){fnRenumberPhotos();for(const page of pages)histories.delete(page.marks);fnClearDeleteHistory();tablet.revision++;tabletRender();tabletSaveSoon();}fnRemovedAttachment=false;});
// All caption/location/disposition fields use the same recording controls.
let fnVoiceTarget='text';
const fnFieldNames={text:'Note',photoLocation:'Photo location',disposition:'Disposition'};
function fnShowVoiceTarget(){const name=fnVoiceTarget==='text'&&pending&&tabletNoteType(pending)==='photo'?'Photo caption':fnFieldNames[fnVoiceTarget];$('voiceTarget').textContent='Record into: '+name;}
for(const id of ['text','photoLocation','disposition'])$(id).addEventListener('focus',()=>{if(!window.fnSpeechBusy){fnVoiceTarget=id;fnShowVoiceTarget();}});
window.fnVoiceField=()=>$(fnVoiceTarget);
window.fnVoiceTargetName=()=>fnVoiceTarget==='text'&&tabletNoteType(pending||{})==='photo'?'Photo caption':fnFieldNames[fnVoiceTarget];
// Conservative fallback: preserve every word, dimension and equipment identifier.
// Full contextual punctuation requires support from the selected speech provider.
window.fnPunctuate=value=>{let s=String(value||'').trim();if(!s)return s;s=s.replace(/^\p{Ll}/u,c=>c.toUpperCase());if(/[\p{L}\p{N}]$/u.test(s))s+='.';return s;};
window.fnSaveDictation=(field,raw)=>{if(!pending||!field)return;pending.dictationOriginals={...(pending.dictationOriginals||{}),[field.id]:raw};field.value=window.fnPunctuate(raw);$('restoreDictation').hidden=false;};
$('restoreDictation').onclick=()=>{const field=window.fnVoiceField(),raw=pending?.dictationOriginals?.[field.id];if(raw!==undefined)field.value=raw;};
// Explicit page navigation clears abandoned gesture state before changing pages.
const fnSwitch=switchPage;switchPage=async function(index){if(pending||dialogsOpen()||loadingPage)return;fnResetInput();fnClearDeleteHistory();await fnSwitch(index);};
$('previousPage').onclick=()=>switchPage(pageIndex-1);$('nextPage').onclick=()=>switchPage(pageIndex+1);
const fnLoad=loadFile;loadFile=async function(...args){fnClearDeleteHistory();return fnLoad(...args);};
const fnOpenSaved=tabletOpenSavedDrawing;tabletOpenSavedDrawing=async function(...args){fnClearDeleteHistory();return fnOpenSaved(...args);};
// Include Menu in the direct S Pen activation path; toolbar buttons already use it.
fnPenButton($('menuButton'));
function fnPenButton(button){let press=null,last=-Infinity;button.addEventListener('pointerdown',e=>{if(e.pointerType==='pen'&&e.button===0){press={id:e.pointerId,x:e.clientX,y:e.clientY};try{button.setPointerCapture(e.pointerId);}catch{}}});button.addEventListener('pointercancel',()=>press=null);button.addEventListener('pointerup',e=>{if(e.pointerType!=='pen'||press?.id!==e.pointerId)return;const p=press;press=null;if(Math.hypot(e.clientX-p.x,e.clientY-p.y)>12)return;e.preventDefault();last=performance.now();button.click();});button.addEventListener('click',e=>{if(e.isTrusted&&performance.now()-last<500){e.preventDefault();e.stopImmediatePropagation();}},true);}
for(const id of ['previousPage','nextPage','pagesButton','rotatePage'])fnPenButton($(id));
function fnFitPhotoEditor(){if(!$('photoMarkupSheet').open)return;const sheet=$('photoMarkupSheet'),canvas=$('photoMarkupCanvas');const rect=sheet.getBoundingClientRect(),style=getComputedStyle(sheet);let used=parseFloat(style.paddingTop)+parseFloat(style.paddingBottom)+2;for(const child of sheet.children)if(child!==canvas){const r=child.getBoundingClientRect();used+=r.height+8;}const maxHeight=Math.max(24,rect.height-used),maxWidth=sheet.clientWidth-parseFloat(style.paddingLeft)-parseFloat(style.paddingRight);const scale=Math.min(maxWidth/canvas.width,maxHeight/canvas.height);canvas.style.width=Math.max(1,Math.floor(canvas.width*scale))+'px';canvas.style.height=Math.max(1,Math.floor(canvas.height*scale))+'px';canvas.style.flex='0 0 auto';canvas.style.alignSelf='center';}
new MutationObserver(fnFitPhotoEditor).observe($('photoMarkupSheet'),{attributes:true,attributeFilter:['open']});window.addEventListener('resize',fnFitPhotoEditor);window.visualViewport?.addEventListener('resize',fnFitPhotoEditor);
// Quarter-turn rotation transforms the page and every overlay together.
$('rotatePage').onclick=async()=>{
 if(pending||loadingPage||dialogsOpen())return;
 if(!pdfDoc){$('fileStatus').textContent='Rotate is available for imported PDF pages.';return;}
 fnResetInput();savePage();const record=pages[pageIndex],index=pageIndex,oldRotation=record.rotation||0;
 loadingPage=true;pageUi();$('rotatePage').disabled=true;
 try{
  const pdfPage=await pdfDoc.getPage(index+1),oldView=pdfPage.getViewport({scale:1,rotation:(pdfPage.rotate+oldRotation)%360});
  const nextRotation=(oldRotation+90)%360;const preview=await pdfPreview(index,2400,nextRotation);
  const oldFit=Math.min(1000/oldView.width,700/oldView.height),newFit=Math.min(1000/preview.width,700/preview.height),ratio=newFit/oldFit;
  const turn=p=>({x:500-(p.y-350)*ratio,y:350+(p.x-500)*ratio});
  for(const mark of record.marks){if(Number.isFinite(mark.x)&&Number.isFinite(mark.y))Object.assign(mark,turn(mark));if(mark.points)mark.points=mark.points.map(turn);if(mark.width)mark.width*=ratio;}
  record.rotation=nextRotation;Object.assign(record,preview);record.view=fitFileView(record);record.cursor=turn(record.cursor);
  Object.assign(lab,{background:record.background,view:{...record.view},cursor:{...record.cursor}});histories.delete(record.marks);fnClearDeleteHistory();
  pdfPreviewKey='';tablet.revision++;$('fileStatus').textContent='PDF page rotated 90° clockwise. Annotations stayed aligned.';tabletSaveSoon();
 }catch(e){$('fileStatus').textContent='Could not rotate page: '+e.message;}
 finally{loadingPage=false;$('rotatePage').disabled=false;pageUi();tabletRender();}
};
fnEnsureIds();tablet.revision++;tabletRender();
