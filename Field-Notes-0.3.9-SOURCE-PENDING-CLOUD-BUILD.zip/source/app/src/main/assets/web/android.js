'use strict';
(() => {
  let recording=null, sequence=0, exporting=false;
  const native=window.FieldNotesNative;
  // Keep Android's compatibility shims in both the UI module and PDF worker.
  pdfLibrary=async function(){if(!pdfPromise)pdfPromise=import('./vendor/android-pdf.mjs').then(lib=>{lib.GlobalWorkerOptions.workerSrc=new URL('./vendor/android-pdf.worker.mjs',location.href).href;return lib;});return pdfPromise;};
  function controls(active){$('voice').disabled=active;$('stopVoice').disabled=!active;$('saveEntry').disabled=active;$('text').readOnly=active;}
  const oldEntry=showEntry;
  showEntry=function(...args){oldEntry(...args);const photo=tabletNoteType(pending)==='photo';$('entryLabel').textContent=photo?'Photo caption · type or speak':'Note text · type or speak';$('voice').textContent=photo?'Dictate caption':'Dictate note';$('voiceStatus').textContent='Tap Dictate, speak, then Stop voice. Review the text before saving.';$('stopVoice').hidden=false;};
  $('takePhoto').onclick=()=>$('cameraPhoto').click();
  $('voice').onclick=()=>{
    if(recording||!pending)return;
    const current={id:'voice-'+Date.now()+'-'+(++sequence),target:pending,initial:$('text').value.trim(),partial:''};recording=current;controls(true);
    $('voiceStatus').textContent='Starting phone speech recognition…';
    native.startSpeech(current.id,$('dictationLanguage').value);
  };
  $('stopVoice').onclick=()=>{if(!recording)return;$('stopVoice').disabled=true;$('voiceStatus').textContent='Finishing… waiting for the final text.';native.stopSpeech(recording.id);};
  window.fieldNotesAndroidSpeech=(id,phase,text)=>{
    const current=recording;if(!current||id!==current.id||current.target!==pending)return;
    if(phase==='ready')$('voiceStatus').textContent='Listening… speak your note, then tap Stop voice. The phone may finish automatically after a pause.';
    if(phase==='partial'){current.partial=text;$('text').value=[current.initial,text].filter(Boolean).join(' ');}
    if(phase==='processing'){$('stopVoice').disabled=true;$('voiceStatus').textContent='Finishing… waiting for the final text.';}
    if(phase==='final'){$('text').value=[current.initial,text.trim()].filter(Boolean).join(' ');$('voiceStatus').textContent=text.trim()?'Review the text, then Save. Tap Dictate to add another sentence.':'No words were returned. Try a short sentence.';recording=null;controls(false);}
    if(phase==='error'){$('voiceStatus').textContent=text+(current.partial?' Any preview text is still here for you to review.':'');recording=null;controls(false);}
    if(phase==='cancelled'){$('voiceStatus').textContent='Voice cancelled. Review any preview text before saving.';recording=null;controls(false);}
  };
  $('entry').addEventListener('close',()=>{if(recording){const id=recording.id;recording=null;native.cancelSpeech(id);controls(false);}});
  window.fieldNotesAndroidExportStatus=text=>{$('fileStatus').textContent=text;$('vectorPdfStatus').textContent=text;$('photoLogStatus').textContent=text;};
  function chunkBase64(blob){return new Promise((resolve,reject)=>{const reader=new FileReader();reader.onload=()=>resolve(String(reader.result).split(',')[1]);reader.onerror=()=>reject(Error('Could not prepare this export.'));reader.readAsDataURL(blob);});}
  downloadBlob=async function(blob,name){
    if(exporting){window.fieldNotesAndroidExportStatus('Another export is being prepared. Finish it first.');return;}
    exporting=true;const id='export-'+Date.now()+'-'+(++sequence);
    try{
      if(!native.beginExport(id,name,blob.type,blob.size))throw Error('Could not start export. Finish any open Save dialog, or use a smaller file (maximum 128 MB).');
      for(let offset=0;offset<blob.size;offset+=196608){const chunk=await chunkBase64(blob.slice(offset,offset+196608));if(!native.appendExport(id,chunk))throw Error('Could not prepare the export. Check storage space.');}
      if(!native.finishExport(id))throw Error('The export was incomplete. Please retry.');
      window.fieldNotesAndroidExportStatus('Choose a folder and tap Save in the Android file picker.');return true;
    }catch(error){native.abortExport(id);window.fieldNotesAndroidExportStatus(error.message);throw error;}
    finally{exporting=false;}
  };
  window.fieldNotesAndroidBack=()=>{
    const open=[...document.querySelectorAll('dialog[open]')];
    if(open.length){const top=open.at(-1);top.returnValue='cancel';top.close();return true;}
    return false;
  };
  // Lower the PDF preview's memory use on older phones; original PDF and vector export are unchanged.
  document.addEventListener('visibilitychange',()=>{if(document.hidden&&typeof tabletPersist==='function')tabletPersist();});
})();
