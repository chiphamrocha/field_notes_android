'use strict';
/* One dictation session per field, spanning provider-imposed utterance boundaries. */
(() => {
 if(window.fieldNotesDesktop)return; // Windows uses its existing local microphone engine.
 const native=window.FieldNotesNative,Speech=window.SpeechRecognition||window.webkitSpeechRecognition;
 let session=null,sequence=0;
 function controls(active){window.fnSpeechBusy=active;$('voice').disabled=active;$('stopVoice').disabled=!active;$('saveEntry').disabled=active;$('deleteEntry').disabled=active;for(const id of ['text','photoLocation','disposition'])$(id).readOnly=active;}
 function words(s,part=''){return [s.initial,...s.parts,part].filter(Boolean).join(' ').trim();}
 function finish(s,message){if(session!==s)return;clearTimeout(s.restart);clearTimeout(s.deadline);session=null;controls(false);if(pending===s.target){const raw=words(s,s.partial);window.fnSaveDictation(s.field,raw);$('voiceStatus').textContent=message||'Dictation stopped. Review punctuation and technical terms before saving.';}}
 function next(s){if(session!==s||s.stopping)return;clearTimeout(s.restart);$('voiceStatus').textContent='Reconnecting speech recognition… your text is kept. Stop ends dictation.';s.restart=setTimeout(()=>startUtterance(s),350);}
 function terminal(s,message){if(native&&s.id)native.cancelSpeech(s.id);s.recognition?.abort();finish(s,message);}
 function startUtterance(s){
  if(session!==s||s.stopping)return;
  if(native){s.id='voice-'+Date.now()+'-'+(++sequence);native.startSpeech(s.id,'en-US');return;}
  const r=new Speech();s.recognition=r;r.lang='en-US';r.interimResults=true;r.continuous=true;let final='',interim='';
  r.onstart=()=>{if(session===s)$('voiceStatus').textContent='Listening into '+s.name+'. Pauses are allowed; tap Stop when finished.';};
  r.onresult=e=>{if(session!==s||pending!==s.target)return;final='';interim='';for(const result of e.results){if(result.isFinal)final+=result[0].transcript+' ';else interim+=result[0].transcript+' ';}s.partial=[final.trim(),interim.trim()].filter(Boolean).join(' ');s.field.value=words(s,s.partial);s.errors=0;};
  r.onerror=e=>{if(session!==s)return;if(['not-allowed','service-not-allowed','audio-capture','network','language-not-supported'].includes(e.error)){terminal(s,'Dictation stopped: '+e.error+'. Your captured text is kept.');return;}if(!['no-speech','aborted'].includes(e.error)&&++s.errors>5)terminal(s,'Speech recognition could not continue. Your text is kept; tap Record to retry.');};
  r.onend=()=>{if(session!==s)return;s.recognition=null;if(final.trim())s.parts.push(final.trim());s.partial=interim.trim();if(s.partial){s.parts.push(s.partial);s.partial='';}if(s.stopping)finish(s);else next(s);};
  try{r.start();}catch(e){terminal(s,'Could not start dictation: '+e.message);}
 }
 $('voice').onclick=()=>{
  if(session||!pending)return;if(!native&&!Speech){$('voiceStatus').textContent='Speech recognition is unavailable in this browser. Use keyboard dictation or type.';return;}
  const field=window.fnVoiceField();const s={target:pending,field,name:window.fnVoiceTargetName(),initial:field.value.trim(),parts:[],partial:'',errors:0,stopping:false,id:null};session=s;controls(true);$('voiceStatus').textContent='Starting dictation into '+s.name+'…';startUtterance(s);
 };
 $('stopVoice').onclick=()=>{const s=session;if(!s||s.stopping)return;s.stopping=true;clearTimeout(s.restart);$('stopVoice').disabled=true;$('voiceStatus').textContent='Finishing dictated text…';if(native&&s.id)native.stopSpeech(s.id);else if(s.recognition)s.recognition.stop();else {finish(s);return;}s.deadline=setTimeout(()=>{if(session===s){if(native&&s.id)native.cancelSpeech(s.id);s.recognition?.abort();finish(s,'Dictation stopped. The last preview was kept; review before saving.');}},7000);};
 window.fieldNotesAndroidSpeech=(id,phase,text)=>{
  const s=session;if(!s||id!==s.id||pending!==s.target)return;
  if(phase==='ready'){$('voiceStatus').textContent='Listening into '+s.name+'. Pauses are allowed; tap Stop when finished.';return;}
  if(phase==='partial'){s.partial=text;s.field.value=words(s,text);return;}
  if(phase==='processing'){$('voiceStatus').textContent=s.stopping?'Finishing dictated text…':'Processing this phrase. Dictation will continue; Stop ends it.';return;}
  if(phase==='final'){if(text.trim())s.parts.push(text.trim());s.partial='';s.errors=0;s.field.value=words(s);s.id=null;if(s.stopping)finish(s);else next(s);return;}
  if(phase==='error'){
   s.id=null;
   if(s.partial){s.parts.push(s.partial);s.partial='';}
   if(!s.stopping&&/No speech|No match|timed out/i.test(text)){next(s);return;}
   finish(s,text+' Captured text is kept.');return;
  }
  if(phase==='cancelled'){s.id=null;finish(s,'Dictation cancelled. Captured text is kept.');}
 };
 $('entry').addEventListener('close',()=>{const s=session;if(!s)return;session=null;clearTimeout(s.restart);clearTimeout(s.deadline);if(native&&s.id)native.cancelSpeech(s.id);s.recognition?.abort();controls(false);});
 // Leaving the app ends the microphone session explicitly; notes stay available.
 document.addEventListener('visibilitychange',()=>{if(document.hidden&&session){const s=session;if(native&&s.id)native.cancelSpeech(s.id);s.recognition?.abort();finish(s,'Dictation stopped because the app left the foreground. Captured text is kept.');}});
 $('voice').textContent='Record';$('stopVoice').textContent='Stop';
})();
