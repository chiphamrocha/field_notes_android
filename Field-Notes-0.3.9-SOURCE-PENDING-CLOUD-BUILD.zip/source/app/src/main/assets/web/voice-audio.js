(function(root,factory){if(typeof module==='object'&&module.exports)module.exports=factory();else root.fieldNotesAudio=factory();})(typeof globalThis!=='undefined'?globalThis:this,function(){
  'use strict';
  function encodeWav(chunks,sampleRate=16000){
    if(sampleRate!==16000)throw Error('Microphone sample rate is not supported.');
    const length=chunks.reduce((n,c)=>n+c.length,0);if(!length||length>16000*180)throw Error('Record a note between one moment and three minutes.');
    const buffer=new ArrayBuffer(44+length*2),view=new DataView(buffer);let offset=0;
    const str=value=>{for(const char of value)view.setUint8(offset++,char.charCodeAt(0));};
    str('RIFF');view.setUint32(offset,36+length*2,true);offset+=4;str('WAVEfmt ');view.setUint32(offset,16,true);offset+=4;view.setUint16(offset,1,true);offset+=2;view.setUint16(offset,1,true);offset+=2;view.setUint32(offset,16000,true);offset+=4;view.setUint32(offset,32000,true);offset+=4;view.setUint16(offset,2,true);offset+=2;view.setUint16(offset,16,true);offset+=2;str('data');view.setUint32(offset,length*2,true);offset+=4;
    for(const chunk of chunks)for(const raw of chunk){const value=Number.isFinite(raw)?Math.max(-1,Math.min(1,raw)):0;view.setInt16(offset,Math.round(value*(value<0?32768:32767)),true);offset+=2;}
    return new Uint8Array(buffer);
  }
  return {encodeWav};
});
