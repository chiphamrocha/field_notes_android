HISTORICAL REFERENCE ONLY. Prior release claims below are not current verification. Do not install failed 0.3.7/0.3.8 APKs.

# Field Notes 0.3.5 tablet-test update

November 1, 2026. Based on the Android 0.3.4 source. Package `com.fieldnotes.preview`, version code 35.

## Session requests

1. Hold a saved Note or Photo tag for about half a second, drag, then release to move it. A short tap opens its editor. Moving preserves the tag number, entry and attachments. A cancelled drag restores the original position; Undo can reverse a completed move.
2. Clear abandoned drawing/pen state when moving into and out of editor text fields, and clear the pen-down flag on form pointer completion. This is a candidate mitigation for the intermittent Samsung S Pen freeze, which remains open until tested on the physical tablet. Handwriting and dictation are retained.
3. Add Export report (.pdf) alongside the existing PowerPoint export. The PDF is a simple review layout with one image per page, tag ID, attachment index, drawing page, project/date, location, caption and disposition. Long text continues on extra pages. It does not reproduce the PowerPoint template's layout.
4. Use the approved helper text: "Finger: turn pen-only off. With pen-only on, fingers navigate; use the pen to sketch and drop labels." Keep the existing eraser instruction.
5. Number photo locations rather than individual attachments. A second image added under Photo 04 remains under 04, and a new location after 09 gets 10. PDF/PPTX reports retain all images under the shared tag number. Existing location numbers are retained; deleting a location closes gaps across the drawing set. Attachment removal does not consume another location ID.
6. Rename Add / edit arrows to Edit.
7. Edit opens Arrows and Crop. Drag a rectangle in Crop to choose the area to keep. Reset crop restores the full original image. Apply commits to the photo form; Save commits the entry. Cancel discards pending editor changes. The original photo and crop coordinates are retained in local drafts and backup exports. A separate resize tool is not included.
8. Put Edit and Remove together below each thumbnail and hide the attachment filename there. Backup filenames remain distinct and continue using page, tag number and attachment index.
9. Remove Screen text size. The whole label belongs to the drawing: its shape, text and leader scale with the drawing during zoom. Photo-circle diameter and note-hexagon height are both 3/16 inch on the printed/exported sheet at Actual Size. ID text has one fixed size for A1 through A999. The 3/16-inch dimension refers to the shape, not its font size.

## Verification

- Real Chromium interaction checks: adding a second attachment, next location numbering, crop output pixels, Cancel, reset and reopening, arrows, hold/drag, short tap, stale pen-state recovery, draft save/reload.
- Android entry page checked with a simulated native bridge: A999, equal circle/hexagon heights, portrait, landscape and a viewport reduced to 480 pixels high; Apply and Cancel remained reachable.
- Actual PDF/PPTX and backup ZIP generated. Both attachments were retained; backup image filenames were distinct, and original-image/crop metadata remained present. Delete, renumber and Undo retained both attachments and IDs.
- Annotated PDF photo circles measured at 13.5 points in diameter, exactly 3/16 inch. JavaScript syntax passed. No page errors in the browser checks.
- Full Java/Dex/resource build completed using Android SDK platform 35 and Build Tools 35.0.0. APK ZIP integrity passed, and every packaged web asset matched the tested source. APK v2/v3 signatures verified. The certificate SHA-256 matches the prior 0.3.4 INPLACE-CANDIDATE APK: `28bfff0b3d3d38064caaa1ba679ebb2718cfcd3ed45a3daf9160b74efd46961c`.

## Remaining device checks

This APK has not been installed on a physical Android tablet here. Installation, Samsung handwriting/IME behavior, S Pen freeze recovery, real camera/microphone operation and physical print measurement remain unverified. Browser/native-bridge simulations do not establish hardware acceptance.

No new Windows executable or hosted iPhone deployment is included. The complete Android source and shared web resources are included for follow-up work.
