# Field Notes: update list

## Implementation and device testing

### FN-001: Photo annotation arrows
- Added: October 24, 2026.
- Add an option to place bold, thick arrows on uploaded photos to point out specific features or conditions.
- Status: implemented in 0.3.2 packages; browser-tested arrow add/save/reload/cancel and report export. Original photo and separate arrow records retained.

### FN-002: Tablet buttons near top edge miss taps
- Added: October 25, 2026.
- Reported behavior: buttons near the tablet's top edge do not reliably respond to touch; several taps are sometimes required.
- Expected behavior: buttons respond reliably to a single deliberate tap.
- Prior troubleshooting (October 23): Android v0.2.8; S Pen taps on top toolbar buttons such as Sketch and Photo often fail to register. This is distinct from drawing-stroke sensitivity.
- Suggested comparison: finger taps versus S Pen taps to investigate stylus input handling. No comparison result or completed fix was found in the retrieved record.
- Investigate touch target size, overlapping elements, and edge gesture interference; cause not yet confirmed.
- Status: candidate fix included in 0.3.2: toolbar targets at least 44 x 48 px, clearance below the screen edge, direct pen activation with duplicate-click suppression. Automated pen-event simulations and target-size checks pass. Physical tablet/S Pen acceptance remains pending; not confirmed fixed on the device.

### FN-003: Choose filename when saving
- Added: October 25, 2026.
- Reported behavior: no option to name the file when saving.
- Requested behavior: allow the user to enter or change the filename when saving the photo log or annotated plan.
- Status: implemented in 0.3.2 packages. Filename dialog covers reports, annotated PDF, notes, and backup ZIP. Custom report/plan names, cancellation, Unicode names, and the Android export bridge were tested.

### FN-004: Punch Walk report template and export choice
- Added: October 25, 2026.
- Reuse the existing photo capture, photo association, and plan annotation workflow.
- User-confirmed regular Photo Log fields: Photo caption, Photo location, and attached photo. Use these as the baseline; earlier presentation labels are not authoritative for the current app. Status was not confirmed as a current Photo Log field.
- At report export/printing, let the user choose Photo Log or Punch Walk.
- User-approved setup: on the initial screen with project number, project name, and other project details, choose visit type using the labels Site Visit or Punch Walk. Site Visit uses the regular Photo Log workflow; Punch Walk adds Disposition and uses the Punch Walk report. Do not prompt for visit type at each camera capture. Retain the previously requested export choice.
- Use the emailed 2026_0702_CWRU Robbins 4_P1 Punch List - Arch.pdf as the Punch Walk layout reference; retain it as a reusable reference, not as new-project content.
- Punch Walk report output must be editable PowerPoint (.pptx). Users edit/review it in PowerPoint before printing to PDF; direct PDF export is not required for Punch Walk.
- Add the extra Punch Walk fields to the app workflow, not only to the exported layout. Capture project/client/location/project number, report date, phase/discipline, and per-item photo number, room or area, Description, and Disposition (required corrective action).
- Reuse the existing Photo location field for Punch Walk location, and the existing Photo caption field for the report's Description box. Do not add a duplicate Description input alongside Photo caption.
- Keep Photo caption (mapped to Description) and Disposition as separate editable values. Make Punch Walk fields available before export while preserving the ability to choose the report type at export.
- Reference layout: repeated project/client/location/project-number/date header; two stacked photo entries per portrait page, with text at left and photo at right. Entry fields: photo number, room or area, Description, and Disposition (required corrective action).
- User revision: keep only the report date in the sheet header. Remove the secondary date beside photo entries; do not require a separate per-item date in the Punch Walk workflow.
- Header mapping confirmed by user: the existing Project Name value populates the title beside the AECOM logo, replacing Robbins 4th Floor Renovation. Reuse the setup value; no additional project-name input is needed.
- Second header line: PUNCH LIST: [Phase] - [Discipline]. Keep PUNCH LIST fixed in every Punch Walk report. Capture a custom phase value with the initial project information; use the existing discipline selection there to populate Discipline. Phase 1 and Architecture are example values, not fixed text.
- Phase is optional: if blank/unselected, omit phase and its separator completely. Example without phase: PUNCH LIST: Architecture. Example with phase: PUNCH LIST: Phase 1 - Architecture.
- Discipline choices confirmed by user: Architecture, Mechanical, Electrical, and Fire Protection. Add Fire Protection to the existing discipline selector.
- Apply these discipline choices and optional-phase behavior to both Site Visit and Punch Walk.
- Punch Walk photo numbering uses the selected discipline prefix with at least two numeric digits: Architecture A01, A02, A03; Mechanical M01, M02, M03; Electrical E01, E02, E03; Fire Protection F01, F02, F03. Keep the existing Photo Log numbering unchanged. Match identifiers across report entries and corresponding plan photo markers.
- Project names, client names, numbers, dates, photos, descriptions, and dispositions must be populated from the current visit rather than copied from the example.
- Preserve relationships between report items, photos, and annotated plan markers.
- Status: implemented in 0.3.2 packages. Setup, Disposition, numbering, persistence, mode switching, Photo Log/Punch Walk exports and long-text continuation pass browser checks. Exported PowerPoints were rendered in LibreOffice for visual inspection. Actual Windows/Android/iPhone device acceptance remains pending.

### FN-005: Double plan label size
- Added: October 25, 2026.
- User-confirmed baseline label size: 3/32 inch.
- Required label size: 3/16 inch, twice the baseline, at printed/exported sheet scale.
- Size decision is final for this revision; no further size selection is needed.
- Status: implemented in 0.3.3 test build: doubled interactive plan labels; 13.5 pt (3/16 inch) PDF labels without shrinking discipline IDs. Real PDF export/render checked; device acceptance pending.

### FN-006: Rotate PDF page
- Added: October 25, 2026.
- Add a Rotate control for the PDF page itself, with 90-degree clockwise steps per tap.
- Keep all notes, photo markers, dimensions, and other annotations aligned with the page through rotation.
- Make Rotate visually distinct from Undo and Redo (user clarification), and from Back: use a page-and-rotation symbol and a visible Rotate label, rather than a lone curved arrow. This is a visual distinction requirement, not a request to add undo behavior.
- Status: implemented in 0.3.3 test build: distinct Rotate control, annotation transforms, saved page rotation and rotated vector export. Four-turn and two-page checks pass; device acceptance pending.

### FN-007: Menu does not respond to S Pen
- Added: October 25, 2026.
- User reports that the menu trigger (described as three dots / three lines) does not open with the Samsung S Pen, but opens with a finger.
- Required behavior: open the menu with a single deliberate S Pen tap while preserving finger operation.
- Status: candidate fix included in 0.3.3: dedicated Menu pen handler without primary-pointer gating, duplicate-click suppression and touch-action handling. Simulated pen test passes; physical S Pen verification pending.
- Separate from the toolbar clearance issue: user reports that the lowered toolbar buttons in 0.3.2 now respond more smoothly without repeated taps.

### FN-008: Previous/next page navigation buttons do not work
- Added: October 25, 2026.
- User reports that the back/forward buttons intended to change PDF pages do not move the page during current app testing; user recalls that they previously worked.
- Required behavior: previous/next controls move between PDF pages when a corresponding page is available.
- Placement refinement: the current Previous and Next buttons are too far apart. Group both controls with the page number at the bottom center of the screen: Previous immediately before the page number, Next immediately after it. Keep comfortable tap targets and a small gap; do not place the controls at opposite screen edges.
- Status: implemented in 0.3.3: controls grouped at bottom center and stale gesture cleared before navigation. Actual two-page PDF button tests pass; physical device acceptance pending.

### FN-009: Voice input for all photo text fields
- Added: October 25, 2026.
- User reports that only Photo caption currently supports voice input.
- Add voice input to Photo location and Disposition while preserving voice input for Photo caption, allowing all three photo text fields to be completed without typing.
- Route dictated text to the selected field, keeping caption, location, and disposition as separate editable values.
- User refinement: use one shared Record button for the photo form rather than a separate recording button for each field. Select Photo caption, Photo location, or Disposition, then use the shared button to dictate into that field.
- Show the target field name near the shared Record control so the destination is clear; retain that target while the recording control is used.
- Status: implemented in 0.3.3: shared Record/Stop controls use the selected caption/location/disposition/note field, with a visible destination. Android/browser provider simulations pass; live microphone and Windows native recording remain device checks.

### FN-010: Photo arrow editor image prevents access to actions
- Added: October 25, 2026.
- Tablet test: the photo fills too much of the annotation screen. Undo arrow, Cancel, and Apply arrows can fall outside the visible area.
- Swiping on the photo to reach those buttons draws an unintended additional arrow instead of scrolling.
- User-requested fix: make the photo smaller within the editor so the photo and all three action buttons remain reachable without scrolling over the drawing surface.
- Keep Undo arrow, Cancel, and Apply arrows: user found these actions intuitive. Keep the arrow colors; user successfully tested arrows and liked the result.
- Acceptance: fit the image into the available screen height and keep the three actions visible/reachable in portrait and landscape, including on the tablet. Navigation outside the drawing surface must not create arrows.
- Status: implemented in 0.3.3: image fits the available editor space with actions visible. Tall-image portrait/landscape browser checks pass; tablet acceptance pending.

### FN-011: Automatic punctuation after dictation
- Added: October 25, 2026.
- User selected an automatic punctuation pass when dictation finishes, without pressing a separate cleanup button or having to say punctuation commands.
- Apply the pass to dictated text, including caption, location, disposition, and notes where dictation is supported.
- Preserve wording, technical terms, numbers, measurements, and meaning; this is punctuation cleanup, not rewriting or adding observations.
- Keep the resulting text editable for user review before saving and final document submission.
- Do not assume every pause ends a sentence.
- Implementation approach and speech-provider support remain to be investigated; no reliable punctuation engine has yet been selected or tested.
- Status: partially implemented in 0.3.3: Android formatting request plus conservative capitalization/final-period cleanup on Stop, original text retained and restorable per field. Full contextual punctuation is still open; no separate language-model punctuation engine was added. Provider punctuation support remains device-dependent.

### FN-012: Keep dictation active until Stop
- Added: October 25, 2026.
- User supersedes the earlier preference to use a long pause as a signal to stop recording.
- Keep the dictation session active across short and long pauses until the user explicitly taps Stop; silence alone must not end the app session.
- Investigate recognition-service session limits and safe continuation/restart handling. Do not promise uninterrupted native recognition where the provider forces an end; preserve accumulated text and prevent duplicate or missing phrases.
- Run the automatic punctuation pass (FN-011) after the user ends dictation, not after an intermediate provider session ends.
- Preserve explicit cancellation and normal error/permission handling. Show listening versus reconnecting/error state accurately.
- Status: implemented for Android/browser in 0.3.3 with utterance continuation/restart and retained accumulated text. Repeated silent-timeout and browser restart simulations pass. Explicit Stop ends the app session; permissions/errors/backgrounding can end it. Windows retains its existing approximately three-minute recording limit. Physical microphone acceptance pending.

### FN-013: Intermittent loss of drawing input
- Added: October 25, 2026.
- User-reported tablet behavior: writing/drawing tools temporarily stopped accepting pen and finger strokes while buttons remained responsive and finger pan/zoom continued to work. Other drawing tools were also affected before recovery.
- Observed recovery: exit the writing tool, pan the plan and zoom in/out with fingers, then re-enter the writing tool. Writing and other tested tools worked again afterward.
- Follow-up test: after entering the photo workflow and switching between finger and S Pen input, tapping inside the Disposition text box turns it yellow without opening a keyboard or handwriting panel; the user cannot write in the field. This is a suspected trigger sequence, not yet independently reproduced.
- Immediately afterward, both finger and pen can still pan the image and select buttons, but drawing/writing actions do not work. User reports that the affected functions return after approximately 30 seconds. Recovery time is an estimate, not a measured timeout.
- Earlier tool-switch recovery may have coincided with elapsed time. Proposed isolation test, not yet performed: leave the selected tool unchanged during the failure, wait approximately 30 seconds, then attempt one stroke. Do not attribute recovery to a tool switch or timeout until verified.
- This is an observed workaround, not a confirmed fix. The trigger and root cause remain unknown; a tool or input-state problem is a hypothesis only.
- Required behavior: drawing tools remain responsive when switching between writing and navigation, without needing this reset sequence.
- Investigate tool transitions and pen/touch gesture state; verify recovery and preservation of existing annotations on the tablet.
- Status: candidate input-state fix included in 0.3.3: clear abandoned gestures, pointers, touch navigation and pen-down state at editor/tool transitions. Simulated stale-state checks pass. Root cause and physical tablet recovery remain unconfirmed; do not mark the reported intermittent failure as resolved.

### FN-014: Architectural vocabulary recognition in dictation
- Added: October 25, 2026.
- Tablet test: user dictated "Interior sill at arch window" and the recognizer transcribed "sill" as "seal". User reports recognition quality is insufficient for comfortable architectural note-taking.
- Investigate architectural vocabulary hints (for example sill, jamb, and mullion) where supported by the current recognition service, and assess an alternative speech engine if necessary. Support and improvement have not been verified; no engine change is selected or implemented.
- This is distinct from punctuation cleanup under FN-011. Punctuation alone cannot correct misrecognized technical words.
- Preserve meaning and keep text editable. Do not globally replace "seal" with "sill": both are valid inspection terms. Any correction approach must account for context and avoid silently changing observations, numbers, or measurements.
- Status: investigation completed for 0.3.3: Android requests architectural vocabulary hints from the installed provider. Provider support/accuracy, especially on the older tablet, remain unverified; no engine replacement or global word substitution was made.

### FN-015: Align Date and Project Number header boxes in exported report
- Added: October 25, 2026.
- User supplied a photograph of the exported report header showing the Date box and the AECOM Project Number box misaligned at their shared border/column boundary.
- Required fix: make the Date and Project Number boxes line up precisely. Use consistent column boundaries, box widths, border positions, and shared edges in the report template; avoid slight horizontal offsets between stacked header cells.
- Verify alignment in the actual exported report, including the PowerPoint output where applicable, not only in an in-app preview. Preserve the current header labels and values.
- Status: implemented in 0.3.3 Punch Walk exporter: Date and Project Number cells now share identical left edge and width. Actual generated PPTX XML checked; PowerPoint/device visual acceptance pending.

### FN-016: Uppercase discipline names
- Added: October 25, 2026.
- User clarification: display discipline values in all capitals, for example ARCHITECTURE, MECHANICAL, ELECTRICAL, and FIRE PROTECTION, including discipline text in report headings.
- Status: implemented in 0.3.3: uppercase discipline choices and report headings, using ARCHITECTURE. Actual app options and generated report content checked; device acceptance pending.

### FN-017: Check deletion of note and photo labels on the plan
- Added: October 25, 2026.
- User requests a check of whether existing note labels and photo labels/markers on the plan can be deleted in the current version.
- Test both annotation types. If deletion is unavailable or fails, record and fix it in the next authorized build.
- User-confirmed photo deletion behavior: delete the selected photo entry and its corresponding plan label, then close the numbering gap automatically throughout the current visit/drawing set. Example: with 20 photos and 20 labels, deleting photo 3 leaves 19 photos and labels numbered 1 through 19; former photos 4 through 20 become 3 through 19, preserving their order. The next added photo becomes 20.
- Keep photo list, plan labels, and newly generated Photo Log/Punch Walk reports synchronized. Preserve each remaining photo’s caption, location, disposition, attachments, and correct plan position as its displayed number changes. Retain discipline prefixes and zero padding where applicable.
- This supersedes the assistant’s earlier suggestion to preserve numbering gaps. Removing only a label while retaining its photo was an assistant proposal, not an approved requirement.
- Use stable internal identifiers separate from displayed numbers so renumbering cannot associate a label or report entry with the wrong photo. Already exported files remain unchanged; fresh exports reflect the new sequence. Original source photos on the device are not deleted.
- Note labels must also be deletable under FN-017; the user’s explicit sequential-renumbering example concerns photos. Do not claim note renumbering was separately confirmed.
- Verification (October 25): inspected the code packaged in Field-Notes-Android-0.3.2.apk. No individual note/photo pin Delete control is present in the editor or notes list. Tapping a pin opens its editor. Remove inside the photo editor removes an attachment, not the plan pin; saving a photo pin without any photo is blocked.
- Executed the packaged tabletEraseAt function with co-located text-note, photo-note, and ink records: it removed the ink and retained both pins. Its explicit ink-only condition excludes note/photo pins.
- Undo/Redo restores annotation history and can reverse a recent pin addition while that history remains available; it does not provide targeted deletion of an arbitrary saved pin. No physical tablet interaction was performed for this verification.
- Status: implemented in 0.3.3: editor Delete entry for notes/photos, confirmed photo renumbering across all pages, stable internal IDs, and immediate Undo/Redo for entry deletion. Two-page 20-to-19 photo deletion, association preservation, save/reload and text-note deletion tests pass. Original source files kept; physical device acceptance pending.

## Tablet test observations - October 25, 2026
- Toolbar clearance: user confirms the lower toolbar position improves response and removes the need for repeated taps on the tested tool buttons. This is partial device validation of FN-002; the S Pen menu failure remains open under FN-007.
- Photo arrows: user successfully added arrows and changed colors. Preserve this working behavior while fixing the oversized editor under FN-010.
- Report choice: user described the existing Photo Log / Punch Walk selection, then clarified this was an observation of current behavior, not a request for another selector or a new defect.
- Saved drawings: user asked whether deleting an app-saved drawing also deletes the original source. Preserve the existing separation between the app database copy and original imported file; this is a clarification question, not authorization to change file deletion behavior.
- Pen navigation: user observed drawing and panning with the stylus, while zoom uses fingers. No request to add pen zoom buttons was confirmed.
- Text entry: Disposition field turns yellow on S Pen contact without opening a keyboard or handwriting panel; subsequent temporary loss of drawing/writing actions is recorded under FN-013. Whether handwriting-to-text support, field focus, or another input-state issue causes this remains unconfirmed.
- Testing collection ended when the user authorized the next build on October 25, 2026. Release 0.3.3 includes the implementation and candidate fixes described above; physical-device acceptance remains open.

## Next build timing
- User explicitly authorized the next build during the October 25, 2026 voice session. Release 0.3.3 was built from the 13 open items FN-005 through FN-017; do not describe candidate/device-dependent work as fully verified.

## List history
An existing standalone update list was not located. This list starts with the request above; it does not claim to include all previous requests.

## Release 0.3.1 - October 25, 2026
- Browser package and existing-installation Windows updater prepared; Android and Windows source included in source archive.
- Android APK build blocked because Android SDK is unavailable. No new APK is included.
- Windows updater was not run on Windows. Physical S Pen behavior remains unverified.
- Automated checks cover existing drawing/voice/export recovery, Android web bridge, browser/mobile layout, trusted simulated pen taps, new workflow fields, photo arrows, custom filenames and Punch Walk PowerPoint output.

## Release 0.3.2 - October 25, 2026
- Windows: complete portable x64 package, including executable and existing local speech engine. Extract the whole ZIP and run Field-Notes.exe; no Node.js installation required. Same app name, origin and user-data location preserve existing drawings.
- Android: compiled installable APK, version code 32, same com.fieldnotes.preview package and original test key. APK signature verified. This release includes an APK, superseding the SDK-blocked 0.3.1 attempt above.
- iPhone/iPad: complete browser/PWA folder. Requires HTTPS hosting and Safari Add to Home Screen. Keep an existing deployment at the same URL to retain its local browser drawings. Hosting has not been changed or published by this task.
- Source continuity: Windows code is in resources/app; an Android source ZIP and QA scripts are included under the Windows package's Developer folder. Browser package contains its web source.
- Export type changes also set visit type and matching plan labels; previously captured caption/location/photos/Disposition remain available.
- Backups include project/report metadata, photo identifiers, arrow records, marked photos, and original marked-photo copies. App backup ZIP import remains unsupported, as before.
- Automated checks passed shared workflow, renderer pages for Windows and Android (native bridge mocked), existing photo-log and vector PDF crop/rotation checks, filename cancellation, save/reload, and browser service-worker offline PDF loading. PowerPoint XML and relationship checks passed; long-text report layout was visually inspected after fixing inherited paragraph spacing.
- Limits: Windows executable/microphone/camera, Android native activity/camera/file picker, physical S Pen and actual iPhone Safari were not exercised on their target devices. Tablet input remains a candidate fix until tested on the tablet.


## Release 0.3.3 - October 25, 2026
- Authorized by the user in the testing voice session. Android, Windows portable, PWA and full source packages prepared.
- Android: version code 33; package name unchanged; compiled APK signature verified and certificate matches 0.3.2. Existing app data locations retained on Android and Windows.
- Automated app checks pass on all three entry pages for setup, simulated S Pen Menu, selected voice target, stale input reset, image editor fit, two-page photo deletion/renumbering with stable IDs, Undo/Redo, page navigation, four PDF turns, actual PDF/PPTX export and save/reload. Android speech and browser speech providers are mocked.
- Legacy regression checks pass for drawing, eraser cancellation, Photo Log generation, archived drawings, PDF crop/rotation/Unicode, whole-drawing deletion isolation and Android chunked binary exports/failure cleanup. Old QA fixture assumptions were corrected without weakening product expectations.
- FN-011 remains partial: formatting is provider-dependent, with a conservative final-period/capitalization fallback, not full contextual punctuation. FN-014 vocabulary hints are optional provider inputs. FN-013 and FN-007 remain candidate device fixes until actual Samsung testing. FN-002 physical recheck remains open. Windows recording retains its prior duration cap.
- The changed PDF was rendered and inspected; PPTX header coordinates/text were inspected in generated XML, not rendered in PowerPoint. Windows native execution, physical microphone/camera/S Pen and iPhone Safari were not exercised. PWA hosting was not published or changed.
- Full behavior and first-device-check instructions are included in RELEASE-0.3.3.md in the deliverables.

## Post-0.3.3 tablet feedback - October 25, 2026

### FN-018: Scale-accurate Note and Photo plan labels
- Note and Photo labels must retain their specified 3/16-inch printed size at exported sheet scale. In the editor they must zoom proportionally with the plan, rather than staying fixed-size on-screen overlays.
- Verify physical printed size at multiple editing zoom levels and in annotated PDF exports.
- Status: requested; pending implementation and verification.

### FN-019: S Pen input delay after switching from handwriting to dictation
- Recurring intermittent tablet bug: handwriting with S Pen in a Note or Photo field, then switching to voice dictation, temporarily makes the pen unresponsive. It begins working again after waiting, without restarting the app.
- Investigate input focus, Samsung handwriting keyboard/IME state, speech-recognition lifecycle, and stylus pointer event handling. The cause is not confirmed.
- Required: switch between pen handwriting and voice dictation without a recovery delay. Test repeated alternation on a physical Samsung tablet.
- Related: FN-013 intermittent drawing input loss, and FN-002/FN-007 stylus menu activation issues. Do not close those issues on the strength of automated simulations.
- Status: recurring, unresolved, awaiting physical-device investigation.

### FN-020: Remove dictation language selector
- In the Photo editor (and equivalent Note dictation UI), remove the visible Language dropdown. English is the only supported language for this version; use English automatically.
- Do not remove or break dictation itself.
- Status: requested; pending implementation.

### FN-021: Simplify Restore original dictation control
- User does not understand the purpose of the visible "Restore original dictation" button and requests its removal if unnecessary.
- First verify whether this control is the only way to recover raw dictated text after automatic punctuation. Prefer removing it from the main Photo/Note form while preserving raw transcription internally and a recovery path if needed, rather than silently deleting data.
- Keep the UI compact; do not display a confusing recovery control by default.
- Status: requested; behavior review and implementation pending.

### FN-022: Photo attachment controls on one row
- In the Photo editor, place "Attach photos" on the left and "Take a photo" on the right, side by side, with aligned button heights and sufficient touch targets.
- Keep file selection, device camera capture, and existing attached images functional on Android and supported iPhone/browser interfaces. Allow responsive stacking only on exceptionally narrow screens.
- Screenshot supplied October 25, 2026 shows vertically stacked controls and unnecessary vertical space.
- Status: requested; pending implementation and device verification.

### FN-023: Selecting a plan label immediately dismisses its editor
- Added: October 25, 2026. User-provided tablet screenshots show Note 2 directly under the region where the editor popup's Cancel/Save/Delete controls appear.
- Observed: tapping a Note marker opens its editor but the popup immediately closes, apparently as though the original tap also activated Cancel. Root cause (tap-through, duplicate pointer/click event, or modal event propagation) is not yet verified.
- Required: opening a Note or Photo editor must consume the opening pointer gesture; no modal action may be activated by the same gesture. Keep the popup open until a distinct intentional Save, Cancel, Delete, or other permitted dismiss action.
- Test overlapping markers/buttons with both finger and S Pen, including touch-down/move/up and delayed click event paths. Fix event handling, not just popup placement.
- Status: confirmed user-reported behavior; pending code investigation and physical tablet verification.
