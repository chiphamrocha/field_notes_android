const fs=require('fs'),vm=require('vm'),assert=require('assert');
const {fixture,settle}=require('./tablet.cjs');
(async()=>{
 const f=fixture();await settle();f.get('projectSave').onclick();await settle();
 const {run}=f;
 const source=fs.readFileSync('app/src/main/assets/web/next-updates.js','utf8');
 run('function fieldNotesLabels(){}');
 run(source.slice(source.indexOf('function fnRenumberPhotos(){'),source.indexOf('function fnRenumberNotes(){')));
 run("pages=[emptyPage(),emptyPage()];pageIndex=0;lab.marks=pages[0].marks;lab.marks.push({id:'a',kind:'note',noteType:'photo',number:4,x:15,y:20,text:'First',photos:[{id:'a1'},{id:'a2'}]});pages[1].marks.push({id:'b',kind:'note',noteType:'photo',number:10,x:30,y:40,text:'Second',photos:[{id:'b1'}]});fnRenumberPhotos()");
 const data=JSON.parse(run('JSON.stringify(pages.map(p=>p.marks))'));
 assert.deepEqual(data.map(p=>p[0].number),[1,2]);
 assert.deepEqual(data[0][0].photos.map(p=>p.number),[1,1]);
 assert.deepEqual(data.map(p=>[p[0].id,p[0].text,p[0].x]),[['a','First',15],['b','Second',30]]);
 // Exercise the shipped modal event guard with a delayed compatibility click.
 const s=fs.readFileSync('app/src/main/assets/web/fixes-036.js','utf8');
 const listeners={};let opens=0;
 const context={showEntry(){opens++;},$:()=>({addEventListener(t,fn){listeners[t]=fn;}})};
 vm.createContext(context);
 vm.runInContext(s.slice(s.indexOf(' let editorPointerReady='),s.indexOf(' // Re-enable the pen')),context);
 const button={closest:()=>true};let prevented=0;
 const click=detail=>({detail,target:button,preventDefault(){prevented++;},stopImmediatePropagation(){}});
 context.showEntry();listeners.click(click(1));assert.equal(prevented,1);
 // No timer expiration can permit the opening gesture's delayed click.
 listeners.click(click(1));assert.equal(prevented,2);
 listeners.pointerdown();listeners.click(click(1));assert.equal(prevented,2);
 context.showEntry();listeners.click(click(0));assert.equal(prevented,2);
 assert.equal(opens,2);
 console.log('PASS: multi-attachment numbering across pages preserves IDs/content; modal rejects opening compatibility clicks and allows distinct pointer/keyboard actions.');
})().catch(e=>{console.error(e);process.exitCode=1});
