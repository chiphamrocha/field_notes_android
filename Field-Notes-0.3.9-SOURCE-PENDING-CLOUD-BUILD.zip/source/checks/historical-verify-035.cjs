const {chromium}=require('playwright'),assert=require('assert'),fs=require('fs');
const http=require('http'),path=require('path');
const root=path.resolve('app/src/main/assets/web');
const server=http.createServer((req,res)=>{const file=path.resolve(root,'.'+decodeURIComponent(req.url.split('?')[0]));if(!file.startsWith(root+'/')){res.writeHead(403);return res.end();}try{res.setHeader('Content-Type',({'.js':'application/javascript','.mjs':'application/javascript','.html':'text/html','.css':'text/css','.ttf':'font/ttf'})[path.extname(file)]||'application/octet-stream');res.end(fs.readFileSync(file));}catch{res.writeHead(404);res.end();}});
(async()=>{
 await new Promise(r=>server.listen(8765,'127.0.0.1',r));
 fs.mkdirSync('build/qa',{recursive:true});
 const b=await chromium.launch({executablePath:process.env.FIELD_NOTES_BROWSER||chromium.executablePath(),headless:true,args:['--no-sandbox']});
 const p=await b.newPage({viewport:{width:1000,height:1300}}),errors=[];
 p.on('pageerror',e=>errors.push(e.message));
 await p.goto('http://127.0.0.1:8765/tablet.html');await p.waitForFunction(()=>!tablet.restoring);
 await p.evaluate(()=>{document.querySelectorAll('dialog[open]').forEach(x=>x.close());projectDetailsSeen=true;});
 const initial=await p.evaluate(()=>{
  const c=document.createElement('canvas');c.width=400;c.height=200;const ctx=c.getContext('2d');ctx.fillStyle='#ff0000';ctx.fillRect(0,0,200,200);ctx.fillStyle='#0000ff';ctx.fillRect(200,0,200,200);window.testImage=c.toDataURL('image/png');
  lab.marks.splice(0);for(let n=1;n<=9;n++)lab.marks.push({id:'tag-'+n,kind:'note',noteType:'photo',pinOnly:true,number:n,x:100+n*60,y:300,photos:[{id:'image-'+n,name:'Site-photo.jpg',type:'image/png',dataUrl:testImage,number:n}]});
  lab.marks[3].photos.push({id:'extra-image',name:'Site-photo.jpg',type:'image/png',dataUrl:testImage});tabletAssignPhotoNumbers();
  const next=nextNoteNumber('photo');
  lab.marks.push({id:'tag-10',kind:'note',noteType:'photo',pinOnly:true,number:next,x:600,y:400,photos:[{name:'Site-photo.jpg',type:'image/png',dataUrl:testImage}]});tabletAssignPhotoNumbers();tablet.revision++;tabletRender();
  return {next,number:lab.marks[3].number,attachments:lab.marks[3].photos.map(x=>x.number),last:lab.marks.at(-1).number,selector:!!document.getElementById('annotationSize')};
 });
 assert.deepEqual(initial,{next:10,number:4,attachments:[4,4],last:10,selector:false});
 console.log('PASS numbering: extra attachment stays under 4; next location is 10.');
 const sizing=await p.evaluate(()=>{const a=screenStyle();lab.view={x:250,y:175,w:500,h:350};tabletRender();const c=screenStyle();const r=+document.querySelector('#tablet-pins circle').getAttribute('r');return {a:a.pinRadius,c:c.pinRadius,inches:r*2/printGeometry(pages[0]).fit/72};});
 assert.equal(sizing.a,sizing.c);assert.ok(Math.abs(sizing.inches-3/16)<1e-8);
 await p.evaluate(()=>{lab.view={x:0,y:0,w:1000,h:700};tabletRender();showEntry({...lab.marks[3],photos:lab.marks[3].photos.map(p=>({...p}))},lab.marks[3]);});
 assert.equal(await p.locator('#notePhotoList [data-markup-photo]').count(),2);assert.equal(await p.locator('#notePhotoList figcaption').first().innerText(),'Edit\nRemove');
 await p.locator('[data-markup-photo="0"]').click();await p.waitForFunction(()=>photoEditor!==null);
 await p.locator('#photoToolCrop').click();
 const r=await p.locator('#photoMarkupCanvas').boundingBox();
 await p.mouse.move(r.x+r.width*.5,r.y+1);await p.mouse.down();await p.mouse.move(r.x+r.width-1,r.y+r.height-1,{steps:6});await p.mouse.up();
 await p.locator('#savePhotoArrows').click();
 const cropped=await p.evaluate(async()=>{const photo=pending.photos[0],im=new Image();im.src=photo.dataUrl;await im.decode();const c=document.createElement('canvas');c.width=im.width;c.height=im.height;c.getContext('2d').drawImage(im,0,0);return {original:photo.originalDataUrl===testImage,crop:photo.crop,w:im.width,h:im.height,pixel:[...c.getContext('2d').getImageData(im.width/2,im.height/2,1,1).data]};});
 assert.ok(cropped.original);assert.ok(cropped.w<cropped.h*1.1);assert.ok(cropped.pixel[2]>240&&cropped.pixel[0]<20);
 await p.locator('[data-markup-photo="0"]').click();await p.waitForFunction(()=>photoEditor!==null);await p.locator('#resetPhotoCrop').click();await p.locator('#photoMarkupSheet button[value="cancel"]').click();
 assert.ok(await p.evaluate(()=>pending.photos[0].crop.x>.49));
 await p.locator('[data-markup-photo="0"]').click();await p.waitForFunction(()=>photoEditor!==null);await p.locator('#resetPhotoCrop').click();await p.locator('#savePhotoArrows').click();
 assert.ok(await p.evaluate(()=>pending.photos[0].dataUrl===testImage));
 console.log('PASS crop selection, pixel output, Cancel, reopen and Reset preserve original.');
 await p.locator('[data-markup-photo="0"]').click();await p.waitForFunction(()=>photoEditor!==null);
 const ar=await p.locator('#photoMarkupCanvas').boundingBox();await p.mouse.move(ar.x+ar.width*.2,ar.y+ar.height*.5);await p.mouse.down();await p.mouse.move(ar.x+ar.width*.7,ar.y+ar.height*.5,{steps:6});await p.mouse.up();await p.locator('#savePhotoArrows').click();assert.equal(await p.evaluate(()=>pending.photos[0].arrows.length),1);
 await p.screenshot({path:'build/qa/photo-editor-035.png'});
 await p.locator('#saveEntry').click();await p.waitForFunction(()=>!pending&&!document.getElementById('entry').open);
 // Short tap and held drag use real pointer events on the drawing.
 await p.evaluate(()=>{tablet.mode='pan';tablet.revision++;tabletRender();});
 let pin=await p.locator('#tablet-pins circle').first().boundingBox();
 await p.mouse.move(pin.x+pin.width/2,pin.y+pin.height/2);await p.mouse.down();await p.waitForTimeout(500);await p.mouse.move(pin.x+pin.width/2+60,pin.y+pin.height/2+20,{steps:10});await p.mouse.up();
 assert.equal(await p.evaluate(()=>!!pending),false);assert.ok(await p.evaluate(()=>lab.marks[0].x>160));assert.equal(await p.evaluate(()=>lab.marks[0].number),1);
 pin=await p.locator('#tablet-pins circle').first().boundingBox();await p.mouse.click(pin.x+pin.width/2,pin.y+pin.height/2);assert.ok(await p.evaluate(()=>pending!==null));
 await p.evaluate(()=>{window.tabletPenDown=true;document.getElementById('photoLocation').focus();});assert.equal(await p.evaluate(()=>window.tabletPenDown),false);
 await p.evaluate(()=>document.getElementById('entry').close('cancel'));
 console.log('PASS hold-drag preserves ID/contents; short tap opens editor; field focus clears stale pen flag.');
 // Export report and annotated PDF from real modules, with actual images and font.
 const result=await p.evaluate(async()=>{
  const items=tabletPhotoLogItems(),pdf=await fieldNotesBuildReportPdf(items,{...photoLogMetadata,projectNumber:'QA',visitType:'punch'});
  window.reportPdf=Array.from(pdf);const fontBytes=new Uint8Array(await(await fetch('vendor/fonts/DejaVuSans.ttf')).arrayBuffer());
  window.planPdf=Array.from(await fieldNotesPdf.build({sourceKind:'sample',pages:pages,fontBytes,fontkit,metadata:{}}));
  await tabletPersist();return {items:items.length,tag4:items.filter(i=>i.number===4).length,pages:(await PDFLib.PDFDocument.load(pdf)).getPageCount()};
 });
 assert.equal(result.items,11);assert.equal(result.tag4,2);assert.equal(result.pages,11);
 fs.writeFileSync('build/qa/report-035.pdf',Buffer.from(await p.evaluate(()=>reportPdf)));fs.writeFileSync('build/qa/plan-035.pdf',Buffer.from(await p.evaluate(()=>planPdf)));
 await p.reload();await p.waitForFunction(()=>!tablet.restoring);assert.equal(await p.evaluate(()=>lab.marks.length),10);assert.equal(await p.evaluate(()=>lab.marks[3].photos.length),2);
 assert.deepEqual(errors,[]);console.log('PASS real PDF report, duplicate tag attachments, annotated PDF, saved draft reload; no browser errors.');
 const android=await b.newPage({viewport:{width:800,height:1200},hasTouch:true});const nativeErrors=[];android.on('pageerror',e=>nativeErrors.push(e.message));
 await android.addInitScript(()=>{window.__exports=[];window.FieldNotesNative={startSpeech(){},stopSpeech(){},cancelSpeech(){},beginExport(id,name,mime,size){window.__export={id,name,mime,size,chunks:[]};return true;},appendExport(id,chunk){window.__export.chunks.push(chunk);return true;},finishExport(){window.__exports.push(window.__export);return true;},abortExport(){}};});
 await android.goto('http://127.0.0.1:8765/index.html');await android.waitForFunction(()=>!tablet.restoring);
 await android.evaluate(()=>{document.querySelectorAll('dialog[open]').forEach(d=>d.close());photoLogMetadata.visitType='punch';const c=document.createElement('canvas');c.width=300;c.height=600;c.getContext('2d').fillRect(0,0,300,600);lab.marks.splice(0,lab.marks.length,{id:'long-photo',kind:'note',noteType:'photo',number:999,x:400,y:400,photos:[{name:'Site-photo.jpg',type:'image/png',dataUrl:c.toDataURL()}]},{id:'note',kind:'note',noteType:'text',number:1,x:500,y:400,photos:[]});tabletAssignPhotoNumbers();tablet.revision++;tabletRender();showEntry({...lab.marks[0],photos:lab.marks[0].photos.map(x=>({...x}))},lab.marks[0]);});
 assert.equal(await android.locator('#entryTitle').innerText(),'Photo A999');assert.ok(!(await android.locator('#notePhotoList').innerText()).includes('Site-photo'));
 await android.locator('[data-markup-photo="0"]').click();await android.waitForFunction(()=>photoEditor!==null);
 for(const viewport of [{width:800,height:1200},{width:1200,height:600},{width:800,height:480}]){await android.setViewportSize(viewport);await android.waitForTimeout(80);const boxes=await android.evaluate(()=>{const s=document.getElementById('photoMarkupSheet').getBoundingClientRect(),a=document.getElementById('savePhotoArrows').getBoundingClientRect(),c=document.getElementById('photoMarkupCanvas').getBoundingClientRect();return {bottom:a.bottom,top:a.top,limit:innerHeight,cw:c.width,ch:c.height,sw:s.width};});assert.ok(boxes.bottom<=boxes.limit+1&&boxes.top>=0);assert.ok(boxes.ch>24&&boxes.cw<=boxes.sw);}
 await android.setViewportSize({width:800,height:1200});await android.screenshot({path:'build/qa/android-photo-editor-035.png'});
 await android.locator('#photoMarkupSheet button[value="cancel"]').click();await android.locator('#entry button[value="cancel"]').click();
 const sizes=await android.evaluate(()=>{const c=document.querySelector('#tablet-pins circle').getBBox(),h=document.querySelector('#tablet-pins polygon').getBBox();return {circle:c.height,hexagon:h.height};});assert.ok(Math.abs(sizes.circle-sizes.hexagon)<.001);
 await android.waitForFunction(()=>!pending&&!tablet.active&&!tablet.restoring&&!loadingPage&&!document.getElementById('entry').open);await android.evaluate(()=>{document.getElementById('phoneMenu').showModal();reportPdfButton.onclick();});await android.waitForTimeout(700);console.log('Android export state',await android.evaluate(()=>({status:document.getElementById('photoLogStatus').textContent,pending:!!pending,active:!!tablet.active,loading:loadingPage,dialog:document.getElementById('saveNameSheet').open})));await android.locator('#saveNameSheet button[value="save"]').click();await android.waitForFunction(()=>window.__exports.length>0);
 const exported=await android.evaluate(()=>__exports[0]);assert.equal(exported.mime,'application/pdf');const nativePdf=Buffer.concat(exported.chunks.map(c=>Buffer.from(c,'base64')));assert.equal(nativePdf.length,exported.size);assert.equal(nativePdf.subarray(0,4).toString(),'%PDF');
 assert.deepEqual(nativeErrors,[]);console.log('PASS Android entry, A999, equal circle/hexagon heights, portrait/landscape/keyboard-sized editor, native PDF export bridge.');

 // Related export and deletion paths must also support multiple images per tag.
 const ppt=await p.evaluate(async()=>{const template=await(await fetch('templates/photographic-log.pptx')).arrayBuffer();const items=tabletPhotoLogItems();const bytes=await punchWalkExporter.build({template,items,metadata:{...photoLogMetadata,visitType:'punch'}});const z=await JSZip.loadAsync(bytes);return {images:Object.keys(z.files).filter(x=>/^ppt\/media\/punch-/.test(x)).length};});assert.equal(ppt.images,11);
 await p.evaluate(()=>{window.savedBackup=null;downloadBlob=async(blob,name)=>{window.savedBackup={name,bytes:Array.from(new Uint8Array(await blob.arrayBuffer()))};return true;};});
 await p.evaluate(async()=>document.getElementById('download').onclick());
 const backup=await p.evaluate(async()=>{const z=await JSZip.loadAsync(new Uint8Array(savedBackup.bytes));const json=JSON.parse(await z.file('annotations.json').async('string'));return {files:Object.keys(z.files).filter(x=>/^photos\/.*\.(jpg|png)$/.test(x)),photos:json.pages[0].marks[3].photos};});assert.equal(backup.files.length,11);assert.ok(backup.files.includes('photos/page-1-photo-4-1.jpg'));assert.ok(backup.files.includes('photos/page-1-photo-4-2.png'));assert.equal(backup.photos.length,2);assert.ok(backup.photos[0].originalFile);
 p.on('dialog',d=>d.accept());await p.evaluate(()=>fnDeleteMark(lab.marks[0]));assert.equal(await p.evaluate(()=>lab.marks.length),9);assert.equal(await p.evaluate(()=>lab.marks[0].number),1);assert.deepEqual(await p.evaluate(()=>lab.marks[2].photos.map(x=>x.number)),[3,3]);
 await p.evaluate(()=>document.getElementById('undo').onclick());assert.equal(await p.evaluate(()=>lab.marks.length),10);assert.deepEqual(await p.evaluate(()=>lab.marks[3].photos.map(x=>x.number)),[4,4]);
 console.log('PASS PPTX image retention, real backup ZIP unique filenames/original/crop metadata, delete/renumber/Undo with multiple attachments.');
 await b.close();server.close();
})().catch(e=>{console.error(e);server.close();process.exit(1)});
