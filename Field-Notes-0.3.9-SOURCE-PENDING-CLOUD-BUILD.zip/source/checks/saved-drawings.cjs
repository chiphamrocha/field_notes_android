const fs=require('node:fs'),assert=require('node:assert/strict'),{fixture,settle}=require('./tablet.cjs');
(async()=>{
  const f=fixture();await settle();f.get('projectSave').onclick();await settle();f.run(fs.readFileSync('app/src/main/assets/web/desktop-updates.js','utf8'));
  f.run("sourceFile=new File(['original'],'First.jpg',{type:'image/jpeg'});lab.marks.push({kind:'text',x:20,y:30,text:'Original drawing note'})");const first=f.run('tabletDocumentId');await f.run('tabletArchiveCurrent()');
  f.run("tabletDocumentId='second';sourceFile=null;pages=[emptyPage()];pageIndex=0;lab.marks=pages[0].marks;lab.marks.push({kind:'text',x:20,y:30,text:'Second drawing note'})");await f.run('tabletArchiveCurrent()');
  f.context.confirm=()=>false;await f.run('tabletDeleteSavedDrawing('+JSON.stringify(first)+')');assert.ok(await f.run('tabletReadStored("drawing:"+'+JSON.stringify(first)+')'),'cancel preserves drawing');
  f.context.confirm=()=>true;await f.run('tabletDeleteSavedDrawing('+JSON.stringify(first)+')');assert.equal(await f.run('tabletReadStored("drawing:"+'+JSON.stringify(first)+')'),undefined);assert.ok(await f.run('tabletReadStored("drawing:second")'));assert.equal(f.run('lab.marks[0].text'),'Second drawing note','deleting another drawing preserves current');
  await f.run("tabletDeleteSavedDrawing('second')");assert.equal(await f.run('tabletReadStored("drawing:second")'),undefined);assert.equal(f.run('lab.marks.length'),0);assert.notEqual(f.run('tabletDocumentId'),'second');assert.equal((await f.run('tabletReadStored("current")')).pages[0].marks.length,0,'deleted current cannot reappear on restart');
  const html=fs.readFileSync('app/src/main/assets/web/tablet.html','utf8');for(const id of ['openHeading','exportHeading','exportNotesMenu'])assert.ok(html.includes('id="'+id+'"'));assert.ok(html.includes('Export annotated PDF'));assert.ok(!html.includes('width="25"'));assert.ok(html.includes('width="18"'));
  console.log('PASS: deletion confirmation/cancel, separate drawing isolation, current-drawing reset and restart protection, grouped menus and smaller icons.');
})().catch(error=>{console.error(error);process.exitCode=1;});
