// Real Chromium app behavior; Android hardware services remain mocked.
const {chromium}=require('playwright'),fs=require('fs'),path=require('path'),assert=require('assert');
const root=path.resolve('app/src/main/assets/web');
(async()=>{
 const browser=await chromium.launch({executablePath:process.env.FIELD_NOTES_BROWSER||undefined,headless:true,args:['--no-sandbox']});
 const context=await browser.newContext({viewport:{width:800,height:1100},hasTouch:true});
 await context.route('https://appassets.androidplatform.net/**',async route=>{
  const url=new URL(route.request().url()),file=path.resolve(root,decodeURIComponent(url.pathname.replace('/assets/web/','')));
  if(!file.startsWith(root+path.sep)||!fs.existsSync(file))return route.fulfill({status:404,body:''});
  await route.fulfill({status:200,contentType:({'.js':'application/javascript','.mjs':'application/javascript','.html':'text/html','.css':'text/css','.pdf':'application/pdf','.ttf':'font/ttf'})[path.extname(file)]||'application/octet-stream',body:fs.readFileSync(file)});
 });
 await context.addInitScript(()=>{
  window.__exports=[];
  window.FieldNotesNative={startSpeech(id){window.__voice=id;setTimeout(()=>window.fieldNotesAndroidSpeech(id,'ready',''),0);},stopSpeech(id){window.fieldNotesAndroidSpeech(id,'final','Check door clearance');},cancelSpeech(){},beginExport(id,name,mime,size){window.__export={id,name,mime,size,chunks:[]};return true;},appendExport(id,chunk){window.__export.chunks.push(chunk);return true;},finishExport(){window.__exports.push(window.__export);return true;},abortExport(){}};
 });
 const page=await context.newPage(),errors=[];page.on('pageerror',e=>errors.push(e.message));
 try{
  await page.goto('https://appassets.androidplatform.net/assets/web/index.html');
  await page.waitForFunction(()=>!tablet.restoring);
  await page.locator('#logName').fill('Recovery QA');await page.locator('#logProject').fill('FN-QA');await page.locator('#projectSave').click();
  await page.evaluate(()=>{
   const canvas=document.createElement('canvas');canvas.width=400;canvas.height=200;
   const ctx=canvas.getContext('2d');ctx.fillStyle='red';ctx.fillRect(0,0,200,200);ctx.fillStyle='blue';ctx.fillRect(200,0,200,200);window.testPhoto=canvas.toDataURL();
   lab.marks.splice(0);for(let n=1;n<=10;n++)lab.marks.push({id:'tag-'+n,kind:'note',noteType:'photo',pinOnly:true,number:n,x:100+n*60,y:300,text:'Condition '+n,photos:[{id:'photo-'+n,name:'site.png',type:'image/png',dataUrl:testPhoto}]});
   lab.marks[3].photos.push({id:'extra-photo',name:'second.png',type:'image/png',dataUrl:testPhoto});tabletAssignPhotoNumbers();tablet.revision++;tabletRender();
  });
  assert.equal(await page.evaluate(()=>nextNoteNumber('photo')),11);
  assert.deepEqual(await page.evaluate(()=>lab.marks[3].photos.map(p=>p.number)),[4,4]);
  const size=await page.evaluate(()=>{const before=screenStyle().pinRadius;lab.view={x:0,y:0,w:500,h:350};tabletRender();return {before,after:screenStyle().pinRadius,inches:2*screenStyle().pinRadius/printGeometry(pages[0]).fit/72};});
  assert.equal(size.before,size.after);assert.ok(Math.abs(size.inches-3/16)<1e-8);
  // The opening gesture has no authority over Cancel/Save, even after 300 ms.
  await page.evaluate(()=>{lab.view={x:0,y:0,w:1000,h:700};tabletRender();showEntry({...lab.marks[3],photos:lab.marks[3].photos.map(p=>({...p}))},lab.marks[3]);});
  await page.waitForTimeout(450);
  await page.locator('#entry button[value="cancel"]').dispatchEvent('click',{detail:1});
  assert.equal(await page.locator('#entry').evaluate(e=>e.open),true);
  await page.locator('#photoLocation').fill('Room 101');
  await page.locator('#voice').click();await page.waitForFunction(()=>!!window.__voice);await page.locator('#stopVoice').click();
  await page.waitForFunction(()=>!document.getElementById('saveEntry').disabled);
  assert.match(await page.locator('#photoLocation').inputValue(),/Check door clearance/i);
  assert.equal(await page.locator('#text').inputValue(),'Condition 4');
  // Crop then cancel/reset, and arrows remain separately editable.
  await page.locator('[data-markup-photo="0"]').click();await page.waitForFunction(()=>photoEditor!==null);
  await page.locator('#photoEditCrop').click();
  let rect=await page.locator('#photoMarkupCanvas').boundingBox();
  await page.mouse.move(rect.x+rect.width*.52,rect.y+rect.height*.05);await page.mouse.down();await page.mouse.move(rect.x+rect.width*.98,rect.y+rect.height*.95,{steps:5});await page.mouse.up();
  await page.locator('#savePhotoArrows').click();
  assert.ok(await page.evaluate(()=>pending.photos[0].crop.x>.5&&pending.photos[0].originalDataUrl===testPhoto));
  await page.locator('[data-markup-photo="0"]').click();await page.waitForFunction(()=>photoEditor!==null);await page.locator('#resetPhotoCrop').click();
  await page.locator('#photoMarkupSheet button[value="cancel"]').click();assert.ok(await page.evaluate(()=>pending.photos[0].crop.x>.5));
  await page.locator('[data-markup-photo="0"]').click();await page.waitForFunction(()=>photoEditor!==null);await page.locator('#resetPhotoCrop').click();await page.locator('#savePhotoArrows').click();
  assert.equal(await page.evaluate(()=>pending.photos[0].dataUrl===testPhoto),true);
  await page.locator('[data-markup-photo="0"]').click();await page.waitForFunction(()=>photoEditor!==null);
  for(const viewport of [{width:800,height:1100},{width:1100,height:600},{width:800,height:480}]){
   await page.setViewportSize(viewport);await page.waitForTimeout(100);
   const fit=await page.locator('#savePhotoArrows').boundingBox();assert.ok(fit.y>=0&&fit.y+fit.height<=viewport.height+1,'Photo actions fit visible height');
  }
  await page.setViewportSize({width:800,height:1100});
  rect=await page.locator('#photoMarkupCanvas').boundingBox();await page.mouse.move(rect.x+rect.width*.2,rect.y+rect.height*.5);await page.mouse.down();await page.mouse.move(rect.x+rect.width*.8,rect.y+rect.height*.5,{steps:5});await page.mouse.up();await page.locator('#savePhotoArrows').click();
  assert.equal(await page.evaluate(()=>pending.photos[0].arrows.length),1);
  await page.locator('#saveEntry').click();await page.waitForFunction(()=>!pending);
  // Held move retains tag identity, short release opens editor.
  await page.evaluate(()=>{tablet.mode='pan';tabletRender();});
  let pin=await page.locator('#tablet-pins circle').first().boundingBox();
  await page.mouse.move(pin.x+pin.width/2,pin.y+pin.height/2);await page.mouse.down();await page.waitForTimeout(480);await page.mouse.move(pin.x+pin.width/2+60,pin.y+pin.height/2+20,{steps:5});await page.mouse.up();
  assert.equal(await page.evaluate(()=>lab.marks[0].id),'tag-1');assert.ok(await page.evaluate(()=>lab.marks[0].x>170));
  pin=await page.locator('#tablet-pins circle').first().boundingBox();await page.mouse.click(pin.x+pin.width/2,pin.y+pin.height/2);assert.equal(await page.locator('#entry').evaluate(e=>e.open),true);await page.locator('#entry button[value="cancel"]').click();
  // Real PDF/PPTX/ZIP bytes use the Android chunked bridge and shared save dialog.
  await page.locator('#menuButton').click();
  for(const id of ['exportVectorPdf','exportPhotoLog','download']){
   const count=await page.evaluate(()=>__exports.length);await page.locator('#'+id).click();await page.locator('#saveNameSheet button[value="save"]').click();await page.waitForFunction(n=>__exports.length>n,count);
  }
  const exports=await page.evaluate(()=>__exports);fs.mkdirSync('build/browser-qa',{recursive:true});
  for(const item of exports){const bytes=Buffer.concat(item.chunks.map(s=>Buffer.from(s,'base64')));assert.equal(bytes.length,item.size);fs.writeFileSync(path.join('build/browser-qa',path.basename(item.name)),bytes);}
  const P=require('../app/src/main/assets/web/vendor/pdf-lib.min.js'),Zip=require('../app/src/main/assets/web/vendor/jszip.min.js');
  const pdfItem=exports.find(x=>x.mime==='application/pdf');assert.equal((await P.PDFDocument.load(Buffer.concat(pdfItem.chunks.map(x=>Buffer.from(x,'base64'))))).getPageCount(),1);
  const pptItem=exports.find(x=>x.name.endsWith('.pptx'));const ppt=await Zip.loadAsync(Buffer.concat(pptItem.chunks.map(x=>Buffer.from(x,'base64'))));assert.ok(ppt.file('ppt/presentation.xml'));
  const zipItem=exports.find(x=>x.name.endsWith('.zip'));const backup=await Zip.loadAsync(Buffer.concat(zipItem.chunks.map(x=>Buffer.from(x,'base64'))));const annotations=JSON.parse(await backup.file('annotations.json').async('string'));assert.equal(annotations.pages[0].marks[3].photos.length,2);
  await page.locator('#closeMenu').click();await page.evaluate(()=>tabletPersist());await page.reload();await page.waitForFunction(()=>!tablet.restoring);assert.equal(await page.evaluate(()=>lab.marks[3].photos.length),2);assert.equal(await page.evaluate(()=>lab.marks[0].id),'tag-1');
  await page.screenshot({path:'build/browser-qa/recovered-draft.png'});
  // Delete/renumber/Undo keeps all attachments paired to their stable marker.
  page.on('dialog',dialog=>dialog.accept());
  await page.evaluate(()=>fnDeleteMark(lab.marks[0]));
  assert.equal(await page.evaluate(()=>lab.marks.length),9);
  assert.equal(await page.evaluate(()=>lab.marks[2].id),'tag-4');
  assert.deepEqual(await page.evaluate(()=>lab.marks[2].photos.map(p=>p.number)),[3,3]);
  await page.locator('#undo').click();assert.equal(await page.evaluate(()=>lab.marks.length),10);
  assert.deepEqual(await page.evaluate(()=>lab.marks[3].photos.map(p=>p.number)),[4,4]);
  // Simulated pen activation opens Menu exactly once without a browser click.
  await page.locator('#menuButton').dispatchEvent('pointerdown',{pointerType:'pen',pointerId:71,button:0,buttons:1});
  await page.locator('#menuButton').dispatchEvent('pointerup',{pointerType:'pen',pointerId:71,button:0,buttons:0});
  assert.equal(await page.locator('#phoneMenu').evaluate(e=>e.open),true);await page.locator('#closeMenu').click();
  await page.evaluate(async()=>{const doc=await PDFLib.PDFDocument.create();doc.addPage([612,792]);doc.addPage([612,792]);await loadFile(new File([await doc.save()],'two-pages.pdf',{type:'application/pdf'}));});
  await page.waitForFunction(()=>pages.length===2&&!loadingPage);
  await page.locator('#nextPage').click();await page.waitForFunction(()=>pageIndex===1&&!loadingPage);
  await page.locator('#previousPage').click();await page.waitForFunction(()=>pageIndex===0&&!loadingPage);
  await page.locator('#rotatePage').click();await page.waitForFunction(()=>pages[0].rotation===90&&!loadingPage);
  assert.deepEqual(errors,[]);
  if(process.env.FIELD_NOTES_BASELINE_WEB){
   const legacyRoot=path.resolve(process.env.FIELD_NOTES_BASELINE_WEB);
   const upgrade=await browser.newContext({viewport:{width:800,height:1100}});let useLegacy=true;
   await upgrade.route('https://appassets.androidplatform.net/**',async route=>{
    const url=new URL(route.request().url()),base=useLegacy?legacyRoot:root,file=path.resolve(base,decodeURIComponent(url.pathname.replace('/assets/web/','')));
    if(!file.startsWith(base+path.sep)||!fs.existsSync(file))return route.fulfill({status:404,body:''});
    await route.fulfill({status:200,contentType:({'.js':'application/javascript','.mjs':'application/javascript','.html':'text/html','.css':'text/css','.pdf':'application/pdf'})[path.extname(file)]||'application/octet-stream',body:fs.readFileSync(file)});
   });
   const oldPage=await upgrade.newPage(),upgradeErrors=[];oldPage.on('pageerror',e=>upgradeErrors.push(e.message));
   await oldPage.goto('https://appassets.androidplatform.net/assets/web/index.html');await oldPage.waitForFunction(()=>!tablet.restoring);
   await oldPage.locator('#logName').fill('Existing 036 visit');await oldPage.locator('#projectSave').click();
   const expected=await oldPage.evaluate(async()=>{
    const c=document.createElement('canvas');c.width=12;c.height=12;c.getContext('2d').fillRect(0,0,12,12);
    lab.marks.splice(0,lab.marks.length,{id:'existing036-photo',kind:'note',noteType:'photo',number:4,x:321,y:456,text:'Existing caption',location:'Room 101',disposition:'Keep relationship',photos:[{id:'existing036-image',name:'old.png',type:'image/png',dataUrl:c.toDataURL(),number:4}]},{kind:'ink',points:[{x:11,y:12},{x:30,y:40}],width:2,color:'#be3c32'});
    savePage();await tabletPersist();await tabletArchiveCurrent();return {id:tabletDocumentId,marks:JSON.stringify(lab.marks)};
   });
   useLegacy=false;await oldPage.reload();await oldPage.waitForFunction(()=>!tablet.restoring);
   assert.equal(await oldPage.evaluate(()=>tabletDocumentId),expected.id);
   assert.equal(await oldPage.evaluate(()=>photoLogMetadata.projectName),'Existing 036 visit');
   const restored=await oldPage.evaluate(()=>lab.marks);
   assert.equal(restored[0].id,'existing036-photo');assert.equal(restored[0].text,'Existing caption');assert.equal(restored[0].location,'Room 101');assert.equal(restored[0].disposition,'Keep relationship');assert.equal(restored[0].x,321);assert.equal(restored[0].y,456);assert.equal(restored[0].photos[0].id,'existing036-image');assert.equal(restored[1].width,2);
   assert.ok(await oldPage.evaluate(async()=>!!(await tabletReadStored('drawing:'+tabletDocumentId))));
   assert.deepEqual(upgradeErrors,[]);await upgrade.close();
   console.log('PASS exact working 0.3.6 web assets -> candidate at unchanged origin: project, document ID, saved archive, caption/location/disposition, image IDs/coordinates and ink retained.');
  }
  console.log('PASS real Android entry: multi-image numbering, tag scale, modal gestures, selected dictation, crop/reset/cancel/arrows, editor fit, held drag, PDF/PPTX/ZIP bridge persistent draft reload, deletion/Undo, pen Menu and multi-page navigation/rotation. Native hardware remains untested.');
 }finally{await browser.close();}
})().catch(e=>{console.error(e);process.exitCode=1});
