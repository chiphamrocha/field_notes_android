# Field Notes Android recovery candidate 0.3.9

Status: source prepared; cloud build and physical tablet acceptance pending.
Do not install the archived failed 0.3.7/0.3.8 packages. Do not uninstall the
working tablet app or clear its storage.

## Provenance
The latest source snapshot is 0.3.7. Native Java matches the 0.3.4 archive.
The working 0.3.6 APK contains readable web assets, which were recovered and
compared byte-for-byte with the snapshot. No APK decompilation is represented
as original Java source. No compiled Android code from an old APK enters this
build. All vendored browser libraries, fonts, templates and licenses are included.

## Build in the cloud
Use the included GitHub Actions workflow in the public repository authorized by the user. It installs
JDK 17, Android platform 35 / Build Tools 35.0.0, Node 22 and Playwright only on
an Ubuntu cloud runner. It runs regression checks, compiles resources with aapt2,
Java with javac and bytecode with d8, then aligns with zipalign before signing.
No workstation setup is required.

Set repository Actions secret FIELD_NOTES_KEYSTORE_B64 to the recovered key's
base64 value. The original archive calls the PKCS12 file field-notes-test.jks;
its original alias is androiddebugkey and original test password is android.
Override the optional FIELD_NOTES_STORE_PASSWORD, FIELD_NOTES_KEY_PASSWORD and
FIELD_NOTES_KEY_ALIAS secrets if using separately supplied compatible material.
Never commit a private key or its base64 encoding. Without the key, CI produces
only aligned.apk, which is UNSIGNED and MUST NOT be installed.

Run Actions -> Android source build -> Run workflow, or push to main.
Download Field-Notes-0.3.9-build-and-evidence. A signed build must include
Field-Notes-Android-0.3.9.apk, signature-verification.txt, badging.txt,
SOURCE-COMMIT.txt and SHA256SUMS.txt. A successful unsigned compilation does
not establish that a signed release exists.

For a developer's Linux/cloud environment with these dependencies already
available: bash verify.sh; FIELD_NOTES_BROWSER_TESTS=1 bash verify.sh;
ANDROID_SDK_ROOT=/path/to/sdk bash build.sh. Supply FIELD_NOTES_KEYSTORE and
FIELD_NOTES_STORE_PASSWORD / KEY_PASSWORD / KEY_ALIAS to sign. The build script
refuses a signed APK whose certificate differs from the reference.

## Installation and data
Expected package com.fieldnotes.preview, versionCode 39, versionName 0.3.9.
The recovered private key matches the certificate in the supplied working
0.3.6 APK: 28bfff0b3d3d38064caaa1ba679ebb2718cfcd3ed45a3daf9160b74efd46961c.
This makes an in-place update eligible; it is not a physical installation test.
The tablet's actual installed certificate has not been read independently.

Preserve app package, WebView origin https://appassets.androidplatform.net,
entry URL /assets/web/index.html, IndexedDB names and record schema. No data
reset or destructive migration was added. Export an existing drawing's backup,
notes and annotated PDF before any candidate update. Backup ZIP import is not
supported by this app, so a backup alone is not proof of full recovery.
If Android refuses the update, retain 0.3.6 and report the exact error. Never
resolve a signature/install failure by uninstalling or clearing app storage.

See CHANGELOG.md, TESTING.md, BUILD-AND-ARCHIVE-PLAN.md and audit/ for evidence.
Historical release notes describe prior claims, not current verification.
