HISTORICAL REFERENCE ONLY. Prior release claims below are not current verification. Do not install failed 0.3.7/0.3.8 APKs.

Field Notes source update, October 23, 2026. Export filename field, 3/16 inch annotation text, adaptive high-resolution PDF preview, larger/inset toolbar touch targets, Android display name Field Notes. This is SOURCE ONLY, not a new APK. Rebuild with Android SDK and test on tablet before installation. PDF preview is re-rendered raster from original PDF at zoom; not a true vector DOM viewer. Existing exports preserve original vector PDF.
