# 0.3.9 recovery candidate - 2026-11-01

## New corrections in recovery
- Replace the 300 ms editor-button guard with a gesture boundary: delayed
  opening clicks stay blocked until a distinct pointer-down occurs in the editor.
  Keyboard activation remains available.
- Cancel stale marker-hold timers when input/tool/speech state resets; restore
  the marker position for an abandoned drag.
- Correct suggested Photo Log PDF filenames so they do not say Annotated Plan.
- Remove silent random signing-key generation. Compile all Android resources
  and Java source; align then sign and check the expected certificate.
- Add cloud CI, version code 39, source provenance and regression evidence.

## Carried forward from unverified 0.3.7 source
- One displayed photo number per plan location, shared by its attachments.
- Held marker drag, drawing-coordinate pen widths and 3/16-inch tag diameter.
- Crop/reset photo editing with original photos retained; existing colored arrows.
- Editable per-export suggested filenames, compact photo actions and status text.
- Photo Log PDF option in addition to editable PowerPoint reports. This inherited
  PDF option has limited long-text/Unicode layout and remains experimental;
  editable PowerPoint remains the established report output.

## Preserved from working 0.3.6 web assets
Compact note/photo editor, attachment/camera controls, hidden language selector,
English dictation and separate text fields, original-photo retention, current
storage identity, existing vector ink, PDF/PPTX/notes/backup workflows.

## Companion source completeness
The historical Windows companion tablet.html referenced three absent desktop
scripts. They are restored from the 0.3.3 broad source archive; Android index.html
does not load them. This does not add a Windows release.

## Open
Samsung S Pen/handwriting-to-speech lag and menu behavior need actual hardware
acceptance. Exact label comparison with the user's 111 keynote, all physical
printing checks and device camera/microphone acceptance remain unverified.
No claim that all cumulative feature requests are closed.
