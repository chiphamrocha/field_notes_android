'use strict';
// Scope: tag geometry, thinner new ink, short S Pen Menu taps and photo toolbar.
(()=>{
 const tags=fieldNotesTags;
 const label=mark=>tabletNoteType(mark)==='photo'?fieldNotesPhotoId(mark.number):String(mark.number);
 const previousMark=markSvg;
 markSvg=function(mark,style,printing=false){if(!['note','voice'].includes(mark?.kind))return previousMark(mark,style,printing);const fit=style?.tagWorldPerPoint||printGeometry(pages[pageIndex]).fit;return tags.svg(label(mark),mark.x,mark.y,fit,tabletNoteType(mark)==='photo');};
 const priorScreen=screenStyle;
 screenStyle=function(){const s=priorScreen(),fit=printGeometry(pages[pageIndex]).fit,g=tags.geometry('A999',fit);return {...s,pinRadius:g.radius,numberSize:g.textHeight,tagWorldPerPoint:fit};};
 const priorPrint=printedStyle;
 printedStyle=function(mark,page){const s=priorPrint(mark,page),fit=printGeometry(page).fit,g=tags.geometry(label(mark),fit);return {...s,pinRadius:g.radius,numberSize:g.textHeight,tagWorldPerPoint:fit};};
 tabletPinAt=function(p){const fit=printGeometry(pages[pageIndex]).fit;return [...lab.marks].reverse().find(mark=>{if(!['note','voice'].includes(mark.kind))return false;const g=tags.geometry(label(mark),fit),cy=mark.y-g.radius-g.stemLength;return Math.hypot(mark.x-p.x,cy-p.y)<Math.max(g.radius,22/screenScale());});};
 const menu=$('menuButton');let activatedAt=-Infinity;
 function activate(){activatedAt=performance.now();if(!$('phoneMenu').open)menu.onclick();}
 menu.addEventListener('pointerdown',e=>{if(e.pointerType!=='pen'||e.button>0)return;e.preventDefault();e.stopImmediatePropagation();activate();},true);
 menu.addEventListener('pointerup',e=>{if(e.pointerType==='pen'&&performance.now()-activatedAt<900){e.preventDefault();e.stopImmediatePropagation();}},true);
 menu.addEventListener('click',e=>{if(e.isTrusted&&performance.now()-activatedAt<900){e.preventDefault();e.stopImmediatePropagation();}},true);
 // Native stylus-down fallback is targeted using the DOM hit test. It neither
 // consumes native MotionEvents nor intercepts the drawing surface.
 window.fieldNotesMenuStylusDown=(nx,ny)=>{const x=nx*innerWidth,y=ny*innerHeight,target=document.elementFromPoint(x,y);if(target===menu||menu.contains(target))activate();};
 $('photoArrowColor').onchange=()=>{$('photoArrowColor').style.background=$('photoArrowColor').value;fieldNotesPhotoMode('arrows');};
 tablet.revision++;tabletRender();
})();
