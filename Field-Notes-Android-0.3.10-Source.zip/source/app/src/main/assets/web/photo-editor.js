'use strict';
// Edits stay in this draft until Apply; the surrounding note still owns Save/Cancel.
let photoEditor=null;
const markupCanvas=$('photoMarkupCanvas');
function fieldNotesArrow(context,a,w,h){const sx=a.x1*w,sy=a.y1*h,ex=a.x2*w,ey=a.y2*h,angle=Math.atan2(ey-sy,ex-sx),thickness=Math.max(4,Math.min(w,h)*.012),head=thickness*3.5;context.strokeStyle=a.color||'#ffcc00';context.fillStyle=context.strokeStyle;context.lineWidth=thickness;context.lineCap='round';context.beginPath();context.moveTo(sx,sy);context.lineTo(ex,ey);context.stroke();context.beginPath();context.moveTo(ex,ey);context.lineTo(ex-head*Math.cos(angle-.48),ey-head*Math.sin(angle-.48));context.lineTo(ex-head*Math.cos(angle+.48),ey-head*Math.sin(angle+.48));context.closePath();context.fill();}
function photoEditSnapshot(){return {crop:{...photoEditor.crop},arrows:photoEditor.arrows.map(a=>({...a})),selected:photoEditor.selected};}
function photoEditRemember(){photoEditor.history.push(photoEditSnapshot());if(photoEditor.history.length>60)photoEditor.history.shift();}
function fieldNotesSetCropCanvas(){if(!photoEditor)return;const im=photoEditor.image,crop=photoEditor.crop,f=Math.min(1,2400/Math.max(im.naturalWidth,im.naturalHeight));markupCanvas.width=Math.max(1,Math.round(im.naturalWidth*crop.w*f));markupCanvas.height=Math.max(1,Math.round(im.naturalHeight*crop.h*f));if(typeof fnFitPhotoEditor==='function')requestAnimationFrame(fnFitPhotoEditor);}
function fieldNotesPaintPhoto(draft=null,forExport=false){
 if(!photoEditor)return;const ctx=markupCanvas.getContext('2d'),w=markupCanvas.width,h=markupCanvas.height,c=photoEditor.crop,im=photoEditor.image;
 ctx.clearRect(0,0,w,h);ctx.drawImage(im,c.x*im.naturalWidth,c.y*im.naturalHeight,c.w*im.naturalWidth,c.h*im.naturalHeight,0,0,w,h);
 for(const arrow of photoEditor.arrows)fieldNotesArrow(ctx,arrow,w,h);
 if(!forExport&&photoEditor.selected>=0){const a=photoEditor.arrows[photoEditor.selected];if(a){ctx.save();ctx.strokeStyle='#00e6ff';ctx.lineWidth=Math.max(3,w/250);ctx.setLineDash([9,6]);ctx.beginPath();ctx.moveTo(a.x1*w,a.y1*h);ctx.lineTo(a.x2*w,a.y2*h);ctx.stroke();ctx.restore();}}
 if(draft){if(photoEditor.mode==='crop'){const x=Math.min(draft.x1,draft.x2)*w,y=Math.min(draft.y1,draft.y2)*h,bw=Math.abs(draft.x2-draft.x1)*w,bh=Math.abs(draft.y2-draft.y1)*h;ctx.fillStyle='rgba(25,110,210,.12)';ctx.fillRect(x,y,bw,bh);ctx.strokeStyle='#ffffff';ctx.lineWidth=Math.max(2,w/600);ctx.setLineDash([9,5]);ctx.strokeRect(x,y,bw,bh);ctx.setLineDash([]);}else fieldNotesArrow(ctx,draft,w,h);}
 $('undoPhotoArrow').disabled=!photoEditor.history.length;$('deletePhotoArrow').disabled=!photoEditor.arrows.length;
}
function fieldNotesPhotoMode(mode){if(!photoEditor)return;photoEditor.mode=mode;photoEditor.start=null;$('photoEditArrows').setAttribute('aria-pressed',String(mode==='arrows'));$('photoEditCrop').setAttribute('aria-pressed',String(mode==='crop'));$('deletePhotoArrow').setAttribute('aria-pressed',String(mode==='delete'));$('photoEditHelp').textContent=mode==='crop'?'Drag a rectangle around the part to keep.':mode==='delete'?'Tap an arrow to select it, then Delete arrow.':'Drag to add an arrow. Tap an existing arrow to select it.';fieldNotesPaintPhoto();}
async function fieldNotesOpenPhotoEditor(index){
 const target=pending,photo=target?.photos[index];if(!photo)return;const image=new Image();
 image.onload=()=>{if(target!==pending)return;photoEditor={target,index,image,crop:photo.crop&&photo.crop.w>0&&photo.crop.h>0?{...photo.crop}:{x:0,y:0,w:1,h:1},arrows:(photo.arrows||[]).map(a=>({...a})),selected:-1,history:[],start:null,mode:'arrows'};$('photoArrowColor').value='#ffcc00';$('photoArrowColor').style.background='#ffcc00';fieldNotesSetCropCanvas();fieldNotesPhotoMode('arrows');$('photoMarkupSheet').returnValue='cancel';$('photoMarkupSheet').showModal();requestAnimationFrame(fnFitPhotoEditor);};
 image.onerror=()=>{$('notePhotoStatus').textContent='Could not open the photo for editing.';};image.src=photo.originalDataUrl||photo.dataUrl;
}
function fieldNotesPhotoPoint(e){const r=markupCanvas.getBoundingClientRect();return {x:clamp((e.clientX-r.left)/r.width,0,1),y:clamp((e.clientY-r.top)/r.height,0,1)};}
function photoArrowAt(point){const r=markupCanvas.getBoundingClientRect();let best=-1,distance=15;for(let i=0;i<photoEditor.arrows.length;i++){const a=photoEditor.arrows[i],d=segmentDistance({x:point.x*r.width,y:point.y*r.height},{x:a.x1*r.width,y:a.y1*r.height},{x:a.x2*r.width,y:a.y2*r.height});if(d<distance){distance=d;best=i;}}return best;}
$('photoEditArrows').onclick=()=>fieldNotesPhotoMode('arrows');
$('photoEditCrop').onclick=()=>fieldNotesPhotoMode('crop');
$('deletePhotoArrow').onclick=()=>{if(!photoEditor)return;if(photoEditor.selected>=0){photoEditRemember();photoEditor.arrows.splice(photoEditor.selected,1);photoEditor.selected=-1;fieldNotesPaintPhoto();}else fieldNotesPhotoMode('delete');};
$('resetPhotoCrop').onclick=()=>{if(!photoEditor)return;const c=photoEditor.crop;if(c.x===0&&c.y===0&&c.w===1&&c.h===1)return;photoEditRemember();photoEditor.arrows=photoEditor.arrows.map(a=>({...a,x1:c.x+a.x1*c.w,x2:c.x+a.x2*c.w,y1:c.y+a.y1*c.h,y2:c.y+a.y2*c.h}));photoEditor.crop={x:0,y:0,w:1,h:1};photoEditor.selected=-1;fieldNotesSetCropCanvas();fieldNotesPaintPhoto();};
$('undoPhotoArrow').onclick=()=>{if(!photoEditor?.history.length)return;const previous=photoEditor.history.pop();Object.assign(photoEditor,previous);photoEditor.start=null;fieldNotesSetCropCanvas();fieldNotesPaintPhoto();};
$('cancelPhotoEdits').onclick=()=>$('photoMarkupSheet').close('cancel');
markupCanvas.addEventListener('pointerdown',e=>{if(!photoEditor||photoEditor.start||e.button>0)return;e.preventDefault();markupCanvas.setPointerCapture(e.pointerId);photoEditor.start={...fieldNotesPhotoPoint(e),id:e.pointerId};});
markupCanvas.addEventListener('pointermove',e=>{if(photoEditor?.start?.id!==e.pointerId||photoEditor.mode==='delete')return;const a=photoEditor.start,b=fieldNotesPhotoPoint(e);fieldNotesPaintPhoto({x1:a.x,y1:a.y,x2:b.x,y2:b.y,color:$('photoArrowColor').value});});
markupCanvas.addEventListener('pointerup',e=>{
 if(photoEditor?.start?.id!==e.pointerId)return;const a=photoEditor.start,b=fieldNotesPhotoPoint(e),dx=Math.abs(a.x-b.x),dy=Math.abs(a.y-b.y);
 if(photoEditor.mode==='delete'||Math.hypot(dx,dy)<=.01){photoEditor.selected=photoArrowAt(b);}
 else if(photoEditor.mode==='crop'){
  if(dx>.05&&dy>.05){photoEditRemember();const c=photoEditor.crop,x=Math.min(a.x,b.x),y=Math.min(a.y,b.y);photoEditor.arrows=photoEditor.arrows.filter(t=>[t.x1,t.x2].every(v=>v>=x&&v<=x+dx)&&[t.y1,t.y2].every(v=>v>=y&&v<=y+dy)).map(t=>({...t,x1:(t.x1-x)/dx,x2:(t.x2-x)/dx,y1:(t.y1-y)/dy,y2:(t.y2-y)/dy}));photoEditor.crop={x:c.x+x*c.w,y:c.y+y*c.h,w:c.w*dx,h:c.h*dy};photoEditor.selected=-1;fieldNotesSetCropCanvas();}
 }else{photoEditRemember();photoEditor.arrows.push({x1:a.x,y1:a.y,x2:b.x,y2:b.y,color:$('photoArrowColor').value});photoEditor.selected=-1;}
 photoEditor.start=null;fieldNotesPaintPhoto();
});
markupCanvas.addEventListener('pointercancel',()=>{if(photoEditor){photoEditor.start=null;fieldNotesPaintPhoto();}});
$('savePhotoArrows').onclick=()=>{if(!photoEditor||photoEditor.target!==pending)return;const p=pending.photos[photoEditor.index],c=photoEditor.crop,cropped=c.x!==0||c.y!==0||c.w!==1||c.h!==1;fieldNotesPaintPhoto(null,true);p.originalDataUrl=p.originalDataUrl||p.dataUrl;p.crop={...c};p.arrows=photoEditor.arrows.map(a=>({...a}));p.dataUrl=cropped||p.arrows.length?markupCanvas.toDataURL('image/jpeg',.94):p.originalDataUrl;$('photoMarkupSheet').close('apply');renderNotePhotos();};
$('photoMarkupSheet').addEventListener('close',()=>{photoEditor=null;});
