'use strict';
/* Field Notes 0.3.7: field-test corrections. Existing document IDs and storage stay unchanged. */
(()=>{
  // A tag is part of the drawing. Use one nominal 3/16-inch diameter at the
  // source sheet's actual size, rather than a fixed pixel size or a screen selector.
  const tagDiameterPt=72*3/16;
  const pinRadius=page=>tagDiameterPt*printGeometry(page).fit/2;
  const oldScreenStyle=screenStyle;
  screenStyle=function(){const s=oldScreenStyle();const radius=pinRadius(pages[pageIndex]);return {...s,pinRadius:radius,numberSize:radius*.9,strokeWidth:Math.max(.65,radius*.15)};};
  const oldPrintedStyle=printedStyle;
  printedStyle=function(mark,page){const s=oldPrintedStyle(mark,page),radius=pinRadius(page);return {...s,pinRadius:radius,numberSize:radius*.9,strokeWidth:Math.max(.65,radius*.15)};};
  lab.annotationScale=1;
  $('annotationSize').value='1';
  // Each export gets its own suggested name. The existing Save dialog lets the
  // user edit it. The persistent shared filename field remains hidden.
  fieldNotesExportName=function(kind,extension){
    const suffix=/annotated|vector/i.test(kind)?'Annotated Plan':/punch/i.test(kind)?'Punch List':/photo/i.test(kind)?'Photo Log':/backup/i.test(kind)?'Backup':'Notes';
    const clean=s=>String(s||'').replace(/[\\/:*?"<>|\x00-\x1f]/g,'_').replace(/\s+/g,' ').trim();
    const parts=[photoLogMetadata.projectNumber,photoLogMetadata.projectName,suffix].map(clean).filter(Boolean);
    return parts.join(' - ').slice(0,140)+'.'+extension;
  };
  // Read-only dialogs close on backdrop tap. Editing dialogs do not.
  for(const id of ['notesSheet','savedDrawingsSheet']){
    const dialog=$(id);if(!dialog)continue;
    dialog.addEventListener('click',e=>{
      if(e.target!==dialog)return;
      const r=dialog.getBoundingClientRect();
      if(e.clientX<r.left||e.clientX>r.right||e.clientY<r.top||e.clientY>r.bottom){e.preventDefault();dialog.close();}
    });
  }
  // Remove stale success messages instead of stacking duplicates in the menu.
  const statusIds=['photoLogStatus','vectorPdfStatus','fileStatus'];
  for(const id of statusIds){const el=$(id);if(!el)continue;let timeout;
    new MutationObserver(()=>{clearTimeout(timeout);if(/^(Saved\b|Exported\b|\d+ photo\(s\) prepared\b)/i.test(el.textContent.trim()))timeout=setTimeout(()=>{el.textContent='';},4000);}).observe(el,{childList:true,subtree:true});
  }
  // Small, explicit report PDF, separate from the editable PowerPoint report.
  const pdfButton=$('exportPhotoPdf');
  function wrapText(text,font,size,maxWidth){const lines=[];for(const para of String(text||'').split(/\n/)){let line='';for(const word of para.split(/\s+/).filter(Boolean)){const next=line?line+' '+word:word;if(font.widthOfTextAtSize(next,size)>maxWidth&&line){lines.push(line);line=word;}else line=next;}lines.push(line);}return lines;}
  async function imageBytes(dataUrl){if(/^data:image\/(jpeg|jpg|png);base64,/i.test(dataUrl))return dataUrl;
    return await new Promise((resolve,reject)=>{const image=new Image();image.onload=()=>{const canvas=document.createElement('canvas');canvas.width=image.naturalWidth;canvas.height=image.naturalHeight;canvas.getContext('2d').drawImage(image,0,0);resolve(canvas.toDataURL('image/jpeg',.92));};image.onerror=reject;image.src=dataUrl;});
  }
  pdfButton.onclick=async()=>{
    if(pending||tablet.active||tablet.restoring||loadingPage){$('photoLogStatus').textContent='Finish the current action before exporting.';return;}
    pdfButton.disabled=true;
    try{
      savePage();const entries=pages.flatMap((page,i)=>page.marks.filter(m=>m.kind==='note'&&tabletNoteType(m)==='photo'&&m.photos?.length).map(m=>({mark:m,page:i+1}))).sort((a,b)=>a.mark.number-b.mark.number);
      if(!entries.length)throw Error('Add a photo before exporting.');
      const pdf=await PDFLib.PDFDocument.create(),font=await pdf.embedFont(PDFLib.StandardFonts.Helvetica),bold=await pdf.embedFont(PDFLib.StandardFonts.HelveticaBold),ink=PDFLib.rgb(.13,.20,.19);
      for(const entry of entries){const {mark,page:sourcePage}=entry;for(let offset=0;offset<mark.photos.length;offset+=2){
        const page=pdf.addPage([612,792]);let y=748;
        const line=(value,size=10,weight=font)=>{for(const l of wrapText(value,weight,size,520)){if(y<105)break;page.drawText(l.slice(0,240),{x:46,y,size,font:weight,color:ink});y-=size+5;}};
        line([photoLogMetadata.projectNumber,photoLogMetadata.projectName].filter(Boolean).join(' | ')||'Field Notes',13,bold);y-=6;
        line(`PHOTO LOG  |  ${fieldNotesPhotoId(mark.number)}  |  Drawing page ${sourcePage}${offset?' (continued)':''}`,11,bold);
        if(photoLogMetadata.date)line(`Report date: ${photoLogMetadata.date}`);
        if(mark.location)line(`Location: ${mark.location}`);
        if(mark.text)line(`Description: ${mark.text}`);
        if(mark.disposition)line(`Disposition: ${mark.disposition}`);
        y-=14;const photos=mark.photos.slice(offset,offset+2);const boxW=248,boxH=Math.min(360,Math.max(140,y-110));
        for(let j=0;j<photos.length;j++){
          const p=photos[j],url=await imageBytes(p.dataUrl),bytes=Uint8Array.from(atob(url.split(',')[1]),c=>c.charCodeAt(0));
          const image=url.startsWith('data:image/png')?await pdf.embedPng(bytes):await pdf.embedJpg(bytes);
          const scale=Math.min(boxW/image.width,boxH/image.height),w=image.width*scale,h=image.height*scale;
          const x=46+j*266+(boxW-w)/2;
          page.drawImage(image,{x,y:y-h,width:w,height:h});
          page.drawText(`Image ${offset+j+1} of ${mark.photos.length}`,{x:46+j*266,y:Math.max(56,y-boxH-19),size:9,font,color:ink});
        }
        page.drawText('Field Notes  |  Photo Log', {x:46,y:32,size:9,font,color:ink});
      }}
      const saved=await downloadBlob(new Blob([await pdf.save()],{type:'application/pdf'}),fieldNotesExportName('Photo Log','pdf'));
      $('photoLogStatus').textContent=saved?'Photo log PDF prepared. Complete the Save dialog.':'Export cancelled.';
    }catch(error){$('photoLogStatus').textContent='PDF export failed: '+error.message;}finally{pdfButton.disabled=false;}
  };
  // The export menu and ink remain intact; new settings do not erase drafts.
  tablet.revision++;tabletRender();
})();
