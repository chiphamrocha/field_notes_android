/* Shared app/PDF geometry: 6.75 pt is the actual glyph ink height, not em size. */
(function(r,f){if(typeof module==='object'&&module.exports)module.exports=f(require('./tag-glyphs.js'));else r.fieldNotesTags=f(r.fieldNotesTagGlyphs);})(typeof globalThis!=='undefined'?globalThis:this,function(atlas){
 'use strict';
 const HEIGHT_PT=72*3/32,PADDING_PT=1.5,STEM_RATIO=.11;
 const cache=new Map();
 function layout(value){
  const label=String(value||'?').toUpperCase();if(cache.has(label))return cache.get(label);
  let x=0,minX=Infinity,minY=Infinity,maxX=-Infinity,maxY=-Infinity;const runs=[];
  for(const c of label){const g=atlas.glyphs[c]||atlas.glyphs['?'];runs.push({x,path:g.path});minX=Math.min(minX,x+g.bbox[0]);minY=Math.min(minY,g.bbox[1]);maxX=Math.max(maxX,x+g.bbox[2]);maxY=Math.max(maxY,g.bbox[3]);x+=g.advance;}
  const scale=HEIGHT_PT/(maxY-minY),result={label,runs,bounds:{minX,minY,maxX,maxY},scale,widthPt:(maxX-minX)*scale};cache.set(label,result);return result;
 }
 const referenceWidth=layout('A999').widthPt;
 function geometry(value,worldPerPoint=1){
  const text=layout(value),halfWidth=Math.max(referenceWidth,text.widthPt)/2+PADDING_PT,halfHeight=HEIGHT_PT/2+PADDING_PT;
  // The padded text rectangle fits inside the hexagon's inscribed circle.
  const radius=Math.hypot(halfWidth,halfHeight)/Math.cos(Math.PI/6)*worldPerPoint;
  return {text,radius,diameter:radius*2,textHeight:HEIGHT_PT*worldPerPoint,textWidth:text.widthPt*worldPerPoint,padding:PADDING_PT*worldPerPoint,glyphScale:text.scale*worldPerPoint,stemWidth:radius*2*STEM_RATIO,stemLength:radius*.4};
 }
 function svg(value,x,anchorY,worldPerPoint,photo){
  const g=geometry(value,worldPerPoint),y=anchorY-g.radius-g.stemLength,color=photo?'#c45b36':'#285f70',b=g.text.bounds;
  const shape=photo?`<circle cx="${x}" cy="${y}" r="${g.radius}" fill="${color}"/>`:`<polygon points="${Array.from({length:6},(_,i)=>{const a=Math.PI/6+i*Math.PI/3;return `${x+g.radius*Math.cos(a)},${y+g.radius*Math.sin(a)}`;}).join(' ')}" fill="${color}"/>`;
  return `<g class="fn-tag" data-label="${g.text.label.replace(/[&<>"]/g, c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]))}" data-text-height-pt="${HEIGHT_PT}"><path class="fn-tag-stem" d="M ${x} ${anchorY} L ${x} ${y+g.radius}" stroke="${color}" stroke-width="${g.stemWidth}" stroke-linecap="butt"/>${shape}<g class="fn-tag-text" fill="white" transform="translate(${x} ${y}) scale(${g.glyphScale} ${-g.glyphScale}) translate(${-(b.minX+b.maxX)/2} ${-(b.minY+b.maxY)/2})">${g.text.runs.map(run=>`<path d="${run.path}" transform="translate(${run.x} 0)"/>`).join('')}</g></g>`;
 }
 return {HEIGHT_PT,PADDING_PT,STEM_RATIO,layout,geometry,svg};
});
