from pathlib import Path
import re
root=Path(__file__).parent/'app/src/main/assets/web'
for name in ['index.html','tablet.html']:
 html=(root/name).read_text(encoding='utf-8')
 assert 'Field Notes · 0.3.10' in html
 for ref in re.findall(r'(?:src|href)="([^"#]+)"',html):
  if ':' not in ref: assert (root/ref.split('?')[0]).is_file(),ref
for name in ['tag-glyphs.js','tag-geometry.js','photo-editor.js','fixes-040.js','fixes-040.css']:assert (root/name).is_file(),name
print('Field Notes 0.3.10 Android web assets and references are ready.')
