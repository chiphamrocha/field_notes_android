# Field Notes Android 0.3.10 / version code 40

Scope: only the five corrections reported for v0.3.9. Earlier backlog is not reopened.

1. Tag text: 3/32-inch actual visible glyph height (6.75 pt), per the user's final
   revision. Shared bundled-font glyph metrics and geometry; app/SVG outlines match the
   embedded searchable text in annotated PDF.
   Circle and hexagon fit A999 plus padding; text and bubble zoom with the drawing.
2. Photo stem: short, centered, 11% of bubble diameter; existing anchor unchanged.
3. New sketch widths: Fine 0.3, Medium 0.6, Bold 1.2 drawing units. Old Fine 1.2 is
   the new Bold. No division by zoom. Existing saved ink records are unchanged.
   Selected old presets migrate once using a settings-version field.
4. Menu/S Pen: replace overlapping pen handlers with a single immediate pen-down
   path and duplicate-click suppression. Add a native stylus-down fallback that
   DOM-hit-tests only Menu; native drawing events are never consumed by it.
5. Photo editor: seven action groups in one non-wrapping top toolbar: Undo,
   Add arrow with yellow-default color dropdown, Delete arrow, Crop, Reset crop,
   Cancel, Apply edits. Canvas below. Delete selected arrow; Undo supports arrow
   add/delete and crop/reset. Edits remain drafts until Apply, then note Save.
   Native Android system-bar/cutout insets keep the WebView inside usable bounds.

Package, signing certificate, WebView origin, database/store names and existing
project/mark/photo IDs remain unchanged. Physical Samsung acceptance is pending.
