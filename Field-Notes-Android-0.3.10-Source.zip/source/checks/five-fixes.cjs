const fs=require('fs'),assert=require('assert');
const root='../app/src/main/assets/web/';
const tags=require(root+'tag-geometry.js'),P=require(root+'vendor/pdf-lib.min.js'),pdf=require(root+'vector-pdf.js'),fontkit=require(root+'vendor/fontkit.umd.min.js');
(async()=>{
 for(const label of ['1','9','A01','A999','M999','E999','F999'])for(const fit of [.25,.9,1,4]){
  const g=tags.geometry(label,fit),b=g.text.bounds;
  assert.ok(Math.abs((b.maxY-b.minY)*g.glyphScale/fit-6.75)<1e-9);
  assert.ok(Math.abs(g.stemWidth/g.diameter-.11)<1e-12);
  assert.ok(g.radius*Math.cos(Math.PI/6)>Math.hypot(g.textWidth/2+g.padding,g.textHeight/2+g.padding)-1e-8);
 }
 const doc=await P.PDFDocument.create();doc.addPage([450,300]);
 const marks=[{kind:'note',noteType:'photo',number:999,displayNumber:'A999',x:300,y:300,photos:[{}]},{kind:'note',noteType:'text',number:999,displayNumber:'A999',x:700,y:300}];
 for(const [i,width]of [.3,.6,1.2].entries())marks.push({kind:'ink',points:[{x:300,y:430+i*70},{x:700,y:430+i*70}],width,color:'#be3c32'});
 fs.mkdirSync('build/qa',{recursive:true});
 const bytes=await pdf.build({sourceKind:'pdf',sourceBytes:await doc.save(),pages:[{marks}],fontBytes:fs.readFileSync('app/src/main/assets/web/vendor/fonts/DejaVuSans.ttf'),fontkit});
 fs.writeFileSync('build/qa/five-fixes-plotted.pdf',bytes);
 assert.equal((await P.PDFDocument.load(bytes)).getPageCount(),1);
 console.log('PASS: 3/32-inch actual glyph bounds, centered A999 padding in both shapes, 11% stem, shared geometry and real annotated-PDF fixture generated.');
})().catch(e=>{console.error(e);process.exitCode=1;});
