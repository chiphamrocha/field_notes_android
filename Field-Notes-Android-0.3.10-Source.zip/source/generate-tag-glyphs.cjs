// Deterministic glyph outlines from the already-bundled font. No runtime font fetch.
const fs=require('fs'),path=require('path');
const root=path.join(__dirname,'app/src/main/assets/web');
const fontkit=require(path.join(root,'vendor/fontkit.umd.min.js'));
const font=fontkit.create(fs.readFileSync(path.join(root,'vendor/fonts/DejaVuSans.ttf')));
const glyphs={};
for(const c of '0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ?-'){
 const g=font.glyphForCodePoint(c.codePointAt(0));
 glyphs[c]={advance:g.advanceWidth,bbox:[g.bbox.minX,g.bbox.minY,g.bbox.maxX,g.bbox.maxY],path:g.path.toSVG()};
}
const data={font:'DejaVu Sans',unitsPerEm:font.unitsPerEm,glyphs};
fs.writeFileSync(path.join(root,'tag-glyphs.js'),"/* Generated from vendor/fonts/DejaVuSans.ttf; see its bundled license. */\n(function(r,f){if(typeof module==='object'&&module.exports)module.exports=f();else r.fieldNotesTagGlyphs=f();})(typeof globalThis!=='undefined'?globalThis:this,()=>("+JSON.stringify(data)+"));\n");
