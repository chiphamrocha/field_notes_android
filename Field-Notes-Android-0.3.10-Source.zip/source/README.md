# Field Notes Android 0.3.10

Five scoped corrections from v0.3.9; see CHANGELOG.md and TESTING.md. The final
approved actual tag-letter height is 3/32 inch, superseding 1/16 inch.

## Build
The complete project includes web assets, shared tag geometry, bundled font
outlines, Java, Android resources, licenses and checks. Cloud prerequisites:
JDK 17, Android SDK platform 35 / Build Tools 35.0.0, Node 22, Python 3, Playwright.
Use android-actions/setup-android to expose sdkmanager on GitHub's runner.
Run `bash verify.sh` and `FIELD_NOTES_BROWSER_TESTS=1 bash verify.sh`, then
`ANDROID_SDK_ROOT=/path/to/sdk bash build.sh`. No developer software is required
on the user's work computer. Regenerate glyph outlines deterministically with
`node generate-tag-glyphs.cjs` if the bundled font changes.

## Signing
Same package com.fieldnotes.preview; version code 40 / version name 0.3.10.
Existing GitHub Actions secret FIELD_NOTES_KEYSTORE_B64 supplies the matching key.
No key is included in source. Original test-key parameters remain android /
androiddebugkey, optionally overridden by existing Actions password/alias secrets.
The build checks certificate SHA256:
28bfff0b3d3d38064caaa1ba679ebb2718cfcd3ed45a3daf9160b74efd46961c.
Do not generate replacement keys or remove this check. Unsigned output must not
be installed. The root cloud workflow extracts the full source ZIP before build.

## Data and installation
Preserve the app installation and storage. Export important drawings first, then
install the signed APK as an update. Never uninstall/clear data to bypass failure.
An exported backup ZIP does not have a supported app re-import interface.
Old ink widths remain unchanged; preset settings migrate once for new strokes.
Package, WebView URL/origin, database/store names and saved record identities stay
unchanged. Physical installation and S Pen/taskbar acceptance remain unverified.
