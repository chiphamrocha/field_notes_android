# Source and release archive plan

Repository: https://github.com/chiphamrocha/field_notes_android (public source and included templates explicitly authorized by the user).
Public source upload authorized; keep keys in
Actions secrets only. Commit source, vendored dependencies/licenses, tests,
workflow and evidence. Tag a release only after a signed cloud build exists.
Do not treat historical assistant release claims as build evidence.

Google Drive plan: create a private Field Notes Releases folder, with an
immutable 0.3.9/YYYY-MM-DD release folder containing signed APK, complete source
ZIP, changelog, testing status, source commit, CI log and SHA-256 manifest.
Archive the original handoff separately as read-only recovery material.
Keep signing-key backup separately with restricted access. No public sharing.
Google Drive folder creation/upload has not occurred. This file records the
private Drive archival plan; the working build took priority.
