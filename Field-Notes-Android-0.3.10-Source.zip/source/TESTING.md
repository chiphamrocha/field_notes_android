# 0.3.10 verification status

## Passed locally
- Seven Node suites: existing draw/erase/Undo, save/restore, file isolation,
  reports, Android bridge, modal gesture guard and new shared tag geometry.
- Actual app entry in existing Edge with native services simulated: all seven
  editor action groups stay on one row and inside 800/1100 px wide viewports,
  including 480/600 px heights. Yellow default, alternate color, selected arrow
  deletion, Undo of delete/add/crop, Cancel, reset and Apply pass.
- A999 in circle and hexagon: SVG visible ink height 6.75 pt and centered at
  25%, 50%, 100%, 200% and 400% zoom, with no clipping.
- New ink widths 0.3/0.6/1.2 retained at four creation zoom levels.
- Exported annotated PDF rendered by Poppler at 576 DPI: both A999 ink bounding
  boxes measure exactly 6.75 pt = 0.09375 inch; centering error <=0.0625 pt.
  Actual PDF stroke operators measure the expected 0.135/0.27/0.54 pt on the
  450x300-point QA fixture (same 1:2:4 ratio and drawing-coordinate mapping).
- v0.3.9 web assets -> candidate at unchanged origin: project/document/archive,
  photo IDs, caption/location/disposition, positions and old ink retained.
- Regression exports: actual PDF/PPTX/ZIP; page navigation/rotation; cropped PDF
  pages and Unicode; old drawing/entry deletion and Undo remain working.

## Pending cloud build
Compile Java/resources/DEX, official apksigner and zipalign, expected certificate,
package com.fieldnotes.preview / versionCode 40 / versionName 0.3.10.

## Requires physical Samsung Galaxy Tab S6
- Single brief S Pen Menu tap, especially after text/handwriting and in Pen-only.
- Visible Android taskbar/system insets in landscape; all top controls tappable.
- Actual install over the existing app with saved-project retention.
- Camera/microphone and real printed 100% scale on the user's sheet.

No uninstall or data clearing is authorized. Existing strokes retain old widths;
only new strokes use the recalibrated presets. No old backlog is closed here.
